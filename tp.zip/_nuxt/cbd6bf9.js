(window.webpackJsonp = window.webpackJsonp || []).push([[2], {
    0: function (e, t, n) {
        "use strict";
        n.d(t, "k", (function () {
            return y
        })), n.d(t, "m", (function () {
            return O
        })), n.d(t, "l", (function () {
            return _
        })), n.d(t, "e", (function () {
            return v
        })), n.d(t, "b", (function () {
            return A
        })), n.d(t, "s", (function () {
            return C
        })), n.d(t, "g", (function () {
            return x
        })), n.d(t, "h", (function () {
            return P
        })), n.d(t, "d", (function () {
            return w
        })), n.d(t, "r", (function () {
            return E
        })), n.d(t, "j", (function () {
            return S
        })), n.d(t, "t", (function () {
            return N
        })), n.d(t, "o", (function () {
            return I
        })), n.d(t, "q", (function () {
            return L
        })), n.d(t, "f", (function () {
            return B
        })), n.d(t, "c", (function () {
            return R
        })), n.d(t, "i", (function () {
            return H
        })), n.d(t, "p", (function () {
            return U
        })), n.d(t, "a", (function () {
            return K
        })), n.d(t, "v", (function () {
            return z
        })), n.d(t, "n", (function () {
            return Y
        })), n.d(t, "u", (function () {
            return X
        }));
        n(9), n(51), n(18), n(19);
        var o = n(37), r = n(6), c = n(3), l = n(17),
            d = (n(64), n(11), n(252), n(24), n(38), n(52), n(13), n(53), n(54), n(50), n(34), n(150), n(174), n(149), n(118), n(119), n(256), n(111), n(103), n(1)),
            m = n(28);

        function h(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function T(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? h(Object(source), !0).forEach((function (t) {
                    Object(c.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : h(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        function f(e, t) {
            var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = function (e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return k(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return k(e, t)
                }(e)) || t && e && "number" == typeof e.length) {
                    n && (e = n);
                    var i = 0, o = function () {
                    };
                    return {
                        s: o, n: function () {
                            return i >= e.length ? {done: !0} : {done: !1, value: e[i++]}
                        }, e: function (e) {
                            throw e
                        }, f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, c = !0, l = !1;
            return {
                s: function () {
                    n = n.call(e)
                }, n: function () {
                    var e = n.next();
                    return c = e.done, e
                }, e: function (e) {
                    l = !0, r = e
                }, f: function () {
                    try {
                        c || null == n.return || n.return()
                    } finally {
                        if (l) throw r
                    }
                }
            }
        }

        function k(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var i = 0, n = new Array(t); i < t; i++) n[i] = e[i];
            return n
        }

        function y(e) {
            d.default.config.errorHandler && d.default.config.errorHandler(e)
        }

        function O(e) {
            return e.then((function (e) {
                return e.default || e
            }))
        }

        function _(e) {
            return e.$options && "function" == typeof e.$options.fetch && !e.$options.fetch.length
        }

        function v(e) {
            var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], o = e.$children || [],
                r = f(o);
            try {
                for (r.s(); !(t = r.n()).done;) {
                    var c = t.value;
                    c.$fetch ? n.push(c) : c.$children && v(c, n)
                }
            } catch (e) {
                r.e(e)
            } finally {
                r.f()
            }
            return n
        }

        function A(e, t) {
            if (t || !e.options.__hasNuxtData) {
                var n = e.options._originDataFn || e.options.data || function () {
                    return {}
                };
                e.options._originDataFn = n, e.options.data = function () {
                    var data = n.call(this, this);
                    return this.$ssrContext && (t = this.$ssrContext.asyncData[e.cid]), T(T({}, data), t)
                }, e.options.__hasNuxtData = !0, e._Ctor && e._Ctor.options && (e._Ctor.options.data = e.options.data)
            }
        }

        function C(e) {
            return e.options && e._Ctor === e || (e.options ? (e._Ctor = e, e.extendOptions = e.options) : (e = d.default.extend(e))._Ctor = e, !e.options.name && e.options.__file && (e.options.name = e.options.__file)), e
        }

        function x(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "components";
            return Array.prototype.concat.apply([], e.matched.map((function (e, o) {
                return Object.keys(e[n]).map((function (r) {
                    return t && t.push(o), e[n][r]
                }))
            })))
        }

        function P(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return x(e, t, "instances")
        }

        function w(e, t) {
            return Array.prototype.concat.apply([], e.matched.map((function (e, n) {
                return Object.keys(e.components).reduce((function (o, r) {
                    return e.components[r] ? o.push(t(e.components[r], e.instances[r], e, r, n)) : delete e.components[r], o
                }), [])
            })))
        }

        function E(e, t) {
            return Promise.all(w(e, function () {
                var e = Object(r.a)(regeneratorRuntime.mark((function e(n, o, r, c) {
                    var l, d;
                    return regeneratorRuntime.wrap((function (e) {
                        for (; ;) switch (e.prev = e.next) {
                            case 0:
                                if ("function" != typeof n || n.options) {
                                    e.next = 11;
                                    break
                                }
                                return e.prev = 1, e.next = 4, n();
                            case 4:
                                n = e.sent, e.next = 11;
                                break;
                            case 7:
                                throw e.prev = 7, e.t0 = e.catch(1), e.t0 && "ChunkLoadError" === e.t0.name && "undefined" != typeof window && window.sessionStorage && (l = Date.now(), (!(d = parseInt(window.sessionStorage.getItem("nuxt-reload"))) || d + 6e4 < l) && (window.sessionStorage.setItem("nuxt-reload", l), window.location.reload(!0))), e.t0;
                            case 11:
                                return r.components[c] = n = C(n), e.abrupt("return", "function" == typeof t ? t(n, o, r, c) : n);
                            case 13:
                            case"end":
                                return e.stop()
                        }
                    }), e, null, [[1, 7]])
                })));
                return function (t, n, o, r) {
                    return e.apply(this, arguments)
                }
            }()))
        }

        function S(e) {
            return D.apply(this, arguments)
        }

        function D() {
            return (D = Object(r.a)(regeneratorRuntime.mark((function e(t) {
                return regeneratorRuntime.wrap((function (e) {
                    for (; ;) switch (e.prev = e.next) {
                        case 0:
                            if (t) {
                                e.next = 2;
                                break
                            }
                            return e.abrupt("return");
                        case 2:
                            return e.next = 4, E(t);
                        case 4:
                            return e.abrupt("return", T(T({}, t), {}, {
                                meta: x(t).map((function (e, n) {
                                    return T(T({}, e.options.meta), (t.matched[n] || {}).meta)
                                }))
                            }));
                        case 5:
                        case"end":
                            return e.stop()
                    }
                }), e)
            })))).apply(this, arguments)
        }

        function N(e, t) {
            return M.apply(this, arguments)
        }

        function M() {
            return (M = Object(r.a)(regeneratorRuntime.mark((function e(t, n) {
                var r, c, d, h;
                return regeneratorRuntime.wrap((function (e) {
                    for (; ;) switch (e.prev = e.next) {
                        case 0:
                            return t.context || (t.context = {
                                isStatic: !1,
                                isDev: !1,
                                isHMR: !1,
                                app: t,
                                store: t.store,
                                payload: n.payload,
                                error: n.error,
                                base: t.router.options.base,
                                env: {}
                            }, n.req && (t.context.req = n.req), n.res && (t.context.res = n.res), n.ssrContext && (t.context.ssrContext = n.ssrContext), t.context.redirect = function (e, path, n) {
                                if (e) {
                                    t.context._redirected = !0;
                                    var r = Object(o.a)(path);
                                    if ("number" == typeof e || "undefined" !== r && "object" !== r || (n = path || {}, path = e, r = Object(o.a)(path), e = 302), "object" === r && (path = t.router.resolve(path).route.fullPath), !/(^[.]{1,2}\/)|(^\/(?!\/))/.test(path)) throw path = Object(m.d)(path, n), window.location.replace(path), new Error("ERR_REDIRECT");
                                    t.context.next({path: path, query: n, status: e})
                                }
                            }, t.context.nuxtState = window.__NUXT__), e.next = 3, Promise.all([S(n.route), S(n.from)]);
                        case 3:
                            r = e.sent, c = Object(l.a)(r, 2), d = c[0], h = c[1], n.route && (t.context.route = d), n.from && (t.context.from = h), t.context.next = n.next, t.context._redirected = !1, t.context._errored = !1, t.context.isHMR = !1, t.context.params = t.context.route.params || {}, t.context.query = t.context.route.query || {};
                        case 15:
                        case"end":
                            return e.stop()
                    }
                }), e)
            })))).apply(this, arguments)
        }

        function I(e, t) {
            return !e.length || t._redirected || t._errored ? Promise.resolve() : L(e[0], t).then((function () {
                return I(e.slice(1), t)
            }))
        }

        function L(e, t) {
            var n;
            return (n = 2 === e.length ? new Promise((function (n) {
                e(t, (function (e, data) {
                    e && t.error(e), n(data = data || {})
                }))
            })) : e(t)) && n instanceof Promise && "function" == typeof n.then ? n : Promise.resolve(n)
        }

        function B(base, e) {
            if ("hash" === e) return window.location.hash.replace(/^#\//, "");
            base = decodeURI(base).slice(0, -1);
            var path = decodeURI(window.location.pathname);
            base && path.startsWith(base) && (path = path.slice(base.length));
            var t = (path || "/") + window.location.search + window.location.hash;
            return Object(m.c)(t)
        }

        function R(e, t) {
            return function (e, t) {
                for (var n = new Array(e.length), i = 0; i < e.length; i++) "object" === Object(o.a)(e[i]) && (n[i] = new RegExp("^(?:" + e[i].pattern + ")$", V(t)));
                return function (t, o) {
                    for (var path = "", data = t || {}, r = (o || {}).pretty ? j : encodeURIComponent, c = 0; c < e.length; c++) {
                        var l = e[c];
                        if ("string" != typeof l) {
                            var d = data[l.name || "pathMatch"], m = void 0;
                            if (null == d) {
                                if (l.optional) {
                                    l.partial && (path += l.prefix);
                                    continue
                                }
                                throw new TypeError('Expected "' + l.name + '" to be defined')
                            }
                            if (Array.isArray(d)) {
                                if (!l.repeat) throw new TypeError('Expected "' + l.name + '" to not repeat, but received `' + JSON.stringify(d) + "`");
                                if (0 === d.length) {
                                    if (l.optional) continue;
                                    throw new TypeError('Expected "' + l.name + '" to not be empty')
                                }
                                for (var h = 0; h < d.length; h++) {
                                    if (m = r(d[h]), !n[c].test(m)) throw new TypeError('Expected all "' + l.name + '" to match "' + l.pattern + '", but received `' + JSON.stringify(m) + "`");
                                    path += (0 === h ? l.prefix : l.delimiter) + m
                                }
                            } else {
                                if (m = l.asterisk ? F(d) : r(d), !n[c].test(m)) throw new TypeError('Expected "' + l.name + '" to match "' + l.pattern + '", but received "' + m + '"');
                                path += l.prefix + m
                            }
                        } else path += l
                    }
                    return path
                }
            }(function (e, t) {
                var n, o = [], r = 0, c = 0, path = "", l = t && t.delimiter || "/";
                for (; null != (n = W.exec(e));) {
                    var d = n[0], m = n[1], h = n.index;
                    if (path += e.slice(c, h), c = h + d.length, m) path += m[1]; else {
                        var T = e[c], f = n[2], k = n[3], y = n[4], O = n[5], _ = n[6], v = n[7];
                        path && (o.push(path), path = "");
                        var A = null != f && null != T && T !== f, C = "+" === _ || "*" === _,
                            x = "?" === _ || "*" === _, P = n[2] || l, pattern = y || O;
                        o.push({
                            name: k || r++,
                            prefix: f || "",
                            delimiter: P,
                            optional: x,
                            repeat: C,
                            partial: A,
                            asterisk: Boolean(v),
                            pattern: pattern ? G(pattern) : v ? ".*" : "[^" + $(P) + "]+?"
                        })
                    }
                }
                c < e.length && (path += e.substr(c));
                path && o.push(path);
                return o
            }(e, t), t)
        }

        function H(e, t) {
            var n = {}, o = T(T({}, e), t);
            for (var r in o) String(e[r]) !== String(t[r]) && (n[r] = !0);
            return n
        }

        function U(e) {
            var t;
            if (e.message || "string" == typeof e) t = e.message || e; else try {
                t = JSON.stringify(e, null, 2)
            } catch (n) {
                t = "[".concat(e.constructor.name, "]")
            }
            return T(T({}, e), {}, {
                message: t,
                statusCode: e.statusCode || e.status || e.response && e.response.status || 500
            })
        }

        window.onNuxtReadyCbs = [], window.onNuxtReady = function (e) {
            window.onNuxtReadyCbs.push(e)
        };
        var W = new RegExp(["(\\\\.)", "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"].join("|"), "g");

        function j(e, t) {
            var n = t ? /[?#]/g : /[/?#]/g;
            return encodeURI(e).replace(n, (function (e) {
                return "%" + e.charCodeAt(0).toString(16).toUpperCase()
            }))
        }

        function F(e) {
            return j(e, !0)
        }

        function $(e) {
            return e.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1")
        }

        function G(e) {
            return e.replace(/([=!:$/()])/g, "\\$1")
        }

        function V(e) {
            return e && e.sensitive ? "" : "i"
        }

        function K(e, t, n) {
            e.$options[t] || (e.$options[t] = []), e.$options[t].includes(n) || e.$options[t].push(n)
        }

        var z = m.b, Y = (m.e, m.a);

        function X(e) {
            try {
                window.history.scrollRestoration = e
            } catch (e) {
            }
        }
    }, 100: function (e, t, n) {
        "use strict";
        var o = {name: "miniNav", mixins: [n(59).a]}, r = (n(278), n(2)), component = Object(r.a)(o, (function () {
            var e = this, t = e.$createElement, o = e._self._c || t;
            return o("div", {staticClass: "mini-nav"}, [o("nav", {
                staticClass: "mini-navbar-wrap",
                class: {isFixed: e.menuState}
            }, [o("div", {staticClass: "mini-navbar-header"}, [o("div", [o("img", {
                staticClass: "mini-navbar-logo pointer",
                attrs: {src: n(223), alt: e.$t("COMMON.LAYOUT.defiWallet")},
                on: {
                    click: function (t) {
                        return e.indexGo("/")
                    }
                }
            })]), e._v(" "), o("div", {staticClass: "menu-status text-right"}, [e.menuState ? o("img", {
                attrs: {
                    src: n(277),
                    alt: ""
                }, on: {click: e.changeMenuState}
            }) : o("img", {
                attrs: {src: n(276), alt: ""},
                on: {click: e.changeMenuState}
            })])]), e._v(" "), e.menuState ? o("div", {staticClass: "mini-menu"}, e._l(e.navList, (function (t, n) {
                return o("a", {
                    key: n,
                    staticClass: "ft-18",
                    staticStyle: {display: "block"},
                    attrs: {href: t.local && t.url ? t.url : "javascript:void(0)"},
                    on: {
                        click: function (o) {
                            return o.stopPropagation(), e.navGo(t, n, o)
                        }
                    }
                }, [o("div", {staticClass: "mini-menu-title"}, [o("div", {staticClass: "menu-item"}, [o("div", [e._v(e._s(t.title))]), e._v(" "), t.children ? o("div", {staticClass: "text-right"}, [o("i", {
                    class: [e.navIndex !== n ? t.lang ? "icon-earth-mini" : "icon-right" : "icon-right icon-dropdown"],
                    staticStyle: {transition: "all .3s"}
                })]) : e._e()]), e._v(" "), t.children && e.navIndex === n ? o("div", {staticClass: "mini-menu-children"}, e._l(t.children, (function (t, n) {
                    return o("a", {
                        key: n,
                        staticClass: "mini-menu-children-title ft-14",
                        attrs: {
                            href: !t.lang && t.url ? t.url : "javascript:void(0)",
                            target: t.local || t.lang ? "_self" : "_blank"
                        },
                        on: {
                            click: function (n) {
                                return n.stopPropagation(), e.navChildrenGo(t, n)
                            }
                        }
                    }, [e._v(e._s(t.title))])
                })), 0) : e._e()])])
            })), 0) : e._e()])])
        }), [], !1, null, "bcb887bc", null);
        t.a = component.exports
    }, 101: function (e, t, n) {
        "use strict";
        n(13), n(9), n(11), n(18), n(19);
        var o = n(3), r = n(10);

        function c(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        var l = {
            name: "warn", computed: function (e) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? c(Object(source), !0).forEach((function (t) {
                        Object(o.a)(e, t, source[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : c(Object(source)).forEach((function (t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                    }))
                }
                return e
            }({}, Object(r.b)(["language"]))
        }, d = (n(280), n(2)), component = Object(d.a)(l, (function () {
            var e = this, t = e.$createElement, o = e._self._c || t;
            return o("div", {staticClass: "warn-container"}, [o("img", {attrs: {src: n(279)}}), e._v(" "), o("span", {domProps: {innerHTML: e._s(e.$t("COMMON.LAYOUT.warn"))}}), e._v(" "), o("a", {
                staticClass: "learn",
                attrs: {href: e.$t("COMMON.LAYOUT.learnUrl"), target: "_blank"}
            }, [e._v(e._s(e.$t("COMMON.LAYOUT.goLearn")))])])
        }), [], !1, null, null, null);
        t.a = component.exports
    }, 102: function (e, t, n) {
        "use strict";
        n(111), n(103), n(52), n(11), n(24), n(50), n(38), n(9), n(51), n(53), n(54);
        var o = n(1);

        function r(e, t) {
            var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = function (e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return c(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return c(e, t)
                }(e)) || t && e && "number" == typeof e.length) {
                    n && (e = n);
                    var i = 0, o = function () {
                    };
                    return {
                        s: o, n: function () {
                            return i >= e.length ? {done: !0} : {done: !1, value: e[i++]}
                        }, e: function (e) {
                            throw e
                        }, f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, l = !0, d = !1;
            return {
                s: function () {
                    n = n.call(e)
                }, n: function () {
                    var e = n.next();
                    return l = e.done, e
                }, e: function (e) {
                    d = !0, r = e
                }, f: function () {
                    try {
                        l || null == n.return || n.return()
                    } finally {
                        if (d) throw r
                    }
                }
            }
        }

        function c(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var i = 0, n = new Array(t); i < t; i++) n[i] = e[i];
            return n
        }

        var l = window.requestIdleCallback || function (e) {
            var t = Date.now();
            return setTimeout((function () {
                e({
                    didTimeout: !1, timeRemaining: function () {
                        return Math.max(0, 50 - (Date.now() - t))
                    }
                })
            }), 1)
        }, d = window.cancelIdleCallback || function (e) {
            clearTimeout(e)
        }, m = window.IntersectionObserver && new window.IntersectionObserver((function (e) {
            e.forEach((function (e) {
                var t = e.intersectionRatio, link = e.target;
                t <= 0 || !link.__prefetch || link.__prefetch()
            }))
        }));
        t.a = {
            name: "NuxtLink",
            extends: o.default.component("RouterLink"),
            props: {prefetch: {type: Boolean, default: !0}, noPrefetch: {type: Boolean, default: !1}},
            mounted: function () {
                this.prefetch && !this.noPrefetch && (this.handleId = l(this.observe, {timeout: 2e3}))
            },
            beforeDestroy: function () {
                d(this.handleId), this.__observed && (m.unobserve(this.$el), delete this.$el.__prefetch)
            },
            methods: {
                observe: function () {
                    m && this.shouldPrefetch() && (this.$el.__prefetch = this.prefetchLink.bind(this), m.observe(this.$el), this.__observed = !0)
                }, shouldPrefetch: function () {
                    return this.getPrefetchComponents().length > 0
                }, canPrefetch: function () {
                    var e = navigator.connection;
                    return !(this.$nuxt.isOffline || e && ((e.effectiveType || "").includes("2g") || e.saveData))
                }, getPrefetchComponents: function () {
                    return this.$router.resolve(this.to, this.$route, this.append).resolved.matched.map((function (e) {
                        return e.components.default
                    })).filter((function (e) {
                        return "function" == typeof e && !e.options && !e.__prefetched
                    }))
                }, prefetchLink: function () {
                    if (this.canPrefetch()) {
                        m.unobserve(this.$el);
                        var e, t = r(this.getPrefetchComponents());
                        try {
                            for (t.s(); !(e = t.n()).done;) {
                                var n = e.value, o = n();
                                o instanceof Promise && o.catch((function () {
                                })), n.__prefetched = !0
                            }
                        } catch (e) {
                            t.e(e)
                        } finally {
                            t.f()
                        }
                    }
                }
            }
        }
    }, 143: function (e, t, n) {
        "use strict";
        var o = {};
        o.context = n(248), o.context = o.context.default || o.context, o.redirect = n(250), o.redirect = o.redirect.default || o.redirect, t.a = o
    }, 147: function (e, t, n) {
        "use strict";
        n(13), n(9), n(11), n(18), n(19);
        var o = n(3), r = n(10), c = n(36);

        function l(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function d(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? l(Object(source), !0).forEach((function (t) {
                    Object(o.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : l(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        var m = {
            data: function () {
                return {
                    form: {start: 0, count: 20, status: 0, lang: ""},
                    newsHasMore: !0,
                    newsDetailData: {},
                    activityList: [],
                    adList: []
                }
            }, computed: d(d({}, Object(r.b)(["language"])), {}, {
                lang: function () {
                    return "zh" === this.language ? "zh-Hans" : "en"
                }, isEn: function () {
                    return "en" === this.language
                }, telegramLink: function () {
                    return "zh" === this.language ? "https://t.me/bptokenpocket" : "https://t.me/tokenpocketadmin"
                }, telegramGM: function () {
                    return "zh" === this.language ? "Kevin | TokenPocket" : "Marcus | TokenPocket"
                }, blockchainList: function () {
                    return [{value: 1, title: this.$t("COMMON.platformInfo.eth"), type: "platform_eth"}, {
                        value: 12,
                        title: this.$t("COMMON.platformInfo.bsc"),
                        type: "platform_bsc"
                    }, {value: 15, title: this.$t("COMMON.platformInfo.heco"), type: "platform_heco"}, {
                        value: 20,
                        title: this.$t("COMMON.platformInfo.okex"),
                        type: "platform_okex"
                    }, {value: 10, title: this.$t("COMMON.platformInfo.trx"), type: "platform_trx"}, {
                        value: 19,
                        title: this.$t("COMMON.platformInfo.hsc"),
                        type: "platform_hsc"
                    }, {value: 4, title: this.$t("COMMON.platformInfo.eos"), type: "platform_eos"}, {
                        value: 7,
                        title: this.$t("COMMON.platformInfo.iost"),
                        type: "platform_iost"
                    }, {value: 13, title: this.$t("COMMON.platformInfo.dot"), type: "platform_dot"}, {
                        value: 18,
                        title: this.$t("COMMON.platformInfo.matic"),
                        type: "platform_matic"
                    }, {value: 22, title: this.$t("COMMON.platformInfo.klaytn"), type: "platform_klaytn"}, {
                        value: 8,
                        title: this.$t("COMMON.platformInfo.cosmos"),
                        type: "platform_cosmos"
                    }, {value: 6, title: this.$t("COMMON.platformInfo.bos"), type: "platform_bos"}, {
                        value: 3,
                        title: this.$t("COMMON.platformInfo.moac"),
                        type: "platform_moac"
                    }, {value: 2, title: this.$t("COMMON.platformInfo.jt"), type: "platform_jt"}, {
                        value: 9,
                        title: this.$t("COMMON.platformInfo.bnb"),
                        type: "platform_binance"
                    }, {value: 24, title: this.$t("COMMON.platformInfo.arb"), type: "platform_arb"}, {
                        value: 25,
                        title: this.$t("COMMON.platformInfo.ftm"),
                        type: "platform_ftm"
                    }, {value: 41, title: this.$t("COMMON.platformInfo.etc"), type: "platform_etc"}, {
                        value: 36,
                        title: this.$t("COMMON.platformInfo.cfx"),
                        type: "platform_cfx"
                    }, {value: 27, title: this.$t("COMMON.platformInfo.solana"), type: "platform_solana"}, {
                        value: 23,
                        title: this.$t("COMMON.platformInfo.avax"),
                        type: "platform_avax"
                    }, {value: 26, title: this.$t("COMMON.platformInfo.oe"), type: "platform_oe"}, {
                        value: 28,
                        title: this.$t("COMMON.platformInfo.xdai"),
                        type: "platform_xdai"
                    }, {value: 33, title: this.$t("COMMON.platformInfo.harmony"), type: "platform_harmony"}, {
                        value: 29,
                        title: this.$t("COMMON.platformInfo.wax"),
                        type: "platform_wax"
                    }, {value: 32, title: this.$t("COMMON.platformInfo.aurora"), type: "platform_aurora"}, {
                        value: 14,
                        title: this.$t("COMMON.platformInfo.ksm"),
                        type: "platform_ksm"
                    }, {value: 31, title: this.$t("COMMON.platformInfo.mb"), type: "platform_mb"}, {
                        value: 21,
                        title: this.$t("COMMON.platformInfo.sbg"),
                        type: "platform_sbg"
                    }, {value: 35, title: this.$t("COMMON.platformInfo.kcc"), type: "platform_kcc"}, {
                        value: 37,
                        title: this.$t("COMMON.platformInfo.lat"),
                        type: "platform_lat"
                    }, {value: 38, title: this.$t("COMMON.platformInfo.bttc"), type: "platform_bttc"}, {
                        value: 39,
                        title: this.$t("COMMON.platformInfo.gt"),
                        type: "platform_gt"
                    }, {value: 40, title: this.$t("COMMON.platformInfo.halo"), type: "platform_halo"}, {
                        value: 42,
                        title: this.$t("COMMON.platformInfo.arbn"),
                        type: "platform_arbn"
                    }, {value: 43, title: this.$t("COMMON.platformInfo.aptos"), type: "platform_aptos"}, {
                        value: 45,
                        title: this.$t("COMMON.platformInfo.fil"),
                        type: "platform_fil"
                    }, {value: 46, title: this.$t("COMMON.platformInfo.zks"), type: "platform_zks"}, {
                        value: 47,
                        title: this.$t("COMMON.platformInfo.eosevm"),
                        type: "platform_eosevm"
                    }, {value: 49, title: this.$t("COMMON.platformInfo.mantle"), type: "platform_mantle"}, {
                        value: 50,
                        title: this.$t("COMMON.platformInfo.linea"),
                        type: "platform_linea"
                    }, {value: 51, title: this.$t("COMMON.platformInfo.base"), type: "platform_base"}, {
                        value: 52,
                        title: this.$t("COMMON.platformInfo.opbnb"),
                        type: "platform_opbnb"
                    }, {value: 53, title: this.$t("COMMON.platformInfo.polyzk"), type: "platform_polyzk"}]
                }, evmList: function () {
                    return [{value: 1, title: this.$t("COMMON.platformInfo.eth"), type: "platform_eth"}, {
                        value: 12,
                        title: this.$t("COMMON.platformInfo.bsc"),
                        type: "platform_bsc"
                    }, {value: 15, title: this.$t("COMMON.platformInfo.heco"), type: "platform_heco"}, {
                        value: 19,
                        title: this.$t("COMMON.platformInfo.hsc"),
                        type: "platform_hsc"
                    }, {value: 18, title: this.$t("COMMON.platformInfo.matic"), type: "platform_matic"}, {
                        value: 25,
                        title: this.$t("COMMON.platformInfo.ftm"),
                        type: "platform_ftm"
                    }]
                }, createAccountUrl: function () {
                    return "https://account.tokenpocket.pro"
                }
            }), watch: {
                language: function () {
                    this.checkLanguage(), this.getAdList()
                }
            }, methods: {
                copy: function (e) {
                    var t = this;
                    this.$copyText(e).then((function (e) {
                    }), (function (e) {
                        t.$message.error("复制失败")
                    }))
                }, checkLanguage: function () {
                    "zh" === this.language ? this.form.lang = "zh-Hans" : this.form.lang = "en"
                }, getNews: function () {
                    var e = this;
                    this.form.start += 20, this.$axios.get(c.g, {params: this.form}).then((function (t) {
                        0 === t.data.result && (e.newsHasMore = null !== t.data.data, e.$store.dispatch("GET_NEWS_LIST", {
                            list: t.data.data,
                            reset: !1
                        }))
                    }))
                }, getActivity: function () {
                    var e = this;
                    this.$axios.get(c.a, {params: {start: 0, count: 5, lang: this.form.lang}}).then((function (t) {
                        0 === t.data.result && (e.activityList = t.data.data)
                    }))
                }, getAdList: function () {
                    var e = this;
                    this.$axios.get(c.b, {params: {start: 0, count: 5, lang: this.form.lang}}).then((function (t) {
                        0 === t.data.result && (null !== t.data.data ? e.adList = t.data.data : e.adList = [])
                    }))
                }, localLink: function (e, t) {
                    t.preventDefault(), this.$router.push(e)
                }
            }, created: function () {
                this.checkLanguage()
            }
        };
        t.a = m
    }, 148: function (e, t, n) {
        "use strict";
        var o = n(76), r = n(60), c = n(61),
            l = {name: "Layouts", components: {ContainerLayout: o.a, HeaderLayout: r.a, FooterLayout: c.a}},
            d = (n(304), n(2)), component = Object(d.a)(l, (function () {
                var e = this, t = e.$createElement, n = e._self._c || t;
                return n("div", {staticClass: "layout-wrap"}, [n("header-layout", {
                    attrs: {
                        "nav-title-color": "#000",
                        "arrow-class": "icon-down-333",
                        "lang-class": "icon-earth-mini"
                    }
                }), e._v(" "), e._t("default"), e._v(" "), n("footer-layout")], 2)
            }), [], !1, null, "5704d1f1", null);
        t.a = component.exports
    }, 176: function (e, t, n) {
    }, 177: function (e, t, n) {
    }, 178: function (e, t, n) {
    }, 179: function (e, t, n) {
    }, 180: function (e, t, n) {
        "use strict";
        n(34);
        t.a = {
            date: function () {
                return {}
            }, methods: {
                indexGo: function (e) {
                    this.$router.replace("/")
                }, linkGo: function (e) {
                    this.$router.push(this.$i18n.path(e))
                }
            }
        }
    }, 181: function (e, t, n) {
        e.exports = n.p + "img/logo.03b9a69.png"
    }, 182: function (e, t, n) {
    }, 183: function (e, t, n) {
    }, 184: function (e, t, n) {
    }, 185: function (e, t, n) {
    }, 186: function (e, t, n) {
    }, 192: function (e, t, n) {
    }, 193: function (e, t, n) {
    }, 212: function (e, t, n) {
        "use strict";
        var o = {props: {url: {type: String}}}, r = (n(272), n(2)), component = Object(r.a)(o, (function () {
            var e = this, t = e.$createElement, o = e._self._c || t;
            return o("div", {staticClass: "modal d-flex flex-column ai-center jc-center"}, [o("div", {staticClass: "modal-content d-flex ai-center jc-center"}, [o("div", {staticClass: "content"}, [o("img", {attrs: {src: n(270)}}), e._v(" "), o("div", {staticClass: "desc1"}, [e._v(e._s(e.$t("HOME.FOLLOW.desc1")))]), e._v(" "), o("div", {staticClass: "desc2"}, [e._v(e._s(e.$t("HOME.FOLLOW.desc2")))]), e._v(" "), o("a", {
                staticClass: "button",
                attrs: {href: e.url, target: "_blank"},
                on: {
                    click: function (t) {
                        return e.$emit("close")
                    }
                }
            }, [e._v("\n        " + e._s(e.$t("HOME.FOLLOW.desc3")) + "\n      ")])]), e._v(" "), o("img", {
                staticClass: "close",
                attrs: {src: n(271)},
                on: {
                    click: function (t) {
                        return e.$emit("close")
                    }
                }
            })])])
        }), [], !1, null, "257fc23f", null);
        t.a = component.exports
    }, 219: function (e, t, n) {
        "use strict";
        var o = n(6), r = (n(64), n(24), n(1)), c = n(0), l = window.__NUXT__;

        function d() {
            if (!this._hydrated) return this.$fetch()
        }

        function m() {
            if ((e = this).$vnode && e.$vnode.elm && e.$vnode.elm.dataset && e.$vnode.elm.dataset.fetchKey) {
                var e;
                this._hydrated = !0, this._fetchKey = this.$vnode.elm.dataset.fetchKey;
                var data = l.fetch[this._fetchKey];
                if (data && data._error) this.$fetchState.error = data._error; else for (var t in data) r.default.set(this.$data, t, data[t])
            }
        }

        function h() {
            var e = this;
            return this._fetchPromise || (this._fetchPromise = T.call(this).then((function () {
                delete e._fetchPromise
            }))), this._fetchPromise
        }

        function T() {
            return f.apply(this, arguments)
        }

        function f() {
            return (f = Object(o.a)(regeneratorRuntime.mark((function e() {
                var t, n, o, r = this;
                return regeneratorRuntime.wrap((function (e) {
                    for (; ;) switch (e.prev = e.next) {
                        case 0:
                            return this.$nuxt.nbFetching++, this.$fetchState.pending = !0, this.$fetchState.error = null, this._hydrated = !1, t = null, n = Date.now(), e.prev = 6, e.next = 9, this.$options.fetch.call(this);
                        case 9:
                            e.next = 15;
                            break;
                        case 11:
                            e.prev = 11, e.t0 = e.catch(6), t = Object(c.p)(e.t0);
                        case 15:
                            if (!((o = this._fetchDelay - (Date.now() - n)) > 0)) {
                                e.next = 19;
                                break
                            }
                            return e.next = 19, new Promise((function (e) {
                                return setTimeout(e, o)
                            }));
                        case 19:
                            this.$fetchState.error = t, this.$fetchState.pending = !1, this.$fetchState.timestamp = Date.now(), this.$nextTick((function () {
                                return r.$nuxt.nbFetching--
                            }));
                        case 23:
                        case"end":
                            return e.stop()
                    }
                }), e, this, [[6, 11]])
            })))).apply(this, arguments)
        }

        t.a = {
            beforeCreate: function () {
                Object(c.l)(this) && (this._fetchDelay = "number" == typeof this.$options.fetchDelay ? this.$options.fetchDelay : 200, r.default.util.defineReactive(this, "$fetchState", {
                    pending: !1,
                    error: null,
                    timestamp: Date.now()
                }), this.$fetch = h.bind(this), Object(c.a)(this, "created", m), Object(c.a)(this, "beforeMount", d))
            }
        }
    }, 223: function (e, t, n) {
        e.exports = n.p + "img/logo.5c68e3f.png"
    }, 224: function (e, t, n) {
        e.exports = n(225)
    }, 225: function (e, t, n) {
        "use strict";
        n.r(t), function (e) {
            n(50), n(9), n(51);
            var t = n(37), o = n(6),
                r = (n(163), n(235), n(243), n(245), n(64), n(38), n(11), n(13), n(111), n(103), n(52), n(53), n(24), n(54), n(1)),
                c = n(213), l = n(143), d = n(0), m = n(30), h = n(219), T = n(102);

            function f(e, t) {
                var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (!n) {
                    if (Array.isArray(e) || (n = function (e, t) {
                        if (!e) return;
                        if ("string" == typeof e) return k(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === n && e.constructor && (n = e.constructor.name);
                        if ("Map" === n || "Set" === n) return Array.from(e);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return k(e, t)
                    }(e)) || t && e && "number" == typeof e.length) {
                        n && (e = n);
                        var i = 0, o = function () {
                        };
                        return {
                            s: o, n: function () {
                                return i >= e.length ? {done: !0} : {done: !1, value: e[i++]}
                            }, e: function (e) {
                                throw e
                            }, f: o
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                var r, c = !0, l = !1;
                return {
                    s: function () {
                        n = n.call(e)
                    }, n: function () {
                        var e = n.next();
                        return c = e.done, e
                    }, e: function (e) {
                        l = !0, r = e
                    }, f: function () {
                        try {
                            c || null == n.return || n.return()
                        } finally {
                            if (l) throw r
                        }
                    }
                }
            }

            function k(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var i = 0, n = new Array(t); i < t; i++) n[i] = e[i];
                return n
            }

            r.default.__nuxt__fetch__mixin__ || (r.default.mixin(h.a), r.default.__nuxt__fetch__mixin__ = !0), r.default.component(T.a.name, T.a), r.default.component("NLink", T.a), e.fetch || (e.fetch = c.a);
            var y, O, _ = [], v = window.__NUXT__ || {}, A = v.config || {};
            A._app && (n.p = Object(d.v)(A._app.cdnURL, A._app.assetsPath)), Object.assign(r.default.config, {
                silent: !0,
                performance: !1
            });
            var C = r.default.config.errorHandler || console.error;

            function x(e, t, n) {
                for (var o = function (component) {
                    var e = function (component, e) {
                        if (!component || !component.options || !component.options[e]) return {};
                        var option = component.options[e];
                        if ("function" == typeof option) {
                            for (var t = arguments.length, n = new Array(t > 2 ? t - 2 : 0), o = 2; o < t; o++) n[o - 2] = arguments[o];
                            return option.apply(void 0, n)
                        }
                        return option
                    }(component, "transition", t, n) || {};
                    return "string" == typeof e ? {name: e} : e
                }, r = n ? Object(d.g)(n) : [], c = Math.max(e.length, r.length), l = [], m = function (i) {
                    var t = Object.assign({}, o(e[i])), n = Object.assign({}, o(r[i]));
                    Object.keys(t).filter((function (e) {
                        return void 0 !== t[e] && !e.toLowerCase().includes("leave")
                    })).forEach((function (e) {
                        n[e] = t[e]
                    })), l.push(n)
                }, i = 0; i < c; i++) m(i);
                return l
            }

            function P(e, t, n) {
                return w.apply(this, arguments)
            }

            function w() {
                return (w = Object(o.a)(regeneratorRuntime.mark((function e(t, n, o) {
                    var r, c, l, m, h = this;
                    return regeneratorRuntime.wrap((function (e) {
                        for (; ;) switch (e.prev = e.next) {
                            case 0:
                                if (this._routeChanged = Boolean(y.nuxt.err) || n.name !== t.name, this._paramChanged = !this._routeChanged && n.path !== t.path, this._queryChanged = !this._paramChanged && n.fullPath !== t.fullPath, this._diffQuery = this._queryChanged ? Object(d.i)(t.query, n.query) : [], (this._routeChanged || this._paramChanged) && this.$loading.start && !this.$loading.manual && this.$loading.start(), e.prev = 5, !this._queryChanged) {
                                    e.next = 12;
                                    break
                                }
                                return e.next = 9, Object(d.r)(t, (function (e, t) {
                                    return {Component: e, instance: t}
                                }));
                            case 9:
                                r = e.sent, r.some((function (e) {
                                    var o = e.Component, r = e.instance, c = o.options.watchQuery;
                                    return !0 === c || (Array.isArray(c) ? c.some((function (e) {
                                        return h._diffQuery[e]
                                    })) : "function" == typeof c && c.apply(r, [t.query, n.query]))
                                })) && this.$loading.start && !this.$loading.manual && this.$loading.start();
                            case 12:
                                o(), e.next = 26;
                                break;
                            case 15:
                                if (e.prev = 15, e.t0 = e.catch(5), c = e.t0 || {}, l = c.statusCode || c.status || c.response && c.response.status || 500, m = c.message || "", !/^Loading( CSS)? chunk (\d)+ failed\./.test(m)) {
                                    e.next = 23;
                                    break
                                }
                                return window.location.reload(!0), e.abrupt("return");
                            case 23:
                                this.error({statusCode: l, message: m}), this.$nuxt.$emit("routeChanged", t, n, c), o();
                            case 26:
                            case"end":
                                return e.stop()
                        }
                    }), e, this, [[5, 15]])
                })))).apply(this, arguments)
            }

            function E(e, t) {
                return v.serverRendered && t && Object(d.b)(e, t), e._Ctor = e, e
            }

            function S(e) {
                return Object(d.d)(e, function () {
                    var e = Object(o.a)(regeneratorRuntime.mark((function e(t, n, o, r, c) {
                        var l;
                        return regeneratorRuntime.wrap((function (e) {
                            for (; ;) switch (e.prev = e.next) {
                                case 0:
                                    if ("function" != typeof t || t.options) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.next = 3, t();
                                case 3:
                                    t = e.sent;
                                case 4:
                                    return l = E(Object(d.s)(t), v.data ? v.data[c] : null), o.components[r] = l, e.abrupt("return", l);
                                case 7:
                                case"end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function (t, n, o, r, c) {
                        return e.apply(this, arguments)
                    }
                }())
            }

            function D(e, t, n) {
                var o = this, r = ["context", "redirect"], c = !1;
                if (void 0 !== n && (r = [], (n = Object(d.s)(n)).options.middleware && (r = r.concat(n.options.middleware)), e.forEach((function (e) {
                    e.options.middleware && (r = r.concat(e.options.middleware))
                }))), r = r.map((function (e) {
                    return "function" == typeof e ? e : ("function" != typeof l.a[e] && (c = !0, o.error({
                        statusCode: 500,
                        message: "Unknown middleware " + e
                    })), l.a[e])
                })), !c) return Object(d.o)(r, t)
            }

            function N(e, t, n) {
                return M.apply(this, arguments)
            }

            function M() {
                return (M = Object(o.a)(regeneratorRuntime.mark((function e(t, n, r) {
                    var c, l, h, T, k, O, v, A, C, P, w, E, S, N, M, I = this;
                    return regeneratorRuntime.wrap((function (e) {
                        for (; ;) switch (e.prev = e.next) {
                            case 0:
                                if (!1 !== this._routeChanged || !1 !== this._paramChanged || !1 !== this._queryChanged) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", r());
                            case 2:
                                return !1, t === n ? (_ = [], !0) : (c = [], _ = Object(d.g)(n, c).map((function (e, i) {
                                    return Object(d.c)(n.matched[c[i]].path)(n.params)
                                }))), l = !1, h = function (path) {
                                    n.path === path.path && I.$loading.finish && I.$loading.finish(), n.path !== path.path && I.$loading.pause && I.$loading.pause(), l || (l = !0, r(path))
                                }, e.next = 8, Object(d.t)(y, {route: t, from: n, next: h.bind(this)});
                            case 8:
                                if (this._dateLastError = y.nuxt.dateErr, this._hadError = Boolean(y.nuxt.err), T = [], (k = Object(d.g)(t, T)).length) {
                                    e.next = 27;
                                    break
                                }
                                return e.next = 15, D.call(this, k, y.context);
                            case 15:
                                if (!l) {
                                    e.next = 17;
                                    break
                                }
                                return e.abrupt("return");
                            case 17:
                                return O = (m.a.options || m.a).layout, e.next = 20, this.loadLayout("function" == typeof O ? O.call(m.a, y.context) : O);
                            case 20:
                                return v = e.sent, e.next = 23, D.call(this, k, y.context, v);
                            case 23:
                                if (!l) {
                                    e.next = 25;
                                    break
                                }
                                return e.abrupt("return");
                            case 25:
                                return y.context.error({
                                    statusCode: 404,
                                    message: "This page could not be found"
                                }), e.abrupt("return", r());
                            case 27:
                                return k.forEach((function (e) {
                                    e._Ctor && e._Ctor.options && (e.options.asyncData = e._Ctor.options.asyncData, e.options.fetch = e._Ctor.options.fetch)
                                })), this.setTransitions(x(k, t, n)), e.prev = 29, e.next = 32, D.call(this, k, y.context);
                            case 32:
                                if (!l) {
                                    e.next = 34;
                                    break
                                }
                                return e.abrupt("return");
                            case 34:
                                if (!y.context._errored) {
                                    e.next = 36;
                                    break
                                }
                                return e.abrupt("return", r());
                            case 36:
                                return "function" == typeof (A = k[0].options.layout) && (A = A(y.context)), e.next = 40, this.loadLayout(A);
                            case 40:
                                return A = e.sent, e.next = 43, D.call(this, k, y.context, A);
                            case 43:
                                if (!l) {
                                    e.next = 45;
                                    break
                                }
                                return e.abrupt("return");
                            case 45:
                                if (!y.context._errored) {
                                    e.next = 47;
                                    break
                                }
                                return e.abrupt("return", r());
                            case 47:
                                C = !0, e.prev = 48, P = f(k), e.prev = 50, P.s();
                            case 52:
                                if ((w = P.n()).done) {
                                    e.next = 63;
                                    break
                                }
                                if ("function" == typeof (E = w.value).options.validate) {
                                    e.next = 56;
                                    break
                                }
                                return e.abrupt("continue", 61);
                            case 56:
                                return e.next = 58, E.options.validate(y.context);
                            case 58:
                                if (C = e.sent) {
                                    e.next = 61;
                                    break
                                }
                                return e.abrupt("break", 63);
                            case 61:
                                e.next = 52;
                                break;
                            case 63:
                                e.next = 68;
                                break;
                            case 65:
                                e.prev = 65, e.t0 = e.catch(50), P.e(e.t0);
                            case 68:
                                return e.prev = 68, P.f(), e.finish(68);
                            case 71:
                                e.next = 77;
                                break;
                            case 73:
                                return e.prev = 73, e.t1 = e.catch(48), this.error({
                                    statusCode: e.t1.statusCode || "500",
                                    message: e.t1.message
                                }), e.abrupt("return", r());
                            case 77:
                                if (C) {
                                    e.next = 80;
                                    break
                                }
                                return this.error({
                                    statusCode: 404,
                                    message: "This page could not be found"
                                }), e.abrupt("return", r());
                            case 80:
                                return e.next = 82, Promise.all(k.map(function () {
                                    var e = Object(o.a)(regeneratorRuntime.mark((function e(o, i) {
                                        var r, c, l, m, h, f, k, O, p;
                                        return regeneratorRuntime.wrap((function (e) {
                                            for (; ;) switch (e.prev = e.next) {
                                                case 0:
                                                    if (o._path = Object(d.c)(t.matched[T[i]].path)(t.params), o._dataRefresh = !1, r = o._path !== _[i], I._routeChanged && r ? o._dataRefresh = !0 : I._paramChanged && r ? (c = o.options.watchParam, o._dataRefresh = !1 !== c) : I._queryChanged && (!0 === (l = o.options.watchQuery) ? o._dataRefresh = !0 : Array.isArray(l) ? o._dataRefresh = l.some((function (e) {
                                                        return I._diffQuery[e]
                                                    })) : "function" == typeof l && (S || (S = Object(d.h)(t)), o._dataRefresh = l.apply(S[i], [t.query, n.query]))), I._hadError || !I._isMounted || o._dataRefresh) {
                                                        e.next = 6;
                                                        break
                                                    }
                                                    return e.abrupt("return");
                                                case 6:
                                                    return m = [], h = o.options.asyncData && "function" == typeof o.options.asyncData, f = Boolean(o.options.fetch) && o.options.fetch.length, k = h && f ? 30 : 45, h && ((O = Object(d.q)(o.options.asyncData, y.context)).then((function (e) {
                                                        Object(d.b)(o, e), I.$loading.increase && I.$loading.increase(k)
                                                    })), m.push(O)), I.$loading.manual = !1 === o.options.loading, f && ((p = o.options.fetch(y.context)) && (p instanceof Promise || "function" == typeof p.then) || (p = Promise.resolve(p)), p.then((function (e) {
                                                        I.$loading.increase && I.$loading.increase(k)
                                                    })), m.push(p)), e.abrupt("return", Promise.all(m));
                                                case 14:
                                                case"end":
                                                    return e.stop()
                                            }
                                        }), e)
                                    })));
                                    return function (t, n) {
                                        return e.apply(this, arguments)
                                    }
                                }()));
                            case 82:
                                l || (this.$loading.finish && !this.$loading.manual && this.$loading.finish(), r()), e.next = 99;
                                break;
                            case 85:
                                if (e.prev = 85, e.t2 = e.catch(29), "ERR_REDIRECT" !== (N = e.t2 || {}).message) {
                                    e.next = 90;
                                    break
                                }
                                return e.abrupt("return", this.$nuxt.$emit("routeChanged", t, n, N));
                            case 90:
                                return _ = [], Object(d.k)(N), "function" == typeof (M = (m.a.options || m.a).layout) && (M = M(y.context)), e.next = 96, this.loadLayout(M);
                            case 96:
                                this.error(N), this.$nuxt.$emit("routeChanged", t, n, N), r();
                            case 99:
                            case"end":
                                return e.stop()
                        }
                    }), e, this, [[29, 85], [48, 73], [50, 65, 68, 71]])
                })))).apply(this, arguments)
            }

            function I(e, n) {
                Object(d.d)(e, (function (e, n, o, c) {
                    return "object" !== Object(t.a)(e) || e.options || ((e = r.default.extend(e))._Ctor = e, o.components[c] = e), e
                }))
            }

            function L(e) {
                var t = Boolean(this.$options.nuxt.err);
                this._hadError && this._dateLastError === this.$options.nuxt.dateErr && (t = !1);
                var n = t ? (m.a.options || m.a).layout : e.matched[0].components.default.options.layout;
                "function" == typeof n && (n = n(y.context)), this.setLayout(n)
            }

            function B(e) {
                e._hadError && e._dateLastError === e.$options.nuxt.dateErr && e.error()
            }

            function R(e, t) {
                var n = this;
                if (!1 !== this._routeChanged || !1 !== this._paramChanged || !1 !== this._queryChanged) {
                    var o = Object(d.h)(e), c = Object(d.g)(e), l = !1;
                    r.default.nextTick((function () {
                        o.forEach((function (e, i) {
                            if (e && !e._isDestroyed && e.constructor._dataRefresh && c[i] === e.constructor && !0 !== e.$vnode.data.keepAlive && "function" == typeof e.constructor.options.data) {
                                var t = e.constructor.options.data.call(e);
                                for (var n in t) r.default.set(e.$data, n, t[n]);
                                l = !0
                            }
                        })), l && window.$nuxt.$nextTick((function () {
                            window.$nuxt.$emit("triggerScroll")
                        })), B(n)
                    }))
                }
            }

            function H(e) {
                window.onNuxtReadyCbs.forEach((function (t) {
                    "function" == typeof t && t(e)
                })), "function" == typeof window._onNuxtLoaded && window._onNuxtLoaded(e), O.afterEach((function (t, n) {
                    r.default.nextTick((function () {
                        return e.$nuxt.$emit("routeChanged", t, n)
                    }))
                }))
            }

            function U() {
                return (U = Object(o.a)(regeneratorRuntime.mark((function e(t) {
                    var n, o, c, l, m;
                    return regeneratorRuntime.wrap((function (e) {
                        for (; ;) switch (e.prev = e.next) {
                            case 0:
                                return y = t.app, O = t.router, t.store, n = new r.default(y), o = v.layout || "default", e.next = 7, n.loadLayout(o);
                            case 7:
                                return n.setLayout(o), c = function () {
                                    n.$mount("#__nuxt"), O.afterEach(I), O.afterEach(L.bind(n)), O.afterEach(R.bind(n)), r.default.nextTick((function () {
                                        H(n)
                                    }))
                                }, e.next = 11, Promise.all(S(y.context.route));
                            case 11:
                                if (l = e.sent, n.setTransitions = n.$options.nuxt.setTransitions.bind(n), l.length && (n.setTransitions(x(l, O.currentRoute)), _ = O.currentRoute.matched.map((function (e) {
                                    return Object(d.c)(e.path)(O.currentRoute.params)
                                }))), n.$loading = {}, v.error && n.error(v.error), O.beforeEach(P.bind(n)), O.beforeEach(N.bind(n)), !v.serverRendered || !Object(d.n)(v.routePath, n.context.route.path)) {
                                    e.next = 20;
                                    break
                                }
                                return e.abrupt("return", c());
                            case 20:
                                return m = function () {
                                    I(O.currentRoute, O.currentRoute), L.call(n, O.currentRoute), B(n), c()
                                }, e.next = 23, new Promise((function (e) {
                                    return setTimeout(e, 0)
                                }));
                            case 23:
                                N.call(n, O.currentRoute, O.currentRoute, (function (path) {
                                    if (path) {
                                        var e = O.afterEach((function (t, n) {
                                            e(), m()
                                        }));
                                        O.push(path, void 0, (function (e) {
                                            e && C(e)
                                        }))
                                    } else m()
                                }));
                            case 24:
                            case"end":
                                return e.stop()
                        }
                    }), e)
                })))).apply(this, arguments)
            }

            Object(m.b)(null, v.config).then((function (e) {
                return U.apply(this, arguments)
            })).catch(C)
        }.call(this, n(31))
    }, 248: function (e, t, n) {
        "use strict";
        n.r(t);
        n(115);
        t.default = function (e) {
            var t = e.isHMR, n = e.app, o = e.store, r = e.params, c = e.error, l = e.req, d = "en",
                m = ["zh", "zh-tw", "en", "ko", "ru", "es", "hi", "ja", "fil", "pt", "vi", "th"], h = function (e) {
                    var t = [];
                    e.split(",").forEach((function (e) {
                        t.push(e.split(";")[0].split("-")[0])
                    })), d = m.indexOf(t[0]) > -1 ? t[0] : -1 !== e.indexOf("zh") ? "zh" : d = -1 !== e.indexOf("ko") ? "ko" : "en"
                };
            if (l && l.headers["accept-language"] && h(l.headers["accept-language"]), l || h(navigator.language), !t) {
                var T = "en", f = r.lang && m.indexOf(r.lang) > -1;
                r.lang ? f ? T = r.lang : c({
                    message: "This page could not be found.",
                    statusCode: 404
                }) : T = d, (r.lang || "" === o.state.language) && o.commit("SET_LANGUAGE", T), n.i18n.locale = o.state.language
            }
        }
    }, 250: function (e, t, n) {
        "use strict";
        n.r(t), t.default = function (e) {
            var t = e.app, n = e.route, o = e.redirect;
            return n.fullPath === t.i18n.path("/download/ios") ? o({
                path: t.i18n.path("/download/app"),
                query: {ios: 1}
            }) : n.fullPath === t.i18n.path("/download/android") ? o({
                path: t.i18n.path("/download/app"),
                query: {android: 1}
            }) : void 0
        }
    }, 261: function (e, t, n) {
        e.exports = n.p + "img/logo.03b9a69.png"
    }, 262: function (e, t, n) {
        "use strict";
        n(176)
    }, 263: function (e, t, n) {
        "use strict";
        n(177)
    }, 266: function (e, t, n) {
    }, 267: function (e, t, n) {
    }, 268: function (e, t, n) {
    }, 269: function (e, t, n) {
        e.exports = n.p + "img/logo-w.7f84b51.png"
    }, 270: function (e, t, n) {
        e.exports = n.p + "img/modal-img.cf62ffa.png"
    }, 271: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAMAAACfWMssAAAAM1BMVEUAAACfoKWen6SdnaOfoaeenqWeoaSdoKaeoqWZoKGeoKWfoaWgoKSdoKWeoKafn5+eoKWEa/YkAAAAEHRSTlMA9+gnf0dUU0cf3m47p3sI6HHvBAAAAKxJREFUSMft0bsSgkAQBdFdZVXAx/z/1+qWQQdQTHUEAR3PSeaWs6M2qhOa6yNzQ32uuIhMDhFIXHSZuBV5D+SGi8u1SIlzEuckzkmckzgncU7inMQ5iXMS5yTOSZySDedk4JTEKYmTvf5wNoYd+oe085LdpWT3m5TsjnQOaR3SOCdxTuKcxDmJcxLnJM5JnJM4J984J1vFbclpLEvZXSJx1KafS2R3yz7lbOe+Ccsae4pM6ZYAAAAASUVORK5CYII="
    }, 272: function (e, t, n) {
        "use strict";
        n(178)
    }, 273: function (e, t, n) {
        "use strict";
        n(179)
    }, 274: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAMAAABg3Am1AAAASFBMVEUAAAAYICwYICgZICsZICwZICsaICwaICwTICgZICsZICsaICwZIC0aICwZICsZICoaICwXICoaICsbICwaICsZIC0ZICwaICzj7t+fAAAAF3RSTlMAQCCgv9/vgBBwX69Qz5Awf0/PkLCPwAaxKxMAAAJMSURBVEjHrVWJlhpBCOz7nEtX0///p+EIMjsz60uyy/NohaIoQdr8gJUp+x5C8HlyfxG9zWNn8/YeY8M4mf8a4joGJHyN9BghvoO0hCHWQdBix7AZQMV6hLer+CeFGwMR2SDAfMAXwIuitmM0xaWKPJDQMMDM9GoqlnURH1c8QEFOACuBgSSeEBu4HAlBFwM4zU0Qz096UZnFUwACBayoAj8CYKhySoCSW3FjPIwCCF8qdye5vYCWubNQkX1pKA48iYIrKO8vAjo7zzzkj/jUj7kQmVUCZrPLuLDFshP1CIHfcU01ex/g4Jfc1g9JRhSFDlm4VKseJpCnzkyHeURRUzGJAIRzEW8a90NFMD1JqSRKvZhOSNn6CEdApLRS3o0lrOal63EEBC3YsQhPRJLOHwDoFi+Vxw0RS6PzAdRXPn12PwjwDxb+B9BHsmJj/DqW1HclRQL4kYzYuBIdD+6s02LiuQ9d+7COkbVxMiXnPoRD48puNPrFaMgsaceCipBhVkAB9Vrw/TjeDUhPc37T8a6SJKis6qaWM7D7XCfrqk5aF3r9t6L7bM3J6HnlmoGoftnzuRVeiTv5uSa5DybnSENxtvXBFtsmBKSCg9NiHeshgCwU6yODgEBskuVDq0EBsgiJvpmdZUwgq+F6GefzuneyTQXg/qz7NdLuOCFGlQVHAAI3LkgEH6oad0f9eTKAfhi+WfPlpRjB422Btw0BdMlQeJrMpTlPv17Qa7cn6kxh/zXkZMGad+aWeR8dM2d/j5myDyF0n1sx37ffErJECjOw5M4AAAAASUVORK5CYII="
    }, 275: function (e, t, n) {
        "use strict";
        n(182)
    }, 276: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOsAAADICAMAAAA+7OZ/AAAAIVBMVEVHcEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAt9G3DAAAACnRSTlMAwEDz1hF4KaBVAppUBwAAAdBJREFUeNrt3UGO4zAMBVFKpCiZ9z/w9BiYGEGy7M3w17sBIduJFLhij50jvFrxGLnswx7Vk59l77L68nxb1KjWxrO0y6u5eA0b1d553asCUuMKvvmyH6ckpMay3tzMZomYZlki0uyUiCE0a5iNEuFa65pCs14l4pitEnGZzsNp6XxxOvbX0Nnn2C4BqbNZH/bPaT/qspfs/1x6zKi24rJ3K71airQvdp4zejm5DQAAAAAAAAAAAAAAAAAAAAAAAMCvW3u2spd9tXJ49fMtpJdeTXmKFANvY9vj8mrNr2dVJeJNMsE1X3Y7IvUmnZbGZTqNlDCh9s0WahqlUKvq0JbryJ2OHh29/9wQaremTpO3tk5rOezH9lJw6ezpwm4rqj3fdlO4iqfMf1T4tMca1Vhse3NFlU5cbh6vdvxcOr9dAQAAAAAAAAAAAAAAAAAAAAAAAPhtM8/o5Zxc9mmd+uHVzpgSFb2nLCfzRqj7tJftCu/l31bovK1+dCoEW6guEULVkNIwTSdpdEwnyxX37SpimXmJ2EKzTrNg1n62UDJw6Xy+DqEkb5pORm/pZPRSZ//qS+dcYiqdN6lk9HzKHJrGNpGMXlz2aeYIr1YictvjD/pR8ETvmrXFAAAAAElFTkSuQmCC"
    }, 277: function (e, t, n) {
        e.exports = n.p + "img/close.613ce25.png"
    }, 278: function (e, t, n) {
        "use strict";
        n(183)
    }, 279: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAArdJREFUWEfFl8+LTmEUxz/fRihmykJJwkLIwoKU5fgxSBFZTtkbs5CEEmpEZhQK4y9goeRHKfk1s1SyEprJSpKyUGYsSB0dzqtn7vvOe+97397uqbu5z3nO+T7ne348jygoZjYX2ALsBdYBS+NzC5/jewc8BMYk/SpiWnlKZrYEOAP0Az15+rH+HbgFDEn60mzPrADMbB5wCjgKLCjoOKv2A7gMnJf0s5GNhgDi1PeAzZlNk8B94CnwMcLuKk7HcqAP2Aeszux7CexvFI06AGa2HngELEuMvAaOS3pRJBJmthUYATYm+p+A3ZLepDZmAIiTv0qc/waOAKOSrIjzmo6Zue0B4CowJ/47iE1pJP4DCM7Hk7B/Aw5IGmvFcVbXzLxy7gKLYs3p6K3lRApgCDgdSn7yHc2cm9kK4Dbg5XlQ0vvZgAaIJ0kkzknyyuIvgAj9hyTbByXdaHZyM3NqroSOl9vZHP3DwPXQ8epY5VTUAIwCh2LRE855asp5CQDuy/Orlpg3JQ0oOtzXpMlsK5LtZrYSuBMU9Et6m5crUR3Pk2a12AHsBB7HzwlJa/MMtbNuZhNJn9jlAJxrLxeXEUknijows/lAlyTntJCY2bD3lFAedQBeZr3xo0/SsyKWzGwD4I2pC9gjyUs4V8xse3RS1x13AGlI1kjydpsrZnYMuBSKFyT53MgVM/M27T5dJh3AFLAwfnRLms618q90naqLoTss6WTBfe7LfbpMZwH0SKotNrXXBoBuwMe1y1Q7FJSNQB0FZZOwLIC6JCxVhm1QUFeGpRpRGwDqGpFPszKtuGUKGrZiT0UzKzOMWgIQF5T6YRQA/Obb6XE8CFyL8ps5jgNEdReSAODX8OquZAkV1VxKa3230mt5AsKTstHDxGv4QUcfJgmI6p5m6Ris7HGancWdep7/AdJ2mOXNV7+dAAAAAElFTkSuQmCC"
    }, 280: function (e, t, n) {
        "use strict";
        n(184)
    }, 281: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAYCAMAAAD9GTxlAAAAUVBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////8IN+deAAAAGnRSTlMA6OE1KibrooaemjDwjYqD9JlyFfpaH86pb9VaEwgAAAB6SURBVBjTZdBJFsMgDAPQMJkwBWjStNX9D1qyANzGu//8pIWW2z0/huslE/NDQCQ9qCtBbtPBix+ry6uZdv+m5nPaRoi8MxcQc7AHYl6YgWNSOwBDJhGKH78kEKvp2iSoaibhQ8+tlxSX6zqbaGjPrdMqNk5pYnyHji9BnAaCtCUeCQAAAABJRU5ErkJggg=="
    }, 282: function (e, t, n) {
        "use strict";
        n(185)
    }, 283: function (e, t, n) {
        "use strict";
        n(186)
    }, 284: function (e, t, n) {
        "use strict";
        n.r(t), n.d(t, "state", (function () {
            return k
        })), n.d(t, "getters", (function () {
            return y
        })), n.d(t, "mutations", (function () {
            return O
        })), n.d(t, "actions", (function () {
            return _
        }));
        var o = n(3), r = n(75), c = (n(34), n(11), n(13), n(9), n(18), n(19), n(47)), l = n.n(c), d = n(29),
            m = n.n(d), h = n(36);

        function T(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function f(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? T(Object(source), !0).forEach((function (t) {
                    Object(o.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : T(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        var k = function () {
            return {
                language: "",
                clientWidth: 0,
                newsForm: {start: 0, count: 20, status: 0, lang: "zh-Hans"},
                lang: "en",
                newsList: [],
                newsDate: [],
                newsDetailData: {},
                bannerList: [],
                categoryList: [],
                categoryId: null,
                dappForm: {start: 0, count: 500, key: "", status: 0, category_id: null, version: "10.0.0"},
                dappList: [],
                downloadPlatformIndex: 0
            }
        }, y = {
            language: function (e) {
                return e.language
            }, lang: function (e) {
                return e.lang
            }, clientWidth: function (e) {
                return e.clientWidth
            }, newsList: function (e) {
                return e.newsList
            }, newsDetailData: function (e) {
                return e.newsDetailData
            }, bannerList: function (e) {
                return e.bannerList
            }, categoryList: function (e) {
                return e.categoryList
            }, dappList: function (e) {
                return e.dappList
            }, downloadPlatformIndex: function (e) {
                return e.downloadPlatformIndex
            }
        }, O = {
            SET_LANGUAGE: function (e, t) {
                switch (e.language = t, e.language) {
                    case"zh":
                        e.lang = "zh-Hans";
                        break;
                    case"zh-tw":
                        e.lang = "zh-Hant";
                        break;
                    case"en":
                        e.lang = "en";
                        break;
                    case"ko":
                        e.lang = "ko";
                        break;
                    case"ru":
                        e.lang = "ru";
                        break;
                    case"es":
                        e.lang = "es";
                        break;
                    case"hi":
                        e.lang = "hi";
                        break;
                    case"fil":
                        e.lang = "fil";
                        break;
                    case"pt":
                        e.lang = "pt";
                        break;
                    case"ja":
                        e.lang = "ja";
                        break;
                    case"vi":
                        e.lang = "vi";
                        break;
                    case"th":
                        e.lang = "th";
                        break;
                    default:
                        e.lang = "en"
                }
            }, SET_DOWNLOADPLATFORMINDEX: function (e, t) {
                e.downloadPlatformIndex = t
            }, SET_CLIENT_WIDTH: function (e, t) {
                e.clientWidth = t
            }, NEWS_DATE: function (e, t) {
                t && (e.newsDate = t)
            }, NEWS_LIST: function (e, t) {
                Array.isArray(t.list) && (t.reset ? e.newsList = t.list : e.newsList = [].concat(Object(r.a)(e.newsList), Object(r.a)(t.list)))
            }, NEWS_DETAIL: function (e, t) {
                e.newsDetailData = t
            }, BANNER_LIST: function (e, t) {
                e.bannerList = t
            }, CATEGORY_LIST: function (e, t) {
                e.categoryList = t
            }, CATEGORY_ID: function (e, t) {
                e.dappForm.category_id = t
            }, COUNT_START: function (e) {
                e.dappForm.start += 40
            }, DAPP_LIST: function (e, t) {
                t.nextPage ? e.dappList = [].concat(Object(r.a)(e.dappList), Object(r.a)(t.list)) : e.dappList = t.list
            }
        }, _ = {
            GET_NEWS_LIST: function (e, t) {
                var n = e.commit;
                e.state;
                if (!t || Array.isArray(t.list)) {
                    var o = [], r = [], c = null;
                    t.list.forEach((function (e, t, n) {
                        e.create_time = e.create_time.replace(/[TZ]/g, " ");
                        var time = l()(e.create_time).format("YYYY-MM-DD");
                        -1 === o.indexOf(time) && o.push(time), e.days = l()(e.create_time).format("MM-DD"), e.times = l()(e.create_time).format("HH:mm")
                    })), n("NEWS_DATE", o), o.forEach((function (e) {
                        c = t.list.filter((function (t) {
                            return l()(t.create_time).format("YYYY-MM-DD") === e
                        })), r.push({time: e, list: c})
                    })), n("NEWS_LIST", {list: r, reset: t.reset})
                }
            }, GET_NEWS_DETAIL: function (e, t) {
                var n = e.commit;
                e.state;
                t && (t.create_time = t.create_time.replace(/[TZ]/g, " "), t.days = l()(t.create_time.substring(0, 10)).format("MM-DD"), t.times = l()(t.create_time.substring(0, t.create_time.length - 1)).format("HH:mm"), n("NEWS_DETAIL", t))
            }, GET_ACTIVITY: function (e, t) {
                e.commit, e.state
            }, GET_BANNER_LIST: function (e, t) {
                var n = e.commit, o = e.state;
                return m.a.get(h.c, {params: {start: 0, count: 10, lang: o.lang, status: 0}}).then((function (e) {
                    if (0 === e.data.result) {
                        var t = e.data.data.filter((function (data) {
                            return -1 !== data.object.url.indexOf("http")
                        }));
                        n("BANNER_LIST", t)
                    }
                }))
            }, GET_CATEGORY_LIST: function (e, t) {
                var n = e.commit, o = e.state;
                return m.a.get(h.d, {params: {lang: o.lang}}).then((function (e) {
                    if (0 === e.data.result) {
                        e.data.data.sort((function (a, b) {
                            return a.m_index - b.m_index
                        }));
                        var t = e.data.data.filter((function (data) {
                            return 0 === data.category_type
                        }));
                        n("CATEGORY_LIST", t), n("CATEGORY_ID", t[0].hid)
                    }
                }))
            }, GET_DAPP_LIST: function (e, t) {
                var n = e.commit, o = e.state;
                if (t) {
                    t.nextPage && n("COUNT_START"), t.id && n("CATEGORY_ID", t.id);
                    var form = f(f({}, o.dappForm), {}, {lang: o.lang});
                    return m.a.get(h.e, {params: form}).then((function (e) {
                        if (0 === e.data.result) {
                            var o = [];
                            Array.isArray(e.data.data) && (o = e.data.data.filter((function (data) {
                                return -1 !== data.url.indexOf("http")
                            }))), n("DAPP_LIST", {list: o, nextPage: t.nextPage})
                        }
                    }))
                }
            }
        }
    }, 30: function (e, t, n) {
        "use strict";
        n.d(t, "b", (function () {
            return Ie
        })), n.d(t, "a", (function () {
            return B
        }));
        n(13), n(9), n(11), n(18), n(19);
        var o = n(6), r = n(3), c = (n(64), n(38), n(52), n(24), n(34), n(1)), l = n(10), d = n(214), m = n(144),
            h = n.n(m), T = n(63), f = n.n(T), k = n(145), y = n(28), O = n(0);
        "scrollRestoration" in window.history && (Object(O.u)("manual"), window.addEventListener("beforeunload", (function () {
            Object(O.u)("auto")
        })), window.addEventListener("load", (function () {
            Object(O.u)("manual")
        })));

        function _(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function v(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? _(Object(source), !0).forEach((function (t) {
                    Object(r.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : _(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        var A = function () {
        };
        c.default.use(k.a);
        var C = {
            mode: "history",
            base: "/",
            linkActiveClass: "nuxt-link-active",
            linkExactActiveClass: "nuxt-link-exact-active",
            scrollBehavior: function (e, t, n) {
                var o = !1, r = e !== t;
                n ? o = n : r && function (e) {
                    var t = Object(O.g)(e);
                    if (1 === t.length) {
                        var n = t[0].options;
                        return !1 !== (void 0 === n ? {} : n).scrollToTop
                    }
                    return t.some((function (e) {
                        var t = e.options;
                        return t && t.scrollToTop
                    }))
                }(e) && (o = {x: 0, y: 0});
                var c = window.$nuxt;
                return (!r || e.path === t.path && e.hash !== t.hash) && c.$nextTick((function () {
                    return c.$emit("triggerScroll")
                })), new Promise((function (t) {
                    c.$once("triggerScroll", (function () {
                        if (e.hash) {
                            var n = e.hash;
                            void 0 !== window.CSS && void 0 !== window.CSS.escape && (n = "#" + window.CSS.escape(n.substr(1)));
                            try {
                                document.querySelector(n) && (o = {selector: n})
                            } catch (e) {
                                console.warn("Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).")
                            }
                        }
                        t(o)
                    }))
                }))
            },
            routes: [{
                path: "/404", component: function () {
                    return Object(O.m)(n.e(4).then(n.bind(null, 648)))
                }, name: "404"
            }, {
                path: "/", component: function () {
                    return Object(O.m)(Promise.all([n.e(1), n.e(0), n.e(19)]).then(n.bind(null, 658)))
                }, name: "index"
            }, {
                path: "/:lang", component: function () {
                    return Object(O.m)(Promise.all([n.e(1), n.e(0)]).then(n.bind(null, 642)))
                }, name: "lang"
            }, {
                path: "/:lang/about", component: function () {
                    return Object(O.m)(n.e(12).then(n.bind(null, 649)))
                }, name: "lang-about"
            }, {
                path: "/:lang/dapp", component: function () {
                    return Object(O.m)(n.e(13).then(n.bind(null, 643)))
                }, name: "lang-dapp"
            }, {
                path: "/:lang/developer", component: function () {
                    return Object(O.m)(n.e(14).then(n.bind(null, 650)))
                }, name: "lang-developer"
            }, {
                path: "/:lang/news", component: function () {
                    return Object(O.m)(n.e(16).then(n.bind(null, 645)))
                }, name: "lang-news"
            }, {
                path: "/:lang/partner", component: function () {
                    return Object(O.m)(n.e(17).then(n.bind(null, 651)))
                }, name: "lang-partner"
            }, {
                path: "/:lang/recruiting", component: function () {
                    return Object(O.m)(n.e(18).then(n.bind(null, 652)))
                }, name: "lang-recruiting"
            }, {
                path: "/:lang/news/:id", component: function () {
                    return Object(O.m)(n.e(15).then(n.bind(null, 646)))
                }, name: "lang-news-id"
            }, {
                path: "/:lang/:download/android", component: function () {
                    return Object(O.m)(n.e(5).then(n.bind(null, 653)))
                }, name: "lang-download-android"
            }, {
                path: "/:lang/:download/app", component: function () {
                    return Object(O.m)(n.e(6).then(n.bind(null, 644)))
                }, name: "lang-download-app"
            }, {
                path: "/:lang/:download/ios", component: function () {
                    return Object(O.m)(n.e(7).then(n.bind(null, 654)))
                }, name: "lang-download-ios"
            }, {
                path: "/:lang/:download/pc", component: function () {
                    return Object(O.m)(n.e(8).then(n.bind(null, 655)))
                }, name: "lang-download-pc"
            }, {
                path: "/:lang/:project/dapp", component: function () {
                    return Object(O.m)(n.e(9).then(n.bind(null, 647)))
                }, name: "lang-project-dapp"
            }, {
                path: "/:lang/:project/nft", component: function () {
                    return Object(O.m)(n.e(10).then(n.bind(null, 656)))
                }, name: "lang-project-nft"
            }, {
                path: "/:lang/:project/token", component: function () {
                    return Object(O.m)(n.e(11).then(n.bind(null, 657)))
                }, name: "lang-project-token"
            }],
            fallback: !1
        };

        function x(e, t) {
            var base = t._app && t._app.basePath || C.base, n = new k.a(v(v({}, C), {}, {base: base})), o = n.push;
            n.push = function (e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : A,
                    n = arguments.length > 2 ? arguments[2] : void 0;
                return o.call(this, e, t, n)
            };
            var r = n.resolve.bind(n);
            return n.resolve = function (e, t, n) {
                return "string" == typeof e && (e = Object(y.c)(e)), r(e, t, n)
            }, n
        }

        var P = {
                name: "NuxtChild",
                functional: !0,
                props: {
                    nuxtChildKey: {type: String, default: ""},
                    keepAlive: Boolean,
                    keepAliveProps: {type: Object, default: void 0}
                },
                render: function (e, t) {
                    var n = t.parent, data = t.data, o = t.props, r = n.$createElement;
                    data.nuxtChild = !0;
                    for (var c = n, l = n.$nuxt.nuxt.transitions, d = n.$nuxt.nuxt.defaultTransition, m = 0; n;) n.$vnode && n.$vnode.data.nuxtChild && m++, n = n.$parent;
                    data.nuxtChildDepth = m;
                    var h = l[m] || d, T = {};
                    w.forEach((function (e) {
                        void 0 !== h[e] && (T[e] = h[e])
                    }));
                    var f = {};
                    E.forEach((function (e) {
                        "function" == typeof h[e] && (f[e] = h[e].bind(c))
                    }));
                    var k = f.beforeEnter;
                    if (f.beforeEnter = function (e) {
                        if (window.$nuxt.$nextTick((function () {
                            window.$nuxt.$emit("triggerScroll")
                        })), k) return k.call(c, e)
                    }, !1 === h.css) {
                        var y = f.leave;
                        (!y || y.length < 2) && (f.leave = function (e, t) {
                            y && y.call(c, e), c.$nextTick(t)
                        })
                    }
                    var O = r("routerView", data);
                    return o.keepAlive && (O = r("keep-alive", {props: o.keepAliveProps}, [O])), r("transition", {
                        props: T,
                        on: f
                    }, [O])
                }
            },
            w = ["name", "mode", "appear", "css", "type", "duration", "enterClass", "leaveClass", "appearClass", "enterActiveClass", "enterActiveClass", "leaveActiveClass", "appearActiveClass", "enterToClass", "leaveToClass", "appearToClass"],
            E = ["beforeEnter", "enter", "afterEnter", "enterCancelled", "beforeLeave", "leave", "afterLeave", "leaveCancelled", "beforeAppear", "appear", "afterAppear", "appearCancelled"],
            S = ["/2018/01/18/sumbitnewtoken/index.html", "/2018/01/18/whatisprivatekey/index.html", "/contactus/", "/whatiskeystore/index.html", "/help/index.html", "/privacy/index.html", "/terms/index.html", "/release/ios.html", "/release/android.html", "/how-to-create-eos-account-by-friend/index.html", "/permission-intro/index.html", "/en/contactus/", "/en/whatiskeystore/index.html", "/en/help/index.html", "/en/privacy/index.html", "/en/terms/index.html", "/en/release/ios.html", "/en/release/android.html", "/en/how-to-create-eos-account-by-friend/index.html", "/en/permission-intro/index.html"],
            D = ["/download/ios", "/download/android"];

        function N(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function M(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? N(Object(source), !0).forEach((function (t) {
                    Object(r.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : N(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        var I = {
                name: "Error", props: {
                    error: {
                        type: Object, default: function () {
                            return {}
                        }
                    }
                }, data: function () {
                    return {isRedirect: !1}
                }, computed: M(M({}, Object(l.b)(["language"])), {}, {
                    navLogo: function () {
                        return n(261)
                    }
                }), created: function () {
                    this.redirect()
                }, layout: "blog", mounted: function () {
                }, methods: {
                    redirect: function () {
                        var path = this.$route.path.replace("/", "");
                        -1 !== S.indexOf(this.$route.path) ? (this.isRedirect = !0, location.href = "https://tp-web.cdn.bcebos.com/".concat(path)) : -1 !== D.indexOf(this.$route.path) ? (this.isRedirect = !0, this.$router.replace("/".concat(this.language, "/").concat(path))) : this.isRedirect = !1
                    }
                }
            }, L = (n(262), n(2)), B = Object(L.a)(I, (function () {
                var e = this, t = e.$createElement, n = e._self._c || t;
                return n("div", {}, [e.isRedirect || 404 != e.error.statusCode ? e._e() : n("div", [n("div", {staticClass: "error-404"}, [n("HeaderLayout", {
                    attrs: {
                        "nav-title-color": "#fff",
                        "nav-logo": e.navLogo,
                        "arrow-class": "icon-down-fff",
                        "lang-class": "icon-earth-mini"
                    }
                }), e._v(" "), n("a", {
                    staticClass: "home-button",
                    attrs: {href: "/"}
                }, [e._v(e._s(e.$t("COMMON.LAYOUT.toHome")))])], 1), e._v(" "), n("FooterLayout")], 1)])
            }), [], !1, null, "5eeeb828", null).exports, R = n(17), H = (n(118), n(119), {
                name: "Nuxt",
                components: {NuxtChild: P, NuxtError: B},
                props: {
                    nuxtChildKey: {type: String, default: void 0},
                    keepAlive: Boolean,
                    keepAliveProps: {type: Object, default: void 0},
                    name: {type: String, default: "default"}
                },
                errorCaptured: function (e) {
                    this.displayingNuxtError && (this.errorFromNuxtError = e, this.$forceUpdate())
                },
                computed: {
                    routerViewKey: function () {
                        if (void 0 !== this.nuxtChildKey || this.$route.matched.length > 1) return this.nuxtChildKey || Object(O.c)(this.$route.matched[0].path)(this.$route.params);
                        var e = Object(R.a)(this.$route.matched, 1)[0];
                        if (!e) return this.$route.path;
                        var t = e.components.default;
                        if (t && t.options) {
                            var n = t.options;
                            if (n.key) return "function" == typeof n.key ? n.key(this.$route) : n.key
                        }
                        return /\/$/.test(e.path) ? this.$route.path : this.$route.path.replace(/\/$/, "")
                    }
                },
                beforeCreate: function () {
                    c.default.util.defineReactive(this, "nuxt", this.$root.$options.nuxt)
                },
                render: function (e) {
                    var t = this;
                    return this.nuxt.err ? this.errorFromNuxtError ? (this.$nextTick((function () {
                        return t.errorFromNuxtError = !1
                    })), e("div", {}, [e("h2", "An error occurred while showing the error page"), e("p", "Unfortunately an error occurred and while showing the error page another error occurred"), e("p", "Error details: ".concat(this.errorFromNuxtError.toString())), e("nuxt-link", {props: {to: "/"}}, "Go back to home")])) : (this.displayingNuxtError = !0, this.$nextTick((function () {
                        return t.displayingNuxtError = !1
                    })), e(B, {props: {error: this.nuxt.err}})) : e("NuxtChild", {
                        key: this.routerViewKey,
                        props: this.$props
                    })
                }
            }), U = (n(50), n(51), n(53), n(54), {
                name: "NuxtLoading", data: function () {
                    return {
                        percent: 0,
                        show: !1,
                        canSucceed: !0,
                        reversed: !1,
                        skipTimerCount: 0,
                        rtl: !1,
                        throttle: 200,
                        duration: 5e3,
                        continuous: !1
                    }
                }, computed: {
                    left: function () {
                        return !(!this.continuous && !this.rtl) && (this.rtl ? this.reversed ? "0px" : "auto" : this.reversed ? "auto" : "0px")
                    }
                }, beforeDestroy: function () {
                    this.clear()
                }, methods: {
                    clear: function () {
                        clearInterval(this._timer), clearTimeout(this._throttle), this._timer = null
                    }, start: function () {
                        var e = this;
                        return this.clear(), this.percent = 0, this.reversed = !1, this.skipTimerCount = 0, this.canSucceed = !0, this.throttle ? this._throttle = setTimeout((function () {
                            return e.startTimer()
                        }), this.throttle) : this.startTimer(), this
                    }, set: function (e) {
                        return this.show = !0, this.canSucceed = !0, this.percent = Math.min(100, Math.max(0, Math.floor(e))), this
                    }, get: function () {
                        return this.percent
                    }, increase: function (e) {
                        return this.percent = Math.min(100, Math.floor(this.percent + e)), this
                    }, decrease: function (e) {
                        return this.percent = Math.max(0, Math.floor(this.percent - e)), this
                    }, pause: function () {
                        return clearInterval(this._timer), this
                    }, resume: function () {
                        return this.startTimer(), this
                    }, finish: function () {
                        return this.percent = this.reversed ? 0 : 100, this.hide(), this
                    }, hide: function () {
                        var e = this;
                        return this.clear(), setTimeout((function () {
                            e.show = !1, e.$nextTick((function () {
                                e.percent = 0, e.reversed = !1
                            }))
                        }), 500), this
                    }, fail: function (e) {
                        return this.canSucceed = !1, this
                    }, startTimer: function () {
                        var e = this;
                        this.show || (this.show = !0), void 0 === this._cut && (this._cut = 1e4 / Math.floor(this.duration)), this._timer = setInterval((function () {
                            e.skipTimerCount > 0 ? e.skipTimerCount-- : (e.reversed ? e.decrease(e._cut) : e.increase(e._cut), e.continuous && (e.percent >= 100 || e.percent <= 0) && (e.skipTimerCount = 1, e.reversed = !e.reversed))
                        }), 100)
                    }
                }, render: function (e) {
                    var t = e(!1);
                    return this.show && (t = e("div", {
                        staticClass: "nuxt-progress",
                        class: {
                            "nuxt-progress-notransition": this.skipTimerCount > 0,
                            "nuxt-progress-failed": !this.canSucceed
                        },
                        style: {width: this.percent + "%", left: this.left}
                    })), t
                }
            }), W = (n(263), Object(L.a)(U, undefined, undefined, !1, null, null, null).exports),
            j = (n(264), n(265), n(266), n(267), n(268), {
                components: {}, mounted: function () {
                }, methods: {}
            }), F = Object(L.a)(j, (function () {
                var e = this.$createElement, t = this._self._c || e;
                return t("div", [t("nuxt")], 1)
            }), [], !1, null, null, null).exports, $ = n(61), G = n(60), V = n(100), K = n(59), z = n(62), Y = n(101);

        function X(e, t) {
            var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = function (e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return J(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return J(e, t)
                }(e)) || t && e && "number" == typeof e.length) {
                    n && (e = n);
                    var i = 0, o = function () {
                    };
                    return {
                        s: o, n: function () {
                            return i >= e.length ? {done: !0} : {done: !1, value: e[i++]}
                        }, e: function (e) {
                            throw e
                        }, f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, c = !0, l = !1;
            return {
                s: function () {
                    n = n.call(e)
                }, n: function () {
                    var e = n.next();
                    return c = e.done, e
                }, e: function (e) {
                    l = !0, r = e
                }, f: function () {
                    try {
                        c || null == n.return || n.return()
                    } finally {
                        if (l) throw r
                    }
                }
            }
        }

        function J(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var i = 0, n = new Array(t); i < t; i++) n[i] = e[i];
            return n
        }

        var Z = {
            _default: Object(O.s)(F),
            _FooterLayout: Object(O.s)($.a),
            "_Header/index": Object(O.s)(G.a),
            "_Header/mini": Object(O.s)(V.a),
            "_Header/NavIndex": Object(O.s)(K.a),
            "_Header/normal": Object(O.s)(z.a),
            "_Header/warn": Object(O.s)(Y.a)
        }, Q = {
            render: function (e, t) {
                var n = e("NuxtLoading", {ref: "loading"}), o = e(this.layout || "nuxt"),
                    r = e("div", {domProps: {id: "__layout"}, key: this.layoutName}, [o]), c = e("transition", {
                        props: {name: "layout", mode: "out-in"}, on: {
                            beforeEnter: function (e) {
                                window.$nuxt.$nextTick((function () {
                                    window.$nuxt.$emit("triggerScroll")
                                }))
                            }
                        }
                    }, [r]);
                return e("div", {domProps: {id: "__nuxt"}}, [n, c])
            }, data: function () {
                return {isOnline: !0, layout: null, layoutName: "", nbFetching: 0}
            }, beforeCreate: function () {
                c.default.util.defineReactive(this, "nuxt", this.$options.nuxt)
            }, created: function () {
                this.$root.$options.$nuxt = this, window.$nuxt = this, this.refreshOnlineStatus(), window.addEventListener("online", this.refreshOnlineStatus), window.addEventListener("offline", this.refreshOnlineStatus), this.error = this.nuxt.error, this.context = this.$options.context
            }, mounted: function () {
                var e = this;
                return Object(o.a)(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function (t) {
                        for (; ;) switch (t.prev = t.next) {
                            case 0:
                                e.$loading = e.$refs.loading;
                            case 1:
                            case"end":
                                return t.stop()
                        }
                    }), t)
                })))()
            }, watch: {"nuxt.err": "errorChanged"}, computed: {
                isOffline: function () {
                    return !this.isOnline
                }, isFetching: function () {
                    return this.nbFetching > 0
                }
            }, methods: {
                refreshOnlineStatus: function () {
                    void 0 === window.navigator.onLine ? this.isOnline = !0 : this.isOnline = window.navigator.onLine
                }, refresh: function () {
                    var e = this;
                    return Object(o.a)(regeneratorRuntime.mark((function t() {
                        var n, o;
                        return regeneratorRuntime.wrap((function (t) {
                            for (; ;) switch (t.prev = t.next) {
                                case 0:
                                    if ((n = Object(O.h)(e.$route)).length) {
                                        t.next = 3;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 3:
                                    return e.$loading.start(), o = n.map((function (t) {
                                        var p = [];
                                        if (t.$options.fetch && t.$options.fetch.length && p.push(Object(O.q)(t.$options.fetch, e.context)), t.$fetch) p.push(t.$fetch()); else {
                                            var n, o = X(Object(O.e)(t.$vnode.componentInstance));
                                            try {
                                                for (o.s(); !(n = o.n()).done;) {
                                                    var component = n.value;
                                                    p.push(component.$fetch())
                                                }
                                            } catch (e) {
                                                o.e(e)
                                            } finally {
                                                o.f()
                                            }
                                        }
                                        return t.$options.asyncData && p.push(Object(O.q)(t.$options.asyncData, e.context).then((function (e) {
                                            for (var n in e) c.default.set(t.$data, n, e[n])
                                        }))), Promise.all(p)
                                    })), t.prev = 5, t.next = 8, Promise.all(o);
                                case 8:
                                    t.next = 15;
                                    break;
                                case 10:
                                    t.prev = 10, t.t0 = t.catch(5), e.$loading.fail(t.t0), Object(O.k)(t.t0), e.error(t.t0);
                                case 15:
                                    e.$loading.finish();
                                case 16:
                                case"end":
                                    return t.stop()
                            }
                        }), t, null, [[5, 10]])
                    })))()
                }, errorChanged: function () {
                    if (this.nuxt.err) {
                        this.$loading && (this.$loading.fail && this.$loading.fail(this.nuxt.err), this.$loading.finish && this.$loading.finish());
                        var e = (B.options || B).layout;
                        "function" == typeof e && (e = e(this.context)), this.setLayout(e)
                    }
                }, setLayout: function (e) {
                    return e && Z["_" + e] || (e = "default"), this.layoutName = e, this.layout = Z["_" + e], this.layout
                }, loadLayout: function (e) {
                    return e && Z["_" + e] || (e = "default"), Promise.resolve(Z["_" + e])
                }
            }, components: {NuxtLoading: W}
        };
        c.default.use(l.a);
        var ee = {};
        (ee = function (e, t) {
            if ((e = e.default || e).commit) throw new Error("[nuxt] ".concat(t, " should export a method that returns a Vuex instance."));
            return "function" != typeof e && (e = Object.assign({}, e)), function (e, t) {
                if (e.state && "function" != typeof e.state) {
                    console.warn("'state' should be a method that returns an object in ".concat(t));
                    var n = Object.assign({}, e.state);
                    e = Object.assign({}, e, {
                        state: function () {
                            return n
                        }
                    })
                }
                return e
            }(e, t)
        }(n(284), "store/index.js")).modules = ee.modules || {};
        var te = ee instanceof Function ? ee : function () {
            return new l.a.Store(Object.assign({strict: !1}, ee))
        };
        var ae = n(29), ne = n.n(ae);

        function oe(e, t) {
            var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = function (e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return ie(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === n && e.constructor && (n = e.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ie(e, t)
                }(e)) || t && e && "number" == typeof e.length) {
                    n && (e = n);
                    var i = 0, o = function () {
                    };
                    return {
                        s: o, n: function () {
                            return i >= e.length ? {done: !0} : {done: !1, value: e[i++]}
                        }, e: function (e) {
                            throw e
                        }, f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var r, c = !0, l = !1;
            return {
                s: function () {
                    n = n.call(e)
                }, n: function () {
                    var e = n.next();
                    return c = e.done, e
                }, e: function (e) {
                    l = !0, r = e
                }, f: function () {
                    try {
                        c || null == n.return || n.return()
                    } finally {
                        if (l) throw r
                    }
                }
            }
        }

        function ie(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var i = 0, n = new Array(t); i < t; i++) n[i] = e[i];
            return n
        }

        for (var re = {
            setBaseURL: function (e) {
                this.defaults.baseURL = e
            }, setHeader: function (e, t) {
                var n, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "common",
                    r = oe(Array.isArray(o) ? o : [o]);
                try {
                    for (r.s(); !(n = r.n()).done;) {
                        var c = n.value;
                        if (!t) return void delete this.defaults.headers[c][e];
                        this.defaults.headers[c][e] = t
                    }
                } catch (e) {
                    r.e(e)
                } finally {
                    r.f()
                }
            }, setToken: function (e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "common",
                    o = e ? (t ? t + " " : "") + e : null;
                this.setHeader("Authorization", o, n)
            }, onRequest: function (e) {
                this.interceptors.request.use((function (t) {
                    return e(t) || t
                }))
            }, onResponse: function (e) {
                this.interceptors.response.use((function (t) {
                    return e(t) || t
                }))
            }, onRequestError: function (e) {
                this.interceptors.request.use(void 0, (function (t) {
                    return e(t) || Promise.reject(t)
                }))
            }, onResponseError: function (e) {
                this.interceptors.response.use(void 0, (function (t) {
                    return e(t) || Promise.reject(t)
                }))
            }, onError: function (e) {
                this.onRequestError(e), this.onResponseError(e)
            }
        }, se = function () {
            var e = le[ce];
            re["$" + e] = function () {
                return this[e].apply(this, arguments).then((function (e) {
                    return e && e.data
                }))
            }
        }, ce = 0, le = ["request", "delete", "get", "head", "options", "post", "put", "patch"]; ce < le.length; ce++) se();
        var ue = function (e, t) {
            var n = {
                baseURL: "http://localhost:3000/",
                headers: {
                    common: {Accept: "application/json, text/plain, */*"},
                    delete: {},
                    get: {},
                    head: {},
                    post: {},
                    put: {},
                    patch: {}
                }
            };
            n.headers.common = e.req && e.req.headers ? Object.assign({}, e.req.headers) : {}, delete n.headers.common.accept, delete n.headers.common.host, delete n.headers.common["cf-ray"], delete n.headers.common["cf-connecting-ip"], delete n.headers.common["content-length"], delete n.headers.common["content-md5"], delete n.headers.common["content-type"];
            var o = ne.a.create(n);
            o.CancelToken = ne.a.CancelToken, o.isCancel = ne.a.isCancel, function (e) {
                for (var t in re) e[t] = re[t].bind(e)
            }(o), function (e, t) {
                var n = {
                    finish: function () {
                    }, start: function () {
                    }, fail: function () {
                    }, set: function () {
                    }
                }, o = function () {
                    return window.$nuxt && window.$nuxt.$loading && window.$nuxt.$loading.set ? window.$nuxt.$loading : n
                }, r = 0;
                e.onRequest((function (e) {
                    e && !1 === e.progress || r++
                })), e.onResponse((function (e) {
                    e && e.config && !1 === e.config.progress || --r <= 0 && (r = 0, o().finish())
                })), e.onError((function (e) {
                    e && e.config && !1 === e.config.progress || (r--, ne.a.isCancel(e) || (o().fail(), o().finish()))
                }));
                var c = function (e) {
                    if (r) {
                        var progress = 100 * e.loaded / (e.total * r);
                        o().set(Math.min(100, progress))
                    }
                };
                e.defaults.onUploadProgress = c, e.defaults.onDownloadProgress = c
            }(o), e.$axios = o, t("axios", o)
        }, de = n(216), pe = n.n(de);
        n(302);
        c.default.use(pe.a);
        var me = n(76), he = n(148);
        c.default.component("ContainerLayout", me.a), c.default.component("HeaderLayout", G.a), c.default.component("FooterLayout", $.a), c.default.component("Layout", he.a);
        var ge = n(146), Te = {
            zh: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "批量转账",
                    YES: "是",
                    NO: "否",
                    HAS: "有",
                    HAVENT: "没有",
                    BLOCKCHAIN: "项目网络",
                    MULTIPLE_CHOICE: "(可多选)",
                    IS_SUPPORT_TP_CONNECT: "是否支持TokenPocket连接（包括移动端和插件端）",
                    SUPPORT_BOTH: "均已支持",
                    SUPPORT_EXTENSION: "仅支持插件端",
                    SUPPORT_MOBILE: "仅支持移动端",
                    SUPPORT_NONE: "均未支持",
                    blockchainWallet: "区块链钱包",
                    iostWallet: "IOST钱包",
                    tronWallet: "TRON钱包",
                    platformInfo: {
                        eos: "EOS",
                        moac: "墨客",
                        eth: "以太坊",
                        jt: "井通",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "币安智能链",
                        heco: "火币生态链",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "虎符智能链",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "提交",
                    symbol: "代币符号（如：AAA）",
                    success: "成功",
                    bl_symbol: "网络代码",
                    precision: "代币小数位",
                    decimal: "精度（如：18）",
                    totalSupply: "代币数量",
                    contract: "合约地址（如：itokenpocket）",
                    website: "官方网址（如：https://www.tokenpocket.pro）",
                    introduction: "项目简介",
                    example: "示例",
                    submitTokenInfoAndLogo: "提交代币信息及logo",
                    toGithubSubmit: "跳转至Github提交",
                    nftType: "NFT类型",
                    LAYOUT: {
                        features: "功能",
                        buyCrypto: "购买加密资产",
                        mobileWallet: "手机钱包",
                        hardwareWallet: "硬件钱包",
                        extensionWallet: "插件钱包",
                        desktop: "桌面端钱包",
                        fiveDegrees: "5Degrees",
                        versionVerification: "版本校验",
                        approvalDetector: "授权检测",
                        tokenSecurity: "代币安全检测",
                        keyGenerator: "私钥生成器",
                        information: "信息",
                        blockchainGuide: "区块链小白书",
                        tronWallet: "波场小白书",
                        iostWallet: "IOST小白书",
                        tpMan: "TP侠",
                        developers: "开发者",
                        github: "Github (TP-Lab)",
                        devCenter: "开发者中心",
                        subToken: "提交代币",
                        subDApp: "提交DApp",
                        subNFT: "提交NFT",
                        subChain: "提交公链",
                        company: "公司",
                        about: "关于",
                        careers: "招聘",
                        pressKit: "品牌素材",
                        swagShop: "周边商店",
                        support: "支持",
                        helpCenter: "帮助中心",
                        contactUs: "联系我们",
                        legal: "法律",
                        privacyPolicy: "隐私策略",
                        terms: "服务协议",
                        toHome: "返回首页",
                        defiWallet: "DeFi钱包",
                        ETHWallet: "以太坊錢包",
                        ethWallet: "ETH钱包"
                    }
                },
                HOME: {
                    download: "下载",
                    downloadNow: "立即下载",
                    HEADER: {title: "让区块链随处发生", desc_1: "让你安全、简单地探索区块链，是全球领先的数字资产钱包"},
                    INTRODUCTION: {
                        title: "TokenPocket深受全球用户信赖",
                        desc_1: "我们为全球200多个国家及地区的用户提供安全易用的数字资产服务",
                        desc_2: "服务的用户",
                        desc_3: "日均交易数",
                        desc_4: "国家及地区"
                    },
                    SECURITY: {
                        title: "安全是我们的根基",
                        desc_1: "TokenPocket只在用户的设备里生成并存储私钥助记词，您是唯一可以访问的人",
                        desc_2: "TokenPocket同时开发了冷钱包、多签钱包等，来满足您对安全的需求",
                        desc_3: "多链钱包，支持BTC、ETH、BSC、TRON、Aptos、Polygon、Solana、Cosmos、Polkadot、EOS、IOST等"
                    },
                    EXCHANGE: {
                        title: "兑换、交易更简单",
                        desc_1: "随时随地，让你更方便地交易",
                        desc_2: "用你的信用卡购入数字资产，轻松存储、发送、跨链与兑换",
                        desc_3: "闪兑",
                        desc_4: "简单快速",
                        desc_5: "跨链",
                        desc_6: "多链转换",
                        desc_7: "购入数字资产",
                        desc_8: "仅在5分钟内"
                    },
                    DAPPSTORE: {
                        title: "一站式DApp商店",
                        desc_1: "找到你最喜爱的去中心化应用，发现最新、最热的DApp，一切尽在TokenPocket",
                        desc_2: "集成DApp浏览器，您可以访问你的任何DApp链接",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "已支持"
                    },
                    COMMUNITY: {
                        title: "社区",
                        desc_1: "我们坚持开放性社区，始终如一！我们欢迎所有开发者一起开发更方便、更丰富的的区块链世界",
                        desc_2: "TP-Lab",
                        desc_3: "开发者社区",
                        desc_4: "开发者文档"
                    },
                    DOWNLOAD: {title: "现在就拥有您的TokenPocket!", desc_1: "安全可信赖的数字资产钱包，伴您探索区块链世界"},
                    FOLLOW: {
                        title: "关注我们",
                        desc1: "TokenPocket 客服不会私聊您！",
                        desc2: "请注意，您即将进入TokenPocket社区，您进入社区可能会有人假冒TokenPocket的工作人员私聊您，请您务必警惕，所有私聊您的都可能是骗子！TokenPocket工作人员不会主动跟您私信！",
                        desc3: "知道了，继续前往"
                    },
                    EXTENSIONMODAL: {
                        title: "Extension is now live!",
                        desc1: "Your Crypto & DeFi & GameFi",
                        desc2: "wallet on computer",
                        btnText: "Use It Now",
                        btnTextm: "Copy Link",
                        tips: "Copy the link successfully, please go to the computer to open"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "项目网络不能为空",
                        title: "项目名称不能为空",
                        address: "DApp合约帐号不能为空",
                        url: "项目链接不能为空",
                        desc: "项目简介不能为空",
                        icon_url: "请上传DApp图标",
                        rakeBackAccount: "邀请奖励合约账号不能为空",
                        email: "邮箱不能为空",
                        others: "其他联系方式不能为空",
                        tp_connect: "该项不能为空"
                    },
                    title: "项目名称",
                    address: "DApp合约地址",
                    url: "项目链接",
                    desc: "项目简介",
                    icon: "DApp图标 (图片大小：200x200px，支持JPG、PNG)",
                    referral: "返佣",
                    hasReferral: "是否有返佣机制",
                    referralReward: "邀请奖励发放方式",
                    reward_1: "邀请奖励发放方式",
                    reward_2: "邀请人需在DApp里手动领取",
                    hasInviteReward: "邀请人账号是否需要在DApp中完成一笔交易才能激活邀请奖励",
                    inviteAccount: "给TP发放邀请奖励的合约账号",
                    DAppRequirement: "DApp要求",
                    requirement_1: "1. DApp需要支持TokenPocket 移动端和插件端。",
                    requirement_2: "2. 项目方提供的网址可公开访问且稳定性有保证。",
                    requirement_3: "3. 智能合约已部署到主网上，敏感逻辑处需开源。",
                    requirement_4: "4. 敏感的合约需提供第三方安全机构的审计报告。",
                    requirement_5: "5. 交互逻辑清晰，有实际用途，且已适配移动端。",
                    requirement_6: "6. 符合相关法律法规，不存在欺诈和侵权等行为。",
                    requirement_7: "7. 如违反相关法律法规，自愿承受相应法律责任。",
                    dappInfo: "项目信息：",
                    necessary: "为必填项",
                    language: "项目语言",
                    languageDesc: "(多语言请分别提交)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "一句话简单描述项目，将出现在DApp副标题里",
                    auditInfo: "审计信息：",
                    hasAudit: "是否已进行合约审计",
                    auditUrl: "审计报告链接",
                    auditUrlExample: "如：https://auditlink.com",
                    auditReport: "审计报告",
                    auditUpload: "点击上传",
                    contact: "联系方式：",
                    contactDesc: "请务必留下除邮箱以外的客服联系方式，否则无法通过审核",
                    emailAddr: "邮箱",
                    emailExample: "dapp@tokenpocket.pro",
                    others: "其他",
                    othersExample: "如：Discord：1234",
                    auditOptional: "审计信息至少选填一项",
                    oversize: "已超出限定字符",
                    select: "请选择",
                    tutorial_url: "https://help.tokenpocket.pro/developer-cn/",
                    tutorial: "对接教程>>"
                },
                DOWNLOAD: {
                    TITLE: "下载 TokenPocket",
                    TITLE_Android: "TokenPocket 安卓客户端",
                    TITLE_IOS: "TokenPocket iOS客户端",
                    TITLE_Chrome: "TokenPocket 浏览器插件",
                    TEXT: "TokenPocket 是一款支持多链的自托管钱包，使用简单安全，深受全球数千万人的信赖与喜爱",
                    TEXT_Chrome: "TokenPocket插件钱包是一款多链自托管钱包，支持所有EVM兼容链，使用简单安全，深受全球数千万人的信赖与喜爱",
                    TEXT_PC: "TokenPocket桌面端是基于ETH、TRON、EOS的多链钱包，我们努力为用户提供强大且安全的数字资产管理服务",
                    scanCode: "扫码下载",
                    installTutorial: "插件安装教程",
                    desc_1: "请务必从官网下载钱包应用，并检查网站的SSL证书",
                    desc_2: "保护好您的私钥、助记词，切勿泄露，更不可与任何人透露",
                    desc_3: "了解更多安全知识",
                    verifyText: "最新安卓版本：",
                    verifyText1: "如何验证钱包App的真假",
                    verifyText2: "最新版本",
                    verifyText3: "最新谷歌商店版本：",
                    footerTitle: "",
                    footerDesc_1: "多链钱包，支持BTC、ETH、BSC、TRON、Matic、Aptos、Solana、EOS、Polkadot、IOST等等",
                    footerDesc_2: "多重安全保护措施，让您安心使用",
                    footerDesc_3: "支持DeFi、DApp、GameFi和NFT等",
                    coming_soon: "即将上线",
                    desc_tp_wallet: "正式成为 TokenPocket 唯一 iOS App 发行商",
                    tp_wallet_version: "TP Wallet版本:",
                    token_pocket_version: "Token Pocket版本:",
                    delisted: "已下架",
                    checkoutAllVersion: "查看所有版本"
                },
                TOKEN: {
                    RULES: {
                        email: "Email不能为空",
                        address: "合约地址不能为空",
                        owner_address: "合约帐号地址不能为空",
                        symbol: "代币符号不能为空",
                        bl_symbol: "网络代码不能为空",
                        total_supply: "代币数量不能为空",
                        decimal: "代币精度不能为空",
                        precision: "代币小数位不能为空",
                        gas: "GAS费用不能为空",
                        website: "官网地址不能为空",
                        companyName: "公司或个人名字不能为空",
                        contact: "项目方联系方式不能为空",
                        name: "项目简介不能为空",
                        icon_url: "请上传代币Logo"
                    }, icon: "代币图标(200*200像素，支持jpg、jpeg、png)", handleText: "我们会在两个工作日内处理您的申请"
                },
                RECRUITING: {
                    title: "TP侠招募计划",
                    text: "加入TokenPocket社区",
                    text1: "投身到区块链世界，贡献自己的一份力量",
                    text2: "共同建设Web3.0世界",
                    joinUs: "加入我们",
                    aboutTitle: "关于TP侠",
                    aboutText: "TP侠是TP社区中的重要一员，我们诚挚地邀请您成为全球TP侠中的一员！",
                    aboutText1: "热衷于区块链事业并认可它的价值",
                    aboutText2: "作为TokenPocket的忠诚用户，希望为探索区块链增加便利",
                    missionTitle: "TP侠使命",
                    missionText: "在全球范围内，帮助TP钱包服务更多的区块链用户，我们希望您（满足以下其中两项要求即可报名）",
                    missionText1: "能够通过多种渠道拓展并促进TP与所在国家的的营销公司或热门项目合作",
                    missionText2: "能够策划符合当地用户需求的市场营销活动",
                    missionText3: "具有其中一至几项主流社交媒体如Twitter、Youtube、Telegram、Discord等媒体的运营能力",
                    missionText4: "具有流畅的英语水平，能完成对应的翻译工作",
                    missionText5: "TokenPocket当前计划为区块链市场提供更多的福利，如果您来自印度、美国、土耳其、俄罗斯、韩国、越南、菲律宾等，我们将给您提供更多的工作支持",
                    getTitle: "我们提供的福利",
                    getText: "一段直接与区块链各个领域直接接触的工作经历，你将获得不限于DApp项目方、kol、主流媒体的交互机会",
                    getText1: "根据工作内容（翻译推文、制作视频、社群运营、寻求商务合作等）获得对应的丰厚报酬",
                    getText2: "获得最专业的区块链知识培训，与团队一起探索WEB3.0世界",
                    getText3: "TP官方福利，包含TokenPocket定制衣服，硬件钱包",
                    processTitle: "招募流程",
                    processText: "投递简历",
                    processText1: "简历筛选",
                    processText2: "线上面试",
                    processText3: "面试结果",
                    processText4: "开始工作",
                    applyTitle: "招募对象",
                    applyText: "来自全球任何地方",
                    applyText1: "对区块链保持着无尽的好奇和热情",
                    applyText2: "填写表格并附上简历，我们会尽快联系您",
                    footerTitle: "关于TokenPocket",
                    footerText: "超过",
                    footerText1_1: "2千万",
                    footerText1_2: "全球用户量",
                    footerText2_1: "350万",
                    footerText2_2: "月活",
                    footerText3_1: "200个",
                    footerText3_2: "国家和地区",
                    footerText4: "TokenPocket 全球领先的多链自托管钱包",
                    footerText5: "Coming soon"
                },
                NAVIGATION: {
                    product: {
                        title: "产品",
                        selfCustodyWallet: "手机钱包",
                        selfCustodyWalletDesc: "您的移动端数字资产钱包，支持iOS和Android",
                        hardwareWallet: "硬件钱包",
                        hardwareWalletDesc: "拥有KeyPal，让您的资产更安全",
                        extensionWallet: "插件钱包",
                        extensionWalletDesc: "您电脑上更好用的钱包",
                        transit: "Transit",
                        transitDesc: "多链聚合、跨链工具及NFT市场",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Web3.0上的社交网络协议",
                        stakeVault: "质押宝",
                        stakeVaultDesc: "支持自托管质押节点和小额灵活质押节点",
                        buyCrypto: "购买数字资产",
                        buyCryptoDesc: "通过信用卡等方式购买数字资产"
                    },
                    assets: {title: "资产"},
                    collaborations: {title: "项目合作"},
                    community: {title: "社区", developers: "开发者", recruiting: "TP侠"},
                    helpCenter: {title: "帮助中心"}
                },
                ABOUT: {
                    title: "关于我们",
                    desc: "TokenPocket是一款去中心化多链钱包，为用户提供手机钱包、插件钱包和硬件钱包，支持比特币、以太坊、币安智能链、TRON、Aptos、Polygon、Solana、Polkadot、EOS等公链以及所有EVM兼容链。TokenPocket服务于来自200多个国家和地区的2000多万用户。它是全球用户信赖的领先的加密钱包。",
                    philosophy: {
                        title: "我们的理念",
                        desc: "我们坚持开发技术社区，欢迎所有的开发者共同构建更便捷、更安全、更丰富的区块链世界",
                        ambition: "目标",
                        ambition_desc: "让区块链随处发生",
                        value: "价值",
                        value_desc: "让数据回归用户，让价值归属用户",
                        attitude: "态度",
                        attitude_desc: "开放思维，互相协作"
                    },
                    milestones: {
                        title: "里程碑",
                        desc_2018_1: "TokenPocket成立",
                        desc_2018_2: "由火币、浩方资本、字节资本投资",
                        desc_2019_1: "发布桌面端钱包，并支持TRON网络",
                        desc_2019_2: "谷歌商店下载次数突破100万",
                        desc_2020_1: "支持身份钱包（HD钱包）",
                        desc_2020_2: "支持BSC网络以及DeFi趋势",
                        desc_2020_3: "支持Eth2.0系统质押",
                        desc_2021_1: "孵化去中心化聚合平台Transit",
                        desc_2021_2: "总用户量突破2000万",
                        desc_2021_3: "孵化硬件钱包KeyPal",
                        desc_2022_1: "收购dFox并将品牌升级为TokenPocket Extension",
                        January: "1月",
                        February: "2月",
                        March: "3月",
                        April: "4月",
                        May: "5月",
                        June: "6月",
                        July: "7月",
                        August: "8月",
                        September: "9月",
                        October: "10月",
                        November: "11月",
                        December: "12月"
                    },
                    contact_us: {
                        title: "联系我们",
                        service: "服务邮箱",
                        service_desc: "service@tokenpocket.pro",
                        bd: "商务合作",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "开发者",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - 让区块链随处发生 | TP钱包-ETH钱包-BTC钱包-BSC钱包-Aptos钱包-HECO钱包-OKExChain钱包-Polkadot钱包-Kusama钱包-DeFi钱包-Layer 2钱包-EOS钱包-TRX钱包-以太坊钱包-BNB钱包-波场钱包-比特币钱包-OK钱包-Web3钱包-加密钱包-NFT钱包-nostr",
                    description: "TokenPocket是全球最大的数字货币钱包，支持包括BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, OKExChain, Polkadot, Kusama, EOS等在内的所有主流公链及Layer 2，已为全球近千万用户提供可信赖的数字货币资产管理服务，也是当前DeFi用户必备的工具钱包。",
                    keywords: "TokenPocket,Token Pocket,TP钱包,ETH钱包,BTC钱包,EOS钱包,IOST,波卡,Polkadot,COSMOS,波场,以太坊,DeFi,火币链,币安智能链,钱包,layer2,加密,区块链,web3,NFT,nostr"
                }
            }, zhTw: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "批量轉賬",
                    YES: "是",
                    NO: "否",
                    HAS: "有",
                    HAVENT: "没有",
                    BLOCKCHAIN: "項目網絡",
                    MULTIPLE_CHOICE: "(可多選)",
                    IS_SUPPORT_TP_CONNECT: "是否支持TokenPocket連接（包括移動端和插件端）",
                    SUPPORT_BOTH: "均已支持",
                    SUPPORT_EXTENSION: "僅支持插件端",
                    SUPPORT_MOBILE: "僅支持移動端",
                    SUPPORT_NONE: "均未支持",
                    blockchainWallet: "區塊鏈錢包",
                    iostWallet: "IOST錢包",
                    tronWallet: "TRON錢包",
                    platformInfo: {
                        eos: "EOS",
                        moac: "墨客",
                        eth: "以太坊",
                        jt: "井通",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "幣安智能鏈",
                        heco: "火幣生態鏈",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "虎符智能鏈",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "提交",
                    symbol: "代幣符號（如：AAA）",
                    success: "成功",
                    bl_symbol: "網絡代碼",
                    precision: "代幣小數位",
                    decimal: "精度（如：18）",
                    totalSupply: "代幣數量",
                    contract: "合約地址（如：itokenpocket）",
                    website: "官方網址（如：https://www.tokenpocket.pro）",
                    introduction: "項目簡介",
                    example: "示例",
                    submitTokenInfoAndLogo: "提交代幣信息及logo",
                    toGithubSubmit: "跳轉至Github提交",
                    nftType: "NFT類型",
                    LAYOUT: {
                        features: "功能",
                        buyCrypto: "購買加密資產",
                        mobileWallet: "手機錢包",
                        hardwareWallet: "硬體錢包",
                        extensionWallet: "挿件錢包",
                        desktop: "桌面端錢包",
                        fiveDegrees: "5Degrees",
                        versionVerification: "版本校验",
                        approvalDetector: "授權檢測",
                        tokenSecurity: "代幣安全",
                        keyGenerator: "私鑰生成器",
                        information: "信息",
                        blockchainGuide: "區塊鏈小白書",
                        tronWallet: "波場小白書",
                        iostWallet: "IOST小白書",
                        tpMan: "TP俠",
                        developers: "開發者",
                        github: "Github (TP-Lab)",
                        devCenter: "開發者中心",
                        subToken: "提交代幣",
                        subDApp: "提交DApp",
                        subNFT: "提交NFT",
                        subChain: "提交公鏈",
                        company: "公司",
                        about: "關於",
                        careers: "招聘",
                        pressKit: "品牌素材",
                        swagShop: "周邊商店",
                        support: "支持",
                        helpCenter: "幫助中心",
                        contactUs: "聯繫我們",
                        legal: "法律",
                        privacyPolicy: "隱私策略",
                        terms: "服務協議",
                        toHome: "返回首頁",
                        defiWallet: "DeFi錢包",
                        ETHWallet: "Ethereum Wallet",
                        ethWallet: "ETH錢包"
                    }
                },
                HOME: {
                    download: "下載",
                    downloadNow: "立即下載",
                    HEADER: {title: "加密錢包 安全簡單", desc_1: "讓你安全、簡單地探索區塊鏈，是全球領先的數字資產錢包"},
                    INTRODUCTION: {
                        title: "TokenPocket深受全球的用戶信賴",
                        desc_1: "我們為全球200多個國家及地區的用戶提供安全易用的數字資產服務",
                        desc_2: "服務的用戶",
                        desc_3: "日均交易數",
                        desc_4: "國家及地區"
                    },
                    SECURITY: {
                        title: "安全是我們的根基",
                        desc_1: "TokenPocket只在用戶的設備裡生成並存儲私鑰助記詞，您是唯一可以訪問的人",
                        desc_2: "TokenPocket同時開發了冷錢包、多簽錢包等，來滿足您對安全的需求",
                        desc_3: "多鏈錢包，支持BTC、ETH、BSC、TRON、Aptos、Polygon、Solana、Cosmos、Polkadot、EOS、IOST等"
                    },
                    EXCHANGE: {
                        title: "兌換、交易更簡單",
                        desc_1: "隨時隨地，讓你更方便地交易",
                        desc_2: "用你的信用卡購入數字資產，輕鬆存儲、發送、跨鏈與兌換",
                        desc_3: "閃兌",
                        desc_4: "簡單快速",
                        desc_5: "跨鏈",
                        desc_6: "多鏈轉換",
                        desc_7: "購入數字資產",
                        desc_8: "僅在5分鐘內"
                    },
                    DAPPSTORE: {
                        title: "一站式DApp商店",
                        desc_1: "找到你最喜愛的去中心化應用，發現最新、最熱的DApp，一切盡在TokenPocket",
                        desc_2: "集成DApp瀏覽器，您可以訪問你的任何DApp鏈接",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "已支持"
                    },
                    COMMUNITY: {
                        title: "社區",
                        desc_1: "我們堅持開放性社區，始終如一！我們歡迎所有開發者一起開發更方便、更豐富的的區塊鏈世界",
                        desc_2: "TP-Lab",
                        desc_3: "開發者社區",
                        desc_4: "開發者文檔"
                    },
                    DOWNLOAD: {title: "現在就擁有您的TokenPocket！", desc_1: "安全可信賴的數字資產錢包，伴您探索區塊鏈世界"},
                    FOLLOW: {
                        title: "關注我們",
                        desc1: "TokenPocket 客服不會私聊您！",
                        desc2: "請注意，您即將進入TokenPocket社區，您進入社區可能會有人假冒TokenPocket的工作人員私聊您，請您務必警惕，所有私聊您的都可能是騙子！ TokenPocket工作人員不會主動跟您私信！",
                        desc3: "知道了，繼續前往"
                    },
                    EXTENSIONMODAL: {
                        title: "插件錢包現已上線！",
                        desc1: "一款應用在電腦上的 Crypto/DeFi",
                        desc2: "/GameFi 錢包",
                        btnTextm: "複製鏈接",
                        btnText: "立即使用",
                        tips: "複製鏈接成功，請前往電腦端打開"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "項目網絡不能為空",
                        title: "項目名稱不能為空",
                        address: "DApp合約帳號不能為空",
                        url: "項目鏈接不能為空",
                        desc: "項目簡介不能為空",
                        icon_url: "請上傳DApp圖標",
                        rakeBackAccount: "邀請獎勵合約賬號不能為空",
                        email: "郵箱不能為空",
                        others: "其他聯繫方式不能為空",
                        tp_connect: "該項不能為空"
                    },
                    title: "項目名稱",
                    address: "DApp合約地址",
                    url: "項目鏈接",
                    desc: "項目簡介",
                    icon: "DApp圖標 (圖片大小：200x200px，支持JPG、PNG)",
                    referral: "返佣",
                    hasReferral: "是否有返佣機制",
                    referralReward: "邀請獎勵發放方式",
                    reward_1: "邀请奖励发放方式",
                    reward_2: "邀請人需在DApp里手動領取",
                    hasInviteReward: "邀請人賬號是否需要在DApp中完成一筆交易才能激活邀請獎勵",
                    inviteAccount: "給TP發放邀請獎勵的合約賬號",
                    DAppRequirement: "DApp要求",
                    requirement_1: "1. DApp需要支持TokenPocket 移動端和插件端。",
                    requirement_2: "2. 項目方提供的網址可公開訪問且穩定性有保證。",
                    requirement_3: "3. 智能合約已部署到主網上，敏感邏輯處需開源。",
                    requirement_4: "4. 敏感的合約需提供第三方安全機構的審計報告。",
                    requirement_5: "5. 交互邏輯清晰，有實際用途，且已適配移動端。",
                    requirement_6: "6. 符合相關法律法規，不存在欺詐和侵權等行為。",
                    requirement_7: "7. 如違反相關法律法規，自願承受相應法律責任。",
                    dappInfo: "項目信息：",
                    necessary: "為必填項",
                    language: "項目語言",
                    languageDesc: "(多語言請分別提交)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "一句話簡單描述項目，將出現在DApp副標題裡",
                    auditInfo: "審計信息：",
                    hasAudit: "是否已進行合約審計",
                    auditUrl: "審計報告鏈接",
                    auditUrlExample: "如：https://auditlink.com",
                    auditReport: "審計報告",
                    auditUpload: "點擊上傳",
                    contact: "聯繫方式：",
                    contactDesc: "請務必留下除郵箱以外的客服聯繫方式，否則無法通過審核",
                    emailAddr: "郵箱",
                    emailExample: "dapp@tokenpocket.pro",
                    others: "其他",
                    othersExample: "如：Discord：1234",
                    auditOptional: "審計信息至少選填一項",
                    oversize: "已超出限定字符",
                    select: "請選擇",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "對接教程>>"
                },
                DOWNLOAD: {
                    TITLE: "下載 TokenPocket",
                    TITLE_Android: "TokenPocket 安卓客戶端",
                    TITLE_IOS: "TokenPocket iOS客戶端",
                    TITLE_Chrome: "TokenPocket 瀏覽器插件",
                    TEXT: "TokenPocket 是一款支持多鏈的自託管錢包，使用簡單安全，深受全球數千萬人的信賴與喜愛",
                    TEXT_Chrome: "TokenPocket插件錢包是一款多鏈自託管錢包，支持所有EVM兼容鏈，使用簡單安全，深受全球數千萬人的信賴與喜愛",
                    TEXT_PC: "TokenPocket桌面端是基於ETH、TRON、EOS的多鏈錢包，我們努力為用戶提供強大且安全的數字資產管理服務",
                    scanCode: "掃碼下載",
                    installTutorial: "插件安装教程",
                    desc_1: "請務必從官網下載錢包應用，並檢查網站的SSL證書",
                    desc_2: "保護好您的私鑰、助記詞，切勿洩露，更不可與任何人透露",
                    desc_3: "了解更多安全知識",
                    verifyText: "當前安卓版本:",
                    verifyText1: "如何驗證應用安全性",
                    verifyText2: "當前版本:",
                    verifyText3: "當前 Google Play 版本:",
                    footerDesc_1: "多鏈錢包，支持BTC、ETH、BSC、TRON、Aptos、Matic、Solana、EOS、Polkadot、IOST等等",
                    footerDesc_2: "多重安全保護措施，讓您安心使用",
                    footerDesc_3: "支持DeFi、DApp、GameFi和NFT等",
                    coming_soon: "即將上線",
                    desc_tp_wallet: "正式成為 TokenPocket 唯一 iOS App 發行商",
                    tp_wallet_version: "TP Wallet 版本:",
                    token_pocket_version: "Token Pocket 版本:",
                    delisted: "已下架",
                    checkoutAllVersion: "查看所有版本"
                },
                TOKEN: {
                    RULES: {
                        email: "Email不能為空",
                        address: "合約地址不能為空",
                        owner_address: "合約帳號地址不能為空",
                        symbol: "代幣符號不能為空",
                        bl_symbol: "網絡代碼不能為空",
                        total_supply: "代幣數量不能為空",
                        decimal: "代幣精度不能為空",
                        precision: "代幣小數位不能為空",
                        gas: "GAS費用不能為空",
                        website: "官網地址不能為空",
                        companyName: "公司或個人名字不能為空",
                        contact: "項目方聯繫方式不能為空",
                        name: "項目簡介不能為空",
                        icon_url: "請上傳代幣Logo"
                    }, icon: "代幣圖標((200*200像素，支持jpg、jpeg、png)", handleText: "我們會在兩個工作日內處理您的申請"
                },
                RECRUITING: {
                    title: "TP俠招募計劃",
                    text: "加入TokenPocket社區",
                    text1: "投身到區塊鏈世界，貢獻自己的一份力量",
                    text2: "共同建設Web3.0世界",
                    joinUs: "加入我們",
                    aboutTitle: "關於TP俠",
                    aboutText: "TP俠是TP社區中的重要一員，我們誠摯地邀請您成為全球TP俠中的一員！",
                    aboutText1: "熱衷於區塊鏈事業並認可它的價值",
                    aboutText2: "作為TokenPocket的忠誠用戶，希望為探索區塊鏈增加便利",
                    missionTitle: "TP俠使命",
                    missionText: "在全球範圍內，幫助TP錢包服務更多的區塊鏈用戶，我們希望您（滿足以下其中兩項要求即可報名）",
                    missionText1: "能夠通過多種渠道拓展並促進TP與所在國家的的營銷公司或熱門項目合作",
                    missionText2: "能夠策劃符合當地用戶需求的市場營銷活動",
                    missionText3: "具有其中一至幾項主流社交媒體如Twitter、Youtube、Telegram、Discord等媒體的運營能力",
                    missionText4: "具有流暢的英語水平，能完成對應的翻譯工作",
                    missionText5: "TokenPocket當前計劃為區塊鏈市場提供更多的福利，如果您來自印度、美國、土耳其、俄羅斯、韓國、越南、菲律賓等，我們將給您提供更多的工作支持",
                    getTitle: "我們提供的福利",
                    getText: "一段直接與區塊鏈各個領域直接接觸的工作經歷，你將獲得不限於DApp項目方、kol、主流媒體的交互機會",
                    getText1: "根據工作內容（翻譯推文、製作視頻、社群運營、尋求商務合作等）獲得對應的豐厚報酬",
                    getText2: "獲得最專業的區塊鏈知識培訓，與團隊一起探索WEB3.0世界",
                    getText3: "TP官方福利，包含TokenPocket定製衣服，硬件錢包",
                    processTitle: "招募流程",
                    processText: "投遞簡歷",
                    processText1: "簡歷篩選",
                    processText2: "線上面試",
                    processText3: "面試結果",
                    processText4: "開始工作",
                    applyTitle: "招募對象",
                    applyText: "來自全球任何地方",
                    applyText1: "對區塊鏈保持著無盡的好奇和熱情",
                    applyText2: "填寫表格並附上簡歷，我們會盡快聯繫您",
                    footerTitle: "關於TokenPocket",
                    footerText: "超過",
                    footerText1_1: "2千萬",
                    footerText1_2: "全球用戶量",
                    footerText2_1: "350萬",
                    footerText2_2: "月活",
                    footerText3_1: "200個",
                    footerText3_2: "國家和地區",
                    footerText4: "TokenPocket 全球領先的多鏈自託管錢包",
                    footerText5: "Coming soon"
                },
                NAVIGATION: {
                    product: {
                        title: "產品",
                        selfCustodyWallet: "手機錢包",
                        selfCustodyWalletDesc: "區塊鏈入口，手機上的多鏈錢包",
                        hardwareWallet: "硬體錢包",
                        hardwareWalletDesc: "用keypal守護您的資產，安全、放心",
                        extensionWallet: "挿件錢包",
                        extensionWalletDesc: "讓您更友好的體驗電腦端錢包",
                        transit: "Transit",
                        transitDesc: "多鏈DEX聚合閃兌與NFT市場平臺",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Web3.0社交協定",
                        stakeVault: "質押寶",
                        stakeVaultDesc: "支持自託管質押節點和小額靈活質押節點",
                        buyCrypto: "購買數字資產",
                        buyCryptoDesc: "通過信用卡等方式購買數字資產"
                    },
                    assets: {title: "資產"},
                    collaborations: {title: "合作"},
                    community: {title: "社區", developers: "開發者", recruiting: "TP俠"},
                    helpCenter: {title: "幫助中心"}
                },
                ABOUT: {
                    title: "關於我們",
                    desc: "TokenPocket是一款去中心化多鏈錢包，為用戶提供手機錢包、插件錢包和硬件錢包，支持比特幣、以太坊、幣安智能鏈、TRON、Aptos、Polygon、Solana、Polkadot、EOS等公鏈以及所有EVM兼容鏈。 TokenPocket服務於來自200多個國家和地區的2000多萬用戶。它是全球用戶信賴的領先的加密錢包。",
                    philosophy: {
                        title: "我們的理念",
                        desc: "我們堅持開發技術社區，歡迎所有的開發者共同構建更便捷、更安全、更豐富的區塊鏈世界",
                        ambition: "目標",
                        ambition_desc: "讓區塊鏈隨處發生",
                        value: "價值",
                        value_desc: "讓數據回歸用戶，讓價值歸屬用戶",
                        attitude: "態度",
                        attitude_desc: "開放思維，互相協作"
                    },
                    milestones: {
                        title: "里程碑",
                        desc_2018_1: "TokenPocket成立",
                        desc_2018_2: "由火幣、浩方資本、字節資本投資",
                        desc_2019_1: "發布桌面端錢包，並支持TRON網絡",
                        desc_2019_2: "谷歌商店下載次數突破100萬",
                        desc_2020_1: "支持身份錢包（HD錢包）",
                        desc_2020_2: "支持BSC網絡以及DeFi趨勢",
                        desc_2020_3: "支持Eth2.0系統質押",
                        desc_2021_1: "孵化去中心化聚合平台Transit",
                        desc_2021_2: "總用戶量突破2000萬",
                        desc_2021_3: "孵化硬件錢包KeyPal",
                        desc_2022_1: "收購dFox並將品牌升級為TokenPocket Extension",
                        January: "1月",
                        February: "2月",
                        March: "3月",
                        April: "4月",
                        May: "5月",
                        June: "6月",
                        July: "7月",
                        August: "8月",
                        September: "9月",
                        October: "10月",
                        November: "11月",
                        December: "12月"
                    },
                    contact_us: {
                        title: "聯繫我們",
                        service: "服務郵箱",
                        service_desc: "service@tokenpocket.pro",
                        bd: "商務合作",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "開發者",
                        developers_desc: "Discord link"
                    }
                },
                SEO: {
                    title: "TokenPocket - 你的通用數字錢包 | TP錢包-ETH錢包-BTC錢包-BSC錢包-HECO錢包-OKExChain錢包-Polkadot錢包-Kusama 錢包-DeFi錢包-Layer 2錢包-EOS錢包-TRX錢包-nostr",
                    description: "TokenPocket是全球最大的數字貨幣錢包，支持包括BTC、ETH、BSC、HECO、TRON、Aptos、OKExChain、Polkadot、Kusama、EOS等在內的所有主流公鍊及Layer 2，已為全球近千萬用戶提供可信賴的數字貨幣資產管理服務，也是當前DeFi用戶必備的工具錢包。",
                    keywords: "TokenPocket,Token Pocket,TP錢包,ETH錢包,BTC錢包,EOS錢包,IOST,波卡,Polkadot,COSMOS,波場,以太坊,DeFi,火幣鏈,幣安智能鏈,錢包,layer2,加密,區塊鏈,web3,NFT,nostr"
                }
            }, en: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "BatchSender",
                    YES: "Yes",
                    NO: "No",
                    HAS: "Yes",
                    HAVENT: "No",
                    BLOCKCHAIN: "Blockchain",
                    MULTIPLE_CHOICE: "(Multiple choice)",
                    IS_SUPPORT_TP_CONNECT: "Does it support TokenPocket connection? (Extension and Mobile app)",
                    SUPPORT_BOTH: "Both are supported",
                    SUPPORT_EXTENSION: "Only extension",
                    SUPPORT_MOBILE: "Only mobile",
                    SUPPORT_NONE: "None",
                    blockchainWallet: "Blockchain Wallet",
                    iostWallet: "IOST Wallet",
                    tronWallet: "TRON Wallet",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "Submit",
                    symbol: "Token Name",
                    success: "Success",
                    bl_symbol: "BL Symbol",
                    precision: "Token Precision",
                    decimal: "Token Decimal",
                    totalSupply: "Total Supply",
                    contract: "Token Contract",
                    website: "Official Website",
                    introduction: "Token Introduction",
                    example: "Example",
                    submitTokenInfoAndLogo: "Update token logo and other Info",
                    toGithubSubmit: "Go to Github",
                    nftType: "NFT protocol standard",
                    LAYOUT: {
                        features: "Features",
                        buyCrypto: "Buy Crypto",
                        mobileWallet: "Mobile Wallet",
                        hardwareWallet: "Hardware Wallet",
                        extensionWallet: "Extension Wallet",
                        desktop: "Desktop Wallet",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "Approval Detector",
                        tokenSecurity: "Token Security",
                        keyGenerator: "Key Generator",
                        information: "Information",
                        blockchainGuide: "Blockchain Guide",
                        tronWallet: "TRON Guide",
                        iostWallet: "IOST Guide",
                        tpMan: "TP Man",
                        developers: "Developers",
                        github: "Github (TP-Lab)",
                        devCenter: "Dev Center",
                        subToken: "Submit Token",
                        subDApp: "Submit DApp",
                        subNFT: "Submit NFT",
                        subChain: "Submit Chain",
                        company: "Company",
                        about: "About",
                        careers: "Careers",
                        pressKit: "Press Kit",
                        swagShop: "Swag Shop",
                        support: "Support",
                        helpCenter: "Help Center",
                        contactUs: "Contact Us",
                        legal: "Legal",
                        privacyPolicy: "Privacy Policy",
                        terms: "Terms of Use",
                        toHome: "Home",
                        defiWallet: "DeFi Wallet",
                        ETHWallet: "Ethereum Wallet",
                        ethWallet: "ETH Wallet"
                    }
                },
                HOME: {
                    download: "Download",
                    downloadNow: "Download Now",
                    HEADER: {
                        title: "Your secure crypto wallet to explore blockchain",
                        desc_1: "Easy and safe to buy, store, send, swap tokens and collect NFTs. Trusted by 20+ millions users from 200+ countries and regions."
                    },
                    INTRODUCTION: {
                        title: "TokenPocket is trusted by global users",
                        desc_1: "We are providing secure and easy crypto wallet service among 200+ countries and regions around the world",
                        desc_2: "Serving users",
                        desc_3: "Daily Transactions",
                        desc_4: "Supporting countries and regions"
                    },
                    SECURITY: {
                        title: "Security as it should be",
                        desc_1: "TokenPocket generates and stores keys and passwords on your device only, only you can access your account and assets.",
                        desc_2: "TokenPocket also develops hardware cold wallet and MultiSig wallet feature to enhance the security as you need.",
                        desc_3: "Supporting BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, Cosmos, Polkadot, EOS, IOST and so on."
                    },
                    EXCHANGE: {
                        title: "Exchange & Transact Easily",
                        desc_1: "You can trade your crypto anytime, anywhere within TokenPocket.",
                        desc_2: "Buy crypto with credit cards. Store, send, cross chain and exchange with ease.",
                        desc_3: "Swap",
                        desc_4: "Instantly and easily",
                        desc_5: "Bridge",
                        desc_6: "Among different chains",
                        desc_7: "Buy Crypto",
                        desc_8: "In 5 minutes"
                    },
                    DAPPSTORE: {
                        title: "A DApp Store",
                        desc_1: "You can find your favorite decentralized applications, discover the latest and hottest ones and use them without leaving the wallet.",
                        desc_2: "DApp Browser integrated, you can always access the DApps with your links.",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "Supported"
                    },
                    COMMUNITY: {
                        title: "Community",
                        desc_1: "We insist on an open technology community, and we welcome all developers to build a more convenient, secure and richer blockchain world together",
                        desc_2: "TP-Lab",
                        desc_3: "Community",
                        desc_4: "Dev Docs"
                    },
                    DOWNLOAD: {
                        title: "Get the TokenPocket Wallet now!",
                        desc_1: "Your secure and trusted crypto wallet to explore blockchain"
                    },
                    FOLLOW: {
                        title: "Follow Us",
                        desc1: "TokenPocket Staffs won't send you private messages!",
                        desc2: "Caution! You're entering TokenPocket community, there might be someone impersonating us to send you private messages! Please be aware that, anyone who sends private messages might be a scammer! We will never contact you first!",
                        desc3: "Understood, enter"
                    },
                    EXTENSIONMODAL: {
                        title: "Extension is now live!",
                        desc1: "Your Crypto & DeFi & GameFi",
                        desc2: "wallet on computer",
                        btnText: "Use It Now",
                        btnTextm: "Copy Link",
                        tips: "Copy the link successfully, please go to the computer to open"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "Platform is required",
                        title: "DApp Name is required",
                        address: "DApp Contract is required",
                        url: "DApp Website is required",
                        desc: "Desc is required",
                        icon_url: "DApp Logo is required",
                        rakeBackAccount: "Contract account is required",
                        email: "Email is required",
                        others: "Other contact information is required",
                        tp_connect: "This item cannot be blank"
                    },
                    title: "DApp Name",
                    address: "Smart Contract",
                    url: "DApp Website",
                    desc: "Short Description",
                    icon: "DApp Logo (Must be 200x200 - supports JPG, PNG.)",
                    referral: "Referral",
                    hasReferral: "Does it have a referral system",
                    referralReward: "The distribution of the referral reward",
                    reward_1: "Automatically distribute by the smart contract (Live)",
                    reward_2: "Need to claim it on the DApp Manually",
                    hasInviteReward: "Does the inviter need to make a transaction in the DApp to activate the referral link",
                    inviteAccount: "The smart contract of referral distribution",
                    DAppRequirement: "DApp Requirement",
                    requirement_1: "1. DApp needs to support TokenPocket mobile and TokenPocket extension.",
                    requirement_2: "2. The provided website is accessible and stable.",
                    requirement_3: "3. The smart contracts have deployed on the mainnet, and the sensitive part requires to be open source.",
                    requirement_4: "4. The sensitive contracts require audit reports from third-party security agencies.",
                    requirement_5: "5. The interaction logic is clear and has been adapted to the mobile UI.",
                    requirement_6: "6. Obey the relevant laws and regulations, without fraud and infringement.",
                    requirement_7: "7. If you violate relevant laws and regulations, you will voluntarily assume corresponding legal responsibilities.",
                    dappInfo: "DApp Information:",
                    necessary: "required",
                    language: "DApp language",
                    languageDesc: "(Please submit separately for multiple languages)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "A brief description of the project in one sentence, which will appear in the DApp subtitle",
                    auditInfo: "Audit information:",
                    hasAudit: "Whether the contract audit has been carried out",
                    auditUrl: "Audit report url",
                    auditUrlExample: "For example: https://auditlink.com",
                    auditReport: "Audit Report",
                    auditUpload: "Upload",
                    contact: "Contact details",
                    contactDesc: "Please be sure to leave the customer service contact information other than the mailbox, otherwise it will not pass the review",
                    emailAddr: "Email",
                    emailExample: "For example: service@yourdomain.com",
                    others: "Other",
                    othersExample: "For example: Telegram：@123456789",
                    auditOptional: "Fill in at least one item of audit information",
                    oversize: " has exceeded the qualified characters",
                    select: "Select",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "View tutorial>>"
                },
                DOWNLOAD: {
                    TITLE: "Download TokenPocket",
                    TITLE_Android: "TokenPocket for Android",
                    TITLE_IOS: "TokenPocket for iOS",
                    TITLE_Chrome: "TokenPocket for your browser",
                    TEXT: "TokenPocket is a multi-chain crypto wallet, easy and secure to use that trusted by millions.",
                    TEXT_Chrome: "TokenPocket Extension is a multi-chain crypto wallet, all EVM compatible chain supported. Easy and secure to use that trusted by millions.",
                    TEXT_PC: "TokenPocket Desktop is the largest multi-blockchain wallet based EOS ETH BOS TRON, we strive to provide a powerful and secure digital asset management to users.",
                    scanCode: "Scan to Download",
                    installTutorial: "Install Tutorial",
                    desc_1: "Download the app from the official website and check its SSL certification",
                    desc_2: "Protect your Recovery Phrase (mnemonic) and Private Key from leaking, never share it to others",
                    desc_3: "Learn more security tips",
                    verifyText: "Latest APK Version:",
                    verifyText1: "How to verify your app's security",
                    verifyText2: "Latest Version:",
                    verifyText3: "Latest Google Play Version:",
                    footerTitle: "Make a great first impression",
                    footerDesc_1: "Supporting BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST and so on.",
                    footerDesc_2: "Multi-layer security protections",
                    footerDesc_3: "DeFi, DApp, GameFi and NFT supported",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "has been officially appointed as the sole iOS App publisher of TokenPocket",
                    tp_wallet_version: "TP Wallet Version:",
                    token_pocket_version: "Token Pocket Version:",
                    delisted: "Delisted",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "Email is required",
                        address: "Address is required",
                        owner_address: "Owner address is required",
                        symbol: "Symbol is required",
                        bl_symbol: "BL Symbol is required",
                        total_supply: "Total supply is required",
                        decimal: "Decimal is required",
                        precision: "Precision is required",
                        gas: "GAS is required",
                        website: "Website is required",
                        companyName: "Company or personal name is required",
                        contact: "Contact is required",
                        name: "Project introduction is required",
                        icon_url: "Logo is required"
                    },
                    icon: "Token Logo (200 * 200 pixels, supporting jpg, jpeg, png, image file naming format: token name, logo does not need rounded corners)",
                    handleText: "We will process your request in 2 workdays"
                },
                RECRUITING: {
                    title: "TP Man Recruitment Plan",
                    text: "Join the TokenPocket community",
                    text1: "Committed to the blockchain world and contribute your part",
                    text2: "We build a Web3.0 world together",
                    joinUs: "Join Us",
                    aboutTitle: "About TP Man",
                    aboutText: "TP Man is an important part of the TokenPocket community, and we sincerely invite you to join us!",
                    aboutText1: "You are a blockchain enthusiast and endorse the industry value.",
                    aboutText2: "Enjoy the convenience brought by TokenPocket wallet when you explore the blockchain world.",
                    missionTitle: "The Mission of TP Man",
                    missionText: "Help TokenPocket to serve more blockchain users around the world. We hope you, meet two of the following requirements to apply.",
                    missionText1: "Expand and promote TokenPocket cooperation with companies or hot projects in your country through various channels",
                    missionText2: "Plan marketing activities that meet the needs of local users",
                    missionText3: "Have the ability to operate mainstream social medias such as Twitter, Youtube, Telegram, and Discord",
                    missionText4: "Fluent in English, and be able to complete translation work",
                    missionText5: "TokenPocket plans to provide more usage and technical support for global blockchain users, so we hope that you have a certain understanding of the blockchain markets of no less than one country and their users (India, the United States, Turkey, Russia, South Korea, Vietnam, the Philippines, etc.)",
                    getTitle: "What will you get?",
                    getText: "A work experience directly involved with various fields of the blockchain industry, and you will get but not limited to communication opportunities with DApp projects, Influencers, and mainstream media in the industry.",
                    getText1: "Get rich rewards from your work such as tweets translation, making video, community operation and business cooperation.",
                    getText2: "Get the most professional blockchain knowledge training and explore the Web3.0 world with the team together.",
                    getText3: "TokenPocket official benefits, including TokenPocket Swag and hardware wallets.",
                    processTitle: "Recruitment process",
                    processText: "Submit CV",
                    processText1: "CV screening",
                    processText2: "Online interview ",
                    processText3: "Interview results",
                    processText4: "Welcome aboard",
                    applyTitle: "Who can apply",
                    applyText: "Face the world, regardless of country",
                    applyText1: "Be keen and curious about the blockchain world",
                    applyText2: "Fill out the form and attach your resume, then we will contact you as soon as possible",
                    footerTitle: "About TokenPocket",
                    footerText: "over",
                    footerText1_1: "20M",
                    footerText1_2: "global users",
                    footerText2_1: "3.5M",
                    footerText2_2: "monthly active users",
                    footerText3_1: "200",
                    footerText3_2: "countries and regions",
                    footerText4: "TokenPocket is the world's leading multi-chain self-custodial wallet",
                    footerText5: "Coming soon"
                },
                NAVIGATION: {
                    product: {
                        title: "Product",
                        selfCustodyWallet: "Mobile Wallet",
                        selfCustodyWalletDesc: "Crypto&DeFi Mobile Wallet on Blockchain.",
                        hardwareWallet: "Hardware Wallet",
                        hardwareWalletDesc: "Get Your KeyPal, to Guard Your Assets.",
                        extensionWallet: "Extension Wallet",
                        extensionWalletDesc: "A Better Wallet on Your Computer.",
                        transit: "Transit",
                        transitDesc: "Multi-chain DEX Aggregator and NFT Marketplace Platform.",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Social Network Protocol in Web3.0.",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "Support Both Self-Custodial Staking and Small Amount Staking",
                        buyCrypto: "Buy Crypto",
                        buyCryptoDesc: "Buy cryptocurrency with your credit cards"
                    },
                    assets: {title: "Assets"},
                    collaborations: {title: "Collaborations"},
                    community: {title: "Community", developers: "Developers", recruiting: "TP Man"},
                    helpCenter: {title: "Help"}
                },
                ABOUT: {
                    title: "About Us",
                    desc: "TokenPocket is a multi-chain decentralized wallet, it provides users with mobile wallet, extension wallet and hardware wallet, supporting public chains including Bitcoin, Ethereum, BNB Smart Chain, TRON, Aptos, Polygon, Solana, Polkadot, EOS and all EVM compatible chains. Serving over 20 millions users from more than 200 countries and regions. It is a world-wide leading crypto wallet that trusted by global users.",
                    philosophy: {
                        title: "Our philosophy",
                        desc: "We insist on an open technology community, and we welcome all developers to build a more convenient, secure and richer blockchain world together",
                        ambition: "Ambition",
                        ambition_desc: "Make the blockchain happen everywhere",
                        value: "Value",
                        value_desc: "Let data return to users, make value belong to real owners",
                        attitude: "Attitude",
                        attitude_desc: "Open-minded, mutual collaboration"
                    },
                    milestones: {
                        title: "Milestones",
                        desc_2018_1: "TokenPocket Founded",
                        desc_2018_2: "Invested by Huobi, Hofan, Byte Capital",
                        desc_2019_1: "Released desktop wallet, supported TRON",
                        desc_2019_2: "Google Play download exceeded 1,000,000",
                        desc_2020_1: "HD wallet supported",
                        desc_2020_2: "Supported BSC and DeFi tendency",
                        desc_2020_3: "Supported Eth2.0 Staking",
                        desc_2021_1: "Incubated Transit",
                        desc_2021_2: "User base exceeded 20,000,000",
                        desc_2021_3: "Incubated KeyPal hardware wallet",
                        desc_2022_1: "Acquired dFox and rebranded to TokenPocket Extension",
                        January: "January",
                        February: "February",
                        March: "March",
                        April: "April",
                        May: "May",
                        June: "June",
                        July: "July",
                        August: "August",
                        September: "September",
                        October: "October",
                        November: "November",
                        December: "December"
                    },
                    contact_us: {
                        title: "Contact Us",
                        service: "Customer Service",
                        service_desc: "service@tokenpocket.pro",
                        bd: "Business Collaborations",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "Developers",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - Your secure crypto & DeFi Wallet | TP wallet - ETH wallet - BTC wallet - BSC wallet - HECO wallet - OKXChain wallet - Web3 Wallet - Crypto Wallet - blockchain wallet - Polkadot wallet - Kusama wallet - DeFi wallet - Layer 2 wallet - Solana Wallet - EOS wallet - TRX wallet - nostr",
                    description: "TokenPocket is a world-leading crypto wallet, supporting public blockchains including BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, OKExChain, Polkadot, Kusama, EOS and Layer2.",
                    keywords: "TokenPocket,Token Pocket,TP wallet,Ethereum wallet,Bitcoin,EOS,IOST,COSMOS,heco,bsc,layer2,DeFi,wallet,crypto,blockchain,web3,NFT,nostr"
                }
            }, ko: {
                COMMON: {
                    EMAIL: "이메일",
                    BATCH_SENDER: "일괄 송신자",
                    YES: "예",
                    NO: "아니요",
                    HAS: "예",
                    HAVENT: "아니요",
                    BLOCKCHAIN: "블록체인",
                    MULTIPLE_CHOICE: "(다중 선택)",
                    IS_SUPPORT_TP_CONNECT: "TokenPocket 연결을 지원합니까? (확장 및 모바일 앱)",
                    SUPPORT_BOTH: "둘 다 지원됩니다",
                    SUPPORT_EXTENSION: "확장만",
                    SUPPORT_MOBILE: "모바일 전용",
                    SUPPORT_NONE: "없음",
                    blockchainWallet: "블록체인 지갑",
                    iostWallet: "IOST 지갑",
                    tronWallet: "TRON 지갑",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM"
                    },
                    submit: "제출",
                    symbol: "토큰 이름",
                    success: "완료",
                    bl_symbol: "베이스 라인 심볼을 입력해주세요",
                    precision: "정밀도를 입력해주세요",
                    decimal: "소수점을 입력해주세요",
                    totalSupply: "총 공급량",
                    contract: "토큰 컨트렉",
                    website: "웹사이트를 입력해주세요",
                    introduction: "토큰 소개",
                    example: "예시",
                    submitTokenInfoAndLogo: "토큰 정보 및 로고 제출",
                    toGithubSubmit: "Github 커밋으로 이동",
                    nftType: "NFT 유형",
                    LAYOUT: {
                        features: "기능",
                        buyCrypto: "암호화폐 구매",
                        mobileWallet: "모바일 지갑",
                        hardwareWallet: "하드웨어 지갑",
                        extensionWallet: "플러그인 지갑",
                        desktop: "데스크탑 지갑",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "감지 승인",
                        tokenSecurity: "토큰 보안",
                        keyGenerator: "열쇠 생성기",
                        information: "정보",
                        blockchainGuide: "Blockchain 지갑 가이드라인",
                        tronWallet: "TRON 지갑 가이드라인",
                        iostWallet: "IOST 지갑 가이드라인",
                        tpMan: "TP 맨",
                        developers: "개발자",
                        github: "Github (TP-Lab)",
                        devCenter: "개발자 센터",
                        subToken: "토큰 제출하기",
                        subDApp: "DApp 체출하기",
                        subNFT: "NFT 제출",
                        subChain: "체인",
                        company: "회사",
                        about: "에 대한",
                        careers: "직업",
                        pressKit: "프레스 키트",
                        swagShop: "스웨그 샵",
                        support: "서포트",
                        helpCenter: "도움 센터",
                        contactUs: "연락주세요",
                        legal: "법률",
                        privacyPolicy: "개인 정보 보호 정책",
                        terms: "이용 약관",
                        toHome: "홈",
                        defiWallet: "DeFi 지갑",
                        ETHWallet: "이더리움 지갑",
                        ethWallet: "eth 지갑"
                    }
                },
                HOME: {
                    download: "다운로드",
                    downloadNow: "지금 다운로드",
                    HEADER: {
                        title: "블록체인을 탐색할 수 있는 안전한 암호화폐 지갑",
                        desc_1: "토큰을 구입, 저장, 전송, 교환 및 수집하기 쉽고 안전합니다. 200개 이상의 국가 및 지역에서 2,000만 명 이상의 사용자가 사용합니다."
                    },
                    INTRODUCTION: {
                        title: "토큰포켓은 글로벌 사용자가 신뢰합니다",
                        desc_1: "토큰포켓은 전 세계 200여 개 국가와 지역에 안전하고 간편한 암호화폐 지갑 서비스를 제공하고 있습니다",
                        desc_2: "서비스 사용자",
                        desc_3: "일 트랜잭션",
                        desc_4: "지원 국가 및 지역"
                    },
                    SECURITY: {
                        title: "보안은 필수적입니다",
                        desc_1: "토큰포켓 사용자는 자신의 기기에서만 키와 비밀번호를 생성하고 저장하며 사용자 자신만이 계정과 자산에 액세스할 수 있습니다.",
                        desc_2: "토큰포켓은 또한 하드웨어 콜드 지갑 및 다중 서명 지갑 기능을 개발하여 필수에 따라 보안을 강화 가능합니다.",
                        desc_3: "BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, Cosmos, Polkadot, EOS, IOST 등을 지원합니다."
                    },
                    EXCHANGE: {
                        title: "쉬운 거래 및 전송",
                        desc_1: "토큰포켓에서 언제 어디서나 암호화폐를 거래할 수 있습니다.",
                        desc_2: "신용 카드로 암호화폐를 구매 가능. 쉬운 저장, 전송, 크로스 체인 및 거래.",
                        desc_3: "스왑",
                        desc_4: "쉽고 빠른",
                        desc_5: "브릿지",
                        desc_6: "다른 체인들 중",
                        desc_7: "암호화폐 구매",
                        desc_8: "5분 안에"
                    },
                    DAPPSTORE: {
                        title: "댑 스토어",
                        desc_1: "가장 좋아하는 탈중앙화 애플리케이션을 찾을 수 있으며, 최신 및 가장 인기있는 디앱을 찾고 지갑 내에서 사용 가능합니다.",
                        desc_2: "DApp 브라우저가 통합되어 링크를 통해 디앱을 이용 가능합니다.",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "지원"
                    },
                    COMMUNITY: {
                        title: "커뮤니티",
                        desc_1: "토큰포켓은 오픈 기술 커뮤니티이며 더 편리하고 안전하며 풍부한 블록체인 세상을 함께 구축할 모든 개발자를환영합니다",
                        desc_2: "TP-Lab",
                        desc_3: "커뮤니티",
                        desc_4: "개발자 문서"
                    },
                    DOWNLOAD: {title: "토큰포켓 지갑을 지금 다운로드하세요!", desc_1: "블록체인 탐색을 위한 안전하고 신뢰할 수 있는 암호화 지갑"},
                    FOLLOW: {
                        title: "우리를 따라오세요",
                        desc1: "TokenPocket 직원은 개인 메시지를 보내지 않습니다!",
                        desc2: "주의! TokenPocket 커뮤니티에 참여 중입니다. 누군가 우리를 사칭하여 개인 메시지를 보낼 수 있습니다! 개인 메시지를 보내는 사람은 모두 사기꾼일 수 있다는 점에 유의하세요! 우리는 당신에게 먼저 연락하지 않을 것입니다!",
                        desc3: "이해, 입력"
                    },
                    EXTENSIONMODAL: {
                        title: "확장 기능이 활성화되었습니다!",
                        desc1: "귀하의 Crypto & DeFi & GameFi",
                        desc2: "컴퓨터의 지갑",
                        btnText: "지금 사용",
                        btnTextm: "링크 복사",
                        tips: "링크를 성공적으로 복사하십시오. 열려면 컴퓨터로 이동하십시오"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "platform 명칭을 입력해주세요",
                        title: "DApp 명칭을 입력해주세요.",
                        address: "DApp컨트렉을 입력해주세요.",
                        url: "DApp웹사이트 주소를 입력해주세요.",
                        desc: "모든분의 자기소개 문구를 입력해주세요.",
                        icon_url: "DApp 아이콘을 업로드 해주세요.",
                        rakeBackAccount: "초대 리워드 컨트렉 계정을 입력해주세요.",
                        email: "이메일을 입력해주세요",
                        others: "기타 연락처 정보가 필요합니다",
                        tp_connect: "이 항목은 비워둘 수 없습니다."
                    },
                    title: "DApp 이름",
                    address: "DApp 컨트렉 주소",
                    url: "DApp 웹사이트 주소",
                    desc: "짦은 소개문구",
                    icon: "DApp 로고 (반드시 200x200 - JPG, PNG 지원)",
                    referral: "리퍼럴",
                    hasReferral: "리퍼럴 시스템이 있습니까?",
                    referralReward: "초대 리워드 분배방식",
                    reward_1: "초대 리워드 분배방식",
                    reward_2: "초대하신분은 DApp내부에서 수동으로 수령하셔야 합니다.",
                    hasInviteReward: "초대하신 분은 DApp내부에서 1회의 트랜섹션을 완료한후 초대 리워드를 활성화 할수 있습니다.",
                    inviteAccount: "초청 보상을 TP에 공개하기위한 계약 계정",
                    DAppRequirement: "DApp 요구사항",
                    requirement_1: "1. DApp은 TokenPocket 앱 및 TokenPocket 확장을 지원해야 합니다..",
                    requirement_2: "2. 프로젝트측에서 제공해주신 웹사이트 주소는 접근 가능하며 안전해야 합니다.",
                    requirement_3: "3. 스마트 컨트렉은 이미 메인넷에 응용이 되었으며 민감한 부분에 대하여 오픈소스로 전환해야 합니다.",
                    requirement_4: "4. 민감한 스마트 컨트렉은 제3자를 통해 안전성에 대한 검증 및 리포트가 필요합니다.",
                    requirement_5: "5. 상호적용 로직이 분명하며 모바일 유저인터페이스에도 응용이 되어야 합니다.",
                    requirement_6: "6. 관련되 법과 규제를 준수하며 범법및 침해행위를 하면 안됩니다.",
                    requirement_7: "7. 관련 법규를 위반할 경우 자발적으로 해당 법적 책임을지게됩니다. ",
                    dappInfo: "DApp 정보 :",
                    necessary: "필수",
                    language: "DApp 언어",
                    languageDesc: "(언어가 다양하면 별도로 제출하세요)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "한 문장으로 된 프로젝트에 대한 간략한 설명",
                    auditInfo: "감사 정보 :",
                    hasAudit: "계약 감사가 수행되었는지 여부",
                    auditUrl: "감사 보고서 URL",
                    auditUrlExample: "예 : https://auditlink.com",
                    auditReport: "감사 보고서",
                    auditUpload: "업로드",
                    contact: "연락처 세부 정보",
                    contactDesc: "우편함 이외의 고객 서비스 연락처 정보를 남겨 두십시오, 그렇지 않으면 검토를 통과하지 않을 것입니다",
                    emailAddr: "이메일",
                    emailExample: "예 : service@yourdomain.com",
                    others: "기타",
                    othersExample: "예 : Telegram ： @ 123456789",
                    auditOptional: "감사 정보 항목을 하나 이상 입력하십시오",
                    oversize: " 정규화 된 문자를 초과했습니다",
                    select: "선택",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "튜토리얼 보기>>"
                },
                DOWNLOAD: {
                    TITLE: "토큰포켓 다운로드",
                    TITLE_Android: "토큰포켓 안드로이드 버전",
                    TITLE_IOS: "토큰포켓 iOS 버전",
                    TITLE_Chrome: "토큰포켓 브라우저 버전",
                    TEXT: "토큰포켓은 수백만 명이 사용하는 쉽고 안전한 멀티 체인 암호화 지갑입니다.",
                    TEXT_Chrome: "토큰포켓 확장 지갑은 수백만 명이 쉽고 안전한 사용하며 모든 EVM 호환 체인을 지원하는 멀티 체인 암호화 지갑입니다.",
                    TEXT_PC: "TokenPocket 데스크톱은 EOS, ETH, BOS 그리고 TRON을 지원하는 가장 큰 멀티 블록체인 지갑입니다. 저희는 강력하고 안전한 디지털 자산 관리 솔루션을 제공해드립니다.",
                    scanCode: "코드 스캔",
                    installTutorial: "튜토리얼 설치",
                    desc_1: "공식 웹 사이트에서 앱을 다운로드하고 SSL 인증을 확인하십시오",
                    desc_2: "복구 구문(니모닉) 및 개인 키가 유출되지 않도록 안전하게 보관하고 타인과 절대 공유하지 마세요",
                    desc_3: "보안 팁 더 알아보기",
                    verifyText: "현재 APK 버전:",
                    verifyText1: "앱의 보안을 확인하는 방법",
                    verifyText2: "현재 버전:",
                    verifyText3: "현재 Google Play 버전:",
                    footerDesc_1: "BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST 등 지원",
                    footerDesc_2: "멀티 레이어 보안 보호 기능 제공",
                    footerDesc_3: "DeFi, DApp, GameFi, NFT 지원",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "는 공식적으로 TokenPocket의 유일한 iOS 앱 퍼블리셔로 지정되었습니다",
                    tp_wallet_version: "TP Wallet 버전:",
                    token_pocket_version: "Token Pocket 버전:",
                    delisted: "상장폐지",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "이메일을 입력해주세요.",
                        address: "컨트렉주소를 입력해세요.",
                        owner_address: "컨트렉 계정주소를 입력해주세요.",
                        symbol: "심볼을 입력해주세요.",
                        bl_symbol: "베이스 라인 심볼을 입력해주세요.",
                        total_supply: "총 공급량을 입력해주세요.",
                        decimal: "소수점을 입력해주세요.",
                        precision: "정밀도를 입력해주세요.",
                        gas: "기스 비용을 입력해주세요.",
                        website: "웹사이트를 입력해주세요.",
                        companyName: "회사 혹은 개인 이름을 입력해주세요.",
                        contact: "연락처를 입력해주세요.",
                        name: "프로젝트 소개를 입력해주세요.",
                        icon_url: "로고를 올려주세요."
                    }, icon: "토큰로고(200 * 200 픽셀, jpg, jpeg, png 포맷을 지원합니다).", handleText: "저희가 2 업무일 안에 처리해드리겠습니다."
                },
                RECRUITING: {
                    title: "TP Man 채용계획",
                    text: "TokenPocket 커뮤니티 가입",
                    text1: "블록체인 세계에 헌신하고 당신의 몫을 기여하십시오",
                    text2: "우리는 함께 Web3.0 세상을 만듭니다",
                    joinUs: "우리와 함께",
                    aboutTitle: "티피맨 소개",
                    aboutText: "TP Man은 TokenPocket 커뮤니티의 중요한 부분이며 글로벌 TP Men의 회원이 되실 수 있도록 진심으로 초대합니다!",
                    aboutText1: "당신은 블록체인 애호가이며 업계 가치를 인정합니다.",
                    aboutText2: "블록체인 세계를 탐험할 때 TokenPocket 지갑이 제공하는 편리함을 즐기십시오.",
                    missionTitle: "TP맨의 미션",
                    missionText: "TokenPocket이 전 세계의 더 많은 블록체인 사용자에게 서비스를 제공할 수 있도록 도와주세요. 다음 요구 사항 중 두 가지를 충족하여 지원하시기 바랍니다.",
                    missionText1: "다양한 채널을 통해 국내 기업이나 핫한 프로젝트와의 협력을 확대하고 추진하세요.",
                    missionText2: "지역 사용자의 요구에 맞는 마케팅 활동을 계획합니다.",
                    missionText3: "Twitter, Youtube, Telegram, Discord와 같은 주류 소셜 미디어를 운영할 수 있는 능력이 있어야 합니다.",
                    missionText4: "영어가 유창하고 번역 작업을 완료할 수 있습니다.",
                    missionText5: "TokenPocket은 글로벌 블록체인 사용자에게 더 많은 사용 및 기술 지원을 제공할 계획이므로 적어도 한 국가와 해당 사용자(인도, 미국, 터키, 러시아, 한국, 베트남, 필리핀 등)",
                    getTitle: "무엇을 얻습니까?",
                    getText: "블록체인 산업의 다양한 분야와 직접 관련된 업무 경험으로 DApp 프로젝트, 인플루언서 및 업계의 주류 미디어와의 커뮤니케이션 기회를 얻을 수 있습니다.",
                    getText1: "트윗 번역, 영상 제작, 커뮤니티 운영, 비즈니스 협력 등 풍부한 보상을 확보하세요.",
                    getText2: "가장 전문적인 블록체인 지식 교육을 받고 팀과 함께 Web3.0 세계를 탐험하십시오.",
                    getText3: "TokenPocket 맞춤형 의류 및 하드웨어 지갑을 포함한 TokenPocket 공식 혜택.",
                    processTitle: "채용 과정",
                    processText: "이력서 제출",
                    processText1: "화면 이력서",
                    processText2: "온라인 인터뷰",
                    processText3: "면접 결과",
                    processText4: "작업 확장",
                    applyTitle: "신청할 수 있는 사람",
                    applyText: "나라를 가리지 않고 세상을 마주하다",
                    applyText1: "블록체인 세계에 대한 관심과 호기심",
                    applyText2: "양식을 작성하고 이력서를 첨부하면 최대한 빨리 연락 드리겠습니다.",
                    footerTitle: "에 대한 TokenPocket",
                    footerText: "초과하다",
                    footerText1_1: "20M",
                    footerText1_2: "글로벌 사용자",
                    footerText2_1: "3.5M",
                    footerText2_2: "활성 사용자",
                    footerText3_1: "200",
                    footerText3_2: "국가 및 지역",
                    footerText4: "양식을 작성하고 이력서를 첨부하면 최대한 빨리 연락 드리겠습니다.",
                    footerText5: "출시 예정"
                },
                NAVIGATION: {
                    product: {
                        title: "생산품",
                        selfCustodyWallet: "모바일 지갑",
                        selfCustodyWalletDesc: "블록체인 진입, 모바일 멀티체인 지갑",
                        hardwareWallet: "하드웨어 지갑",
                        hardwareWalletDesc: "키팔로 자산을 보호하고 안전하고 안심하세요.",
                        extensionWallet: "플러그인 지갑",
                        extensionWalletDesc: "너의 컴퓨터에 더 좋은 지갑을 놓아라",
                        transit: "Transit",
                        transitDesc: "멀티체인 DEX 애그리게이터 및 NFT 마켓플레이스 플랫폼",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Web3.0의 소셜 네트워크 프로토콜",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "자체 보관 스테이킹과 소액 스테이킹을 모두 지원합니다",
                        buyCrypto: "암호화폐 구매",
                        buyCryptoDesc: "신용 카드로 암호화폐 구매하기"
                    },
                    assets: {title: "자산"},
                    collaborations: {title: "협업"},
                    community: {title: "커뮤니티", developers: "개발자", recruiting: "모병"},
                    helpCenter: {title: "도움"}
                },
                ABOUT: {
                    title: "소개",
                    desc: "토큰포켓'은 멀티 체인 탈중앙화 지갑으로 모바일 지갑, 웹 지갑 그리고 하드웨어 지갑을 제공하며 비트코인, 이더리움, 바이낸스 스마트 체인, 트론, 폴리곤, 솔라나, 앱토스, 폴카닷, EOS 및 모든 EVM 호환 체인을 지원합니다. 200개 이상의 국가 및 지역에서 2,000만 명 이상의 사용자에게 서비스를 제공합니다. 전 세계 이용자들의 신뢰를 받은 세계적인 암호화폐 지갑입니다.",
                    philosophy: {
                        title: "철학",
                        desc: "우리는 오픈 소스 기술 커뮤니티를 추구하며, 모든 개발자가 보다 편리하고 안전하며 풍부한 블록체인 세계를 함께 구축하기를 환영합니다.",
                        ambition: "포부",
                        ambition_desc: "블록체인을 모든 곳에 사용 될 수 있도록 만들겠습니다.",
                        value: "가치",
                        value_desc: "데이터를 사용자에게 돌려주고 가치를 실제 소유자가 가질 수 있게 합니다.",
                        attitude: "태도",
                        attitude_desc: "열린 마음으로 상호 협력합니다."
                    },
                    milestones: {
                        title: "이정표",
                        desc_2018_1: "토큰포켓 창립",
                        desc_2018_2: "Huobi, Hofan, Byte Capital로부터 투자 유치",
                        desc_2019_1: "트론 지원 데스크탑 지갑 출시",
                        desc_2019_2: "구글 플레이, 토큰포켓 앱 다운로드 100만 건 돌파",
                        desc_2020_1: "HD 지갑 지원",
                        desc_2020_2: "BSC 및 DeFi 프로젝트 지원",
                        desc_2020_3: "이더리움 2.0 스테이킹 지원",
                        desc_2021_1: "스왑 플랫폼 Transit 인큐베이팅",
                        desc_2021_2: "사용자 2천만명 돌파",
                        desc_2021_3: "하드웨어 지갑 KeyPal 인큐베이팅",
                        desc_2022_1: "dFox 인수 후 토큰포켓 웹 확장 지갑으로 브랜드 변경",
                        January: "1월",
                        February: "2월",
                        March: "3월",
                        April: "4월l",
                        May: "5월",
                        June: "6월",
                        July: "7월",
                        August: "8월",
                        September: "9월",
                        October: "10월",
                        November: "11월",
                        December: "12월"
                    },
                    contact_us: {
                        title: "문의하기",
                        service: "고객 서비스",
                        service_desc: "service@tokenpocket.pro",
                        bd: "사업 협업",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "개발자",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "토큰포켓 - 여러분의 범용 디지털 지갑입니다. | TP 지갑 - ETH  지갑 - BTC  지갑 - BSC  지갑 - HECO 지갑 - OKExChain 지갑 - Polkadot 지갑 - Kusama 지갑 - DeFi  지갑 - Layer 2 지갑 - EOS 지갑 - TRX 지갑 - nostr",
                    description: "TokenPocket is a world-leading digital currency wallet, supporting public blockchains including BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS and Layer 2.",
                    keywords: "TokenPocket,Token Pocket,TP wallet,Ethereum wallet,Bitcoin,EOS,IOST,COSMOS,heco,bsc,layer2,DeFi,wallet,암호화, 블록체인, web3,NFT,nostr"
                }
            }, ru: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "Отправитель пакета",
                    YES: "Да",
                    NO: "Нет",
                    HAS: "Да",
                    HAVENT: "Нет",
                    BLOCKCHAIN: "Блокчейн",
                    MULTIPLE_CHOICE: "(Множественный выбор)",
                    IS_SUPPORT_TP_CONNECT: "Поддерживает ли он подключение TokenPocket? (Расширение и мобильное приложение)",
                    SUPPORT_BOTH: "Поддерживаются оба",
                    SUPPORT_EXTENSION: "Только расширение",
                    SUPPORT_MOBILE: "Только для мобильных устройств",
                    SUPPORT_NONE: "Нет",
                    blockchainWallet: "Блокчейн-кошелек",
                    iostWallet: "Кошелек IOST",
                    tronWallet: "Кошелек ТRОN",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "Отправить",
                    symbol: "Имя токена",
                    success: "Success",
                    bl_symbol: "BL Symbol",
                    precision: "Точность токена",
                    decimal: "Десятичный токен",
                    totalSupply: "Общее предложение",
                    contract: "Токен-контракт",
                    website: "Официальный сайт",
                    introduction: "Введение токена",
                    example: "Пример",
                    submitTokenInfoAndLogo: "Обновить логотип токена и другую информацию",
                    toGithubSubmit: "Перейти на Github",
                    nftType: "Стандарт протокола NFT",
                    LAYOUT: {
                        features: "Особенности",
                        buyCrypto: "Купить криптовалюту",
                        mobileWallet: "Мобильный кошелек",
                        hardwareWallet: "Аппаратный кошелек",
                        extensionWallet: "Расширение кошелька",
                        desktop: "Настольный кошелек",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "Детектор одобрения",
                        tokenSecurity: "Безопасность токена",
                        keyGenerator: "Генератор ключей",
                        information: "Информация",
                        blockchainGuide: "Руководство по блокчейну",
                        tronWallet: "Руководство по TRON",
                        iostWallet: "Руководство по IOST",
                        tpMan: "ТП-мужчина",
                        developers: "Разработчики",
                        github: "Github (TP-Lab)",
                        devCenter: "Центр разработки",
                        subToken: "Отправить токен",
                        subDApp: "Отправить DApp",
                        subNFT: "Отправить NFT",
                        subChain: "Цепь",
                        company: "Компания",
                        about: "О",
                        careers: "Карьера",
                        pressKit: "Пресс-кит",
                        swagShop: "Магазин сувениров",
                        support: "Поддержка",
                        helpCenter: "Справочный центр",
                        contactUs: "Свяжитесь с нами",
                        legal: "Юридический",
                        privacyPolicy: "Privacy Policy",
                        terms: "Terms of Use",
                        toHome: "Дом",
                        defiWallet: "Кошелек DeFi",
                        ETHWallet: "Кошелек Эфириума",
                        ethWallet: "ETH-кошелек"
                    }
                },
                HOME: {
                    download: "Скачать",
                    downloadNow: "Скачать сейчас",
                    HEADER: {
                        title: "Ваш безопасный криптокошелек для изучения блокчейна",
                        desc_1: "Легко и безопасно покупать, хранить, отправлять, обменивать токены и собирать NFT. Нам доверяют более 20 миллионов пользователей из более чем 200 стран и регионов."
                    },
                    INTRODUCTION: {
                        title: "TokenPocket доверяют пользователи со всего мира",
                        desc_1: "Мы предоставляем безопасный и простой сервис криптовалютного кошелька в более чем 200 странах и регионах по всему миру",
                        desc_2: "Обслуживание пользователей",
                        desc_3: "Ежедневные транзакции",
                        desc_4: "Поддерживаемые страны и регионы"
                    },
                    SECURITY: {
                        title: "Безопасность, какой она должна быть",
                        desc_1: "TokenPocket генерирует и хранит ключи и пароли только на вашем устройстве, только вы можете получить доступ к своей учетной записи и активам.",
                        desc_2: "TokenPocket также разрабатывает аппаратный холодный кошелек и функцию кошелька с несколькими подписями для повышения безопасности по мере необходимости.",
                        desc_3: "Поддержка BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, Cosmos, Polkadot, EOS, IOST и т. д."
                    },
                    EXCHANGE: {
                        title: "Легкий обмен и транзакции",
                        desc_1: "Вы можете торговать своей криптовалютой в любое время и в любом месте в TokenPocket.",
                        desc_2: "Покупайте криптовалюту с помощью кредитных карт. С легкостью храните, отправляйте, пересекайте цепочки и обменивайте.",
                        desc_3: "Swap",
                        desc_4: "Мгновенно и легко",
                        desc_5: "Bridge",
                        desc_6: "Среди разных цепочек",
                        desc_7: "Купить криптовалюту",
                        desc_8: "Через 5 минут"
                    },
                    DAPPSTORE: {
                        title: "Магазин децентрализованных приложений",
                        desc_1: "Вы можете найти свои любимые децентрализованные приложения, открыть для себя последние и самые популярные и использовать их, не выходя из кошелька.",
                        desc_2: "Браузер DApp интегрирован, вы всегда можете получить доступ к DApps по своим ссылкам.",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "Supported"
                    },
                    COMMUNITY: {
                        title: "Сообщество",
                        desc_1: "Мы настаиваем на открытом технологическом сообществе и приглашаем всех разработчиков вместе создавать более удобный, безопасный и богатый блокчейн-мир",
                        desc_2: "TP-Lab",
                        desc_3: "Сообщество",
                        desc_4: "Dev Docs"
                    },
                    DOWNLOAD: {
                        title: "Получить кошелек TokenPocket прямо сейчас!",
                        desc_1: "Ваш безопасный и надежный криптокошелек для изучения блокчейна"
                    },
                    FOLLOW: {
                        title: "Подписывайтесь на нас",
                        desc1: "Сотрудники TokenPocket не будут отправлять вам личные сообщения!",
                        desc2: "Осторожность! Вы входите в сообщество TokenPocket, возможно, кто-то выдает себя за нас, чтобы отправлять вам личные сообщения! Имейте в виду, что любой, кто отправляет личные сообщения, может быть мошенником! Мы никогда не свяжемся с вами первыми!",
                        desc3: "Понятно, вводите"
                    },
                    EXTENSIONMODAL: {
                        title: "Расширение запущено!",
                        desc1: "Ваша криптовалюта, DeFi и GameFi",
                        desc2: "кошелек на компьютере",
                        btnText: "Использовать сейчас",
                        btnTextm: "Копировать ссылку",
                        tips: "Скопируйте ссылку успешно, перейдите на компьютер, чтобы открыть"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "Требуется платформа",
                        title: "Требуется имя децентрализованного приложения",
                        address: "Требуется контракт DApp",
                        url: "Требуется веб-сайт DApp",
                        desc: "Требуется описание",
                        icon_url: "Требуется логотип децентрализованного приложения",
                        rakeBackAccount: "Требуется контрактный аккаунт",
                        email: "Требуется электронная почта",
                        others: "Требуется другая контактная информация",
                        tp_connect: "Этот элемент не может быть пустым"
                    },
                    title: "Имя децентрализованного приложения",
                    address: "Смарт-контракт",
                    url: "Веб-сайт децентрализованного приложения",
                    desc: "Краткое описание",
                    icon: "Логотип DApp (должен быть 200 x 200 – поддерживается формат JPG, PNG)",
                    referral: "Реферал",
                    hasReferral: "Есть ли реферальная система",
                    referralReward: "Распределение реферального вознаграждения",
                    reward_1: "Автоматически распределять по смарт-контракту (Live)",
                    reward_2: "Необходимо запросить его в DApp вручную",
                    hasInviteReward: "Нужно ли приглашающему совершить транзакцию в DApp, чтобы активировать реферальную ссылку",
                    inviteAccount: "Смарт-контракт распределения рефералов",
                    DAppRequirement: "Требование DApp",
                    requirement_1: "1. DApp должен поддерживать мобильное приложение TokenPocket и расширение TokenPocket.",
                    requirement_2: "2. Предоставленный веб-сайт доступен и стабилен.",
                    requirement_3: "3. Смарт-контракты развернуты в основной сети, а конфиденциальная часть должна быть с открытым исходным кодом.",
                    requirement_4: "4. Конфиденциальные контракты требуют аудиторских отчетов от сторонних агентств безопасности.",
                    requirement_5: "5. Логика взаимодействия понятна и адаптирована к мобильному интерфейсу.",
                    requirement_6: "6. Соблюдайте соответствующие законы и постановления без мошенничества и нарушений.",
                    requirement_7: "7. Если вы нарушите соответствующие законы и постановления, вы добровольно возьмете на себя соответствующую юридическую ответственность.",
                    dappInfo: "Информация о децентрализованном приложении:",
                    necessary: "требуется",
                    language: "Язык DApp",
                    languageDesc: "(Пожалуйста, отправьте отдельно для нескольких языков)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "Краткое описание проекта в одном предложении, которое появится в подзаголовке DApp",
                    auditInfo: "Информация аудита:",
                    hasAudit: "Проведен ли аудит договора",
                    auditUrl: "URL отчета об аудите",
                    auditUrlExample: "Например: https://auditlink.com",
                    auditReport: "Аудиторский отчет",
                    auditUpload: "Загрузить",
                    contact: "Контактная информация",
                    contactDesc: "Пожалуйста, не забудьте оставить контактную информацию службы поддержки, кроме почтового ящика, иначе она не пройдет проверку",
                    emailAddr: "Электронная почта",
                    emailExample: "Например: service@yourdomain.com",
                    others: "Другое",
                    othersExample: "Например: Telegram：@123456789",
                    auditOptional: "Заполните хотя бы один пункт информации об аудите",
                    oversize: "превышено допустимое количество символов",
                    select: "Выбрать",
                    tutorial_url: "https://help.tokenpocket.pro/developer-ru/",
                    tutorial: "Просмотреть учебник>>"
                },
                DOWNLOAD: {
                    TITLE: "Скачать TokenPocket",
                    TITLE_Android: "TokenPocket для Android",
                    TITLE_IOS: "TokenPocket для iOS",
                    TITLE_Chrome: "TokenPocket для вашего браузера",
                    TEXT: "TokenPocket — это простой и безопасный крипто-кошелек с несколькими цепочками, которому доверяют миллионы",
                    TEXT_Chrome: "Расширение TokenPocket — это крипто-кошелек с несколькими цепочками, поддерживающий все цепочки, совместимые с EVM. Простое и безопасное использование, которому доверяют миллионы.",
                    TEXT_PC: "TokenPocket Desktop — это крупнейший мультиблокчейн-кошелек на основе EOS ETH BOS TRON, мы стремимся предоставить пользователям мощное и безопасное управление цифровыми активами.",
                    scanCode: "Сканировать для загрузки",
                    installTutorial: "Учебник по установке",
                    desc_1: "Скачайте приложение с официального сайта и проверьте его сертификат SSL",
                    desc_2: "Защитите свою фразу восстановления (мнемонику) и закрытый ключ от утечки, никогда не передавайте их другим",
                    desc_3: "Узнайте больше советов по безопасности",
                    verifyText: "Последняя версия APK:",
                    verifyText1: "Как проверить безопасность приложения",
                    verifyText2: "Последняя версия:",
                    verifyText3: "Последняя версия Google Play:",
                    footerTitle: "Производите отличное первое впечатление",
                    footerDesc_1: "Поддержка BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST и т. д.",
                    footerDesc_2: "Многоуровневая защита",
                    footerDesc_3: "Поддерживаются DeFi, DApp, GameFi и NFT",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "официально назначена единственным издателем iOS-приложения TokenPocket",
                    tp_wallet_version: "TP Wallet Версия:",
                    token_pocket_version: "Token Pocket Версия:",
                    delisted: "Исключен из списка",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "Требуется электронная почта",
                        address: "Требуется адрес",
                        owner_address: "Требуется адрес владельца",
                        "символ": "Требуется символ",
                        bl_symbol: "Требуется символ BL",
                        total_supply: "Требуется общий запас",
                        decimal: "Требуется десятичный",
                        precision: "Требуется точность",
                        gas: "Требуется ГАЗ",
                        website: "Требуется веб-сайт",
                        companyName: "Требуется название компании или имя",
                        contact: "Требуется контакт",
                        name: "Требуется представление проекта",
                        icon_url: "Требуется логотип"
                    },
                    icon: "Логотип токена (200 * 200 пикселей, поддержка jpg, jpeg, png, формат именования файла изображения: имя токена, логотипу не нужны закругленные углы)",
                    handleText: "Мы обработаем ваш запрос в течение 2 рабочих дней"
                },
                RECRUITING: {
                    title: "План найма TP Man",
                    text: "Присоединяйтесь к сообществу TokenPocket",
                    text1: "Приверженность миру блокчейна и внесите свой вклад",
                    text2: "Вместе мы строим мир Web3.0",
                    joinUs: "Присоединяйтесь к нам",
                    aboutTitle: "О ТП Мэн",
                    aboutText: "TP Man — важная часть сообщества TokenPocket, и мы искренне приглашаем вас присоединиться к нам!",
                    aboutText1: "Вы энтузиаст блокчейна и поддерживаете ценность отрасли.",
                    aboutText2: "Наслаждайтесь удобством кошелька TokenPocket при изучении мира блокчейна.",
                    missionTitle: "Миссия TP Man",
                    missionText: "Помогите TokenPocket обслуживать больше пользователей блокчейна по всему миру. Мы надеемся, что вы соответствуете двум из следующих требований, чтобы подать заявку",
                    missionText1: "Расширяйте и продвигайте сотрудничество TokenPocket с компаниями или популярными проектами в вашей стране по различным каналам.",
                    missionText2: "Планируйте маркетинговые мероприятия, отвечающие потребностям местных пользователей",
                    missionText3: "Иметь возможность работать с основными социальными сетями, такими как Twitter, Youtube, Telegram и Discord.",
                    missionText4: "Свободное владение английским языком и умение выполнять переводческие работы",
                    missionText5: "TokenPocket планирует обеспечить более широкое использование и техническую поддержку для глобальных пользователей блокчейна, поэтому мы надеемся, что у вас есть определенное понимание рынков блокчейнов не менее чем в одной стране и их пользователей (Индия, США, Турция, Россия, Южная Корея, Вьетнам, Филиппины и др.)",
                    getTitle: "Что вы получите?",
                    getText: "Опыт работы, непосредственно связанный с различными областями индустрии блокчейнов, и вы получите, помимо прочего, возможности общения с проектами DApp, влиятельными лицами и основными СМИ в отрасли..",
                    getText1: "Получайте щедрые вознаграждения за свою работу, такую ​​как перевод твитов, создание видео, работа в сообществе и деловое сотрудничество..",
                    getText2: "Получите самое профессиональное обучение по блокчейну и исследуйте мир Web3.0 вместе с командой.",
                    getText3: "Официальные преимущества TokenPocket, включая TokenPocket Swag и аппаратные кошельки.",
                    processTitle: "Процесс набора",
                    processText: "Отправить резюме",
                    processText1: "проверка резюме",
                    processText2: "Онлайн-интервью ",
                    processText3: "Результаты интервью",
                    processText4: "Добро пожаловать на борт",
                    applyTitle: "Кто может подать заявку",
                    applyText: "Лицом к миру, независимо от страны",
                    applyText1: "Будьте увлечены и любопытны в мире блокчейна",
                    applyText2: "Заполните форму и прикрепите свое резюме, тогда мы свяжемся с вами в ближайшее время",
                    footerTitle: "О TokenPocket",
                    footerText: "над",
                    footerText1_1: "20M",
                    footerText1_2: "глобальные пользователи",
                    footerText2_1: "3.5M",
                    footerText2_2: "ежемесячно активных пользователей",
                    footerText3_1: "200",
                    footerText3_2: "страны и регионы",
                    footerText4: "TokenPocket — ведущий в мире мультичейн-кошелек с самостоятельным хранением.",
                    footerText5: "Вскоре"
                },
                NAVIGATION: {
                    product: {
                        title: "Товар",
                        selfCustodyWallet: "Мобильный кошелек",
                        selfCustodyWalletDesc: "Мобильный кошелек Crypto&DeFi на блокчейне.",
                        hardwareWallet: "Аппаратный кошелек",
                        hardwareWalletDesc: "Получите свой KeyPal, чтобы защитить свои активы.",
                        extensionWallet: "Расширение кошелька",
                        extensionWalletDesc: "Лучший кошелек на вашем компьютере.",
                        transit: "Transit",
                        transitDesc: "Многоцепочечный агрегатор DEX и торговая площадка NFT.",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Протокол социальной сети в Web3.0.",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "Поддерживает и самостоятельный стейкинг, и стейкинг с небольшими суммами",
                        buyCrypto: "Покупка криптовалюты",
                        buyCryptoDesc: "Покупайте криптовалюту с помощью кредитных карт"
                    },
                    assets: {title: "Ресурсы"},
                    collaborations: {title: "Сотрудничество"},
                    community: {title: "Сообщество", developers: "Разработчик", recruiting: "ТП-мужчина"},
                    helpCenter: {title: "Помощь"}
                },
                ABOUT: {
                    title: "About Us",
                    desc: "TokenPocket is a multi-chain decentralized wallet, it provides users with mobile wallet, extension wallet and hardware wallet, supporting public chains including Bitcoin, Ethereum, BNB Smart Chain, TRON, Aptos, Polygon, Solana, Polkadot, EOS and all EVM compatible chains. Serving over 20 millions users from more than 200 countries and regions. It is a world-wide leading crypto wallet that trusted by global users.",
                    philosophy: {
                        title: "Our philosophy",
                        desc: "We insist on an open technology community, and we welcome all developers to build a more convenient, secure and richer blockchain world together",
                        ambition: "Ambition",
                        ambition_desc: "Make the blockchain happen everywhere",
                        value: "Value",
                        value_desc: "Let data return to users, make value belong to real owners",
                        attitude: "Attitude",
                        attitude_desc: "Open-minded, mutual collaboration"
                    },
                    milestones: {
                        title: "Milestones",
                        desc_2018_1: "TokenPocket Founded",
                        desc_2018_2: "Invested by Huobi, Hofan, Byte Capital",
                        desc_2019_1: "Released desktop wallet, supported TRON",
                        desc_2019_2: "Google Play download exceeded 1,000,000",
                        desc_2020_1: "HD wallet supported",
                        desc_2020_2: "Supported BSC and DeFi tendency",
                        desc_2020_3: "Supported Eth2.0 Staking",
                        desc_2021_1: "Incubated Transit",
                        desc_2021_2: "User base exceeded 20,000,000",
                        desc_2021_3: "Incubated KeyPal hardware wallet",
                        desc_2022_1: "Acquired dFox and rebranded to TokenPocket Extension",
                        January: "January",
                        February: "February",
                        March: "March",
                        April: "April",
                        May: "May",
                        June: "June",
                        July: "July",
                        August: "August",
                        September: "September",
                        October: "October",
                        November: "November",
                        December: "December"
                    },
                    contact_us: {
                        title: "Contact Us",
                        service: "Customer Service",
                        service_desc: "service@tokenpocket.pro",
                        bd: "Business Collaborations",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "Developers",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - Ваш универсальный цифровой кошелек | Кошелек TP - Кошелек ETH - Кошелек BTC - Кошелек BSC - Кошелек HECO - Кошелек OKExChain - Кошелек Polkadot - Кошелек Kusama - Кошелек DeFi - Кошелек Layer 2 - Кошелек EOS - Кошелек TRX - nostr",
                    description: "TokenPocket — это ведущий в мире кошелек цифровой валюты, поддерживающий общедоступные блокчейны, включая BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS и Layer 2.",
                    keywords: "TokenPocket, Token Pocket, кошелек TP, кошелек Ethereum, биткойн, EOS, IOST, COSMOS, heco, bsc, layer2, DeFi, кошелек,крипто,блокчейн,web3,NFT,nostr"
                }
            }, es: {
                COMMON: {
                    EMAIL: "Correo electrónico",
                    BATCH_SENDER: "Envío por lotes",
                    YES: "Sí",
                    NO: "No",
                    HAS: "Sí",
                    HAVENT: "No",
                    BLOCKCHAIN: "Blockchain",
                    MULTIPLE_CHOICE: "(Opción múltiple)",
                    IS_SUPPORT_TP_CONNECT: "¿Admite la conexión de TokenPocket? (Extensión y aplicación móvil)",
                    SUPPORT_BOTH: "Se aceptan ambos",
                    SUPPORT_EXTENSION: "Sólo la extensión",
                    SUPPORT_MOBILE: "Sólo móvil",
                    SUPPORT_NONE: "Ninguno",
                    blockchainWallet: "Billetera Blockchain",
                    iostWallet: "Billetera IOST",
                    tronWallet: "Billetera TRON",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "Envía",
                    symbol: "Nombre del Token",
                    success: "Success",
                    bl_symbol: "Símbolo BL",
                    precision: "Precision del Token",
                    decimal: "Token Decimal",
                    totalSupply: "Emisión total",
                    contract: "Contrato del Token",
                    website: "Sitio web oficial",
                    introduction: "Presentación del token",
                    example: "Ejemplo",
                    submitTokenInfoAndLogo: "Actualiza el logotipo del token y otra información",
                    toGithubSubmit: "Ve a Github",
                    nftType: "Estándar de protocolo del NFT",
                    LAYOUT: {
                        features: "Características",
                        buyCrypto: "Compra cripto",
                        mobileWallet: "Billetera móvil",
                        hardwareWallet: "Billetera de hardware",
                        extensionWallet: "Extensión de la Billetera",
                        desktop: "Cartera de escritorio",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "Detector de aprobación",
                        tokenSecurity: "Seguridad de Token",
                        keyGenerator: "Generador de Claves",
                        information: "Información",
                        blockchainGuide: "Guía de cadena de bloques",
                        tronWallet: "Guía de TRON",
                        iostWallet: "Guía de IOST",
                        tpMan: "TP Man",
                        developers: "Desarrolladores",
                        github: "Github (TP-Lab)",
                        devCenter: "Centro de Desarrollo",
                        subToken: "Enviar token",
                        subDApp: "Enviar DApp",
                        subNFT: "Enviar NFT",
                        subChain: "Cadena",
                        company: "Compañía",
                        about: "Acerca de",
                        careers: "Empleos",
                        pressKit: "Kit de Prensa",
                        swagShop: "Tienda de artículos de regalo",
                        support: "Soporte",
                        helpCenter: "Centro de Asistencia",
                        contactUs: "Contáctanos",
                        legal: "Legal",
                        privacyPolicy: "Política de Privacidad",
                        terms: "Términos de Uso",
                        toHome: "Página Principal",
                        defiWallet: "Billetera DeFi",
                        ETHWallet: "Ethereum na Wallet",
                        ethWallet: "Billetera ETH"
                    }
                },
                HOME: {
                    download: "Descargar",
                    downloadNow: "Descarga ahora",
                    HEADER: {
                        title: "Su billetera cripto segura para explorar la blockchain",
                        desc_1: "Fácil y segura para comprar, almacenar, enviar, intercambiar tokens y recolectar NFT. Con la confianza de más de 20 millones de usuarios de más de 200 países y regiones."
                    },
                    INTRODUCTION: {
                        title: "Los usuarios globales confían en TokenPocket",
                        desc_1: "Brindamos un servicio de billetera cripto, fácil de usar entre más de 200 países y regiones de todo el mundo",
                        desc_2: "Atención al usuario",
                        desc_3: "Transacciones Diarias",
                        desc_4: "Países y regiones que apoyan"
                    },
                    SECURITY: {
                        title: "Seguridad como debe ser",
                        desc_1: "TokenPocket genera y almacena claves y contraseñas solo en su dispositivo, solo usted puede acceder a su cuenta y activos.",
                        desc_2: "TokenPocket también desarrolla una billetera hardware y una función de billetera de múltiples firmas, para mejorar la seguridad según lo necesite.",
                        desc_3: "Compatible con BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, Cosmos, Polkadot, EOS, IOST, etc."
                    },
                    EXCHANGE: {
                        title: "Intercambia y realiza transacciones fácilmente",
                        desc_1: "Puede intercambiar tus criptos en cualquier momento y en cualquier lugar dentro de TokenPocket.",
                        desc_2: "Compre criptomonedas con tarjetas de crédito. Almacene, envíe, intercambie entre diferentes cadenas con facilidad.",
                        desc_3: "Swap",
                        desc_4: "Al instante y fácilmente",
                        desc_5: "Bridge",
                        desc_6: "Entre diferentes cadenas",
                        desc_7: "Compra cripto",
                        desc_8: "En 5 minutos"
                    },
                    DAPPSTORE: {
                        title: "Una tienda DApp",
                        desc_1: "Puede encontrar sus aplicaciones descentralizadas favoritas, descubrir las más populares y recientes y como si fuera poco sin salir de la billetera.",
                        desc_2: "Navegador DApp integrado, siempre puede acceder a las DApps con sus enlaces.",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "Soportado"
                    },
                    COMMUNITY: {
                        title: "Comunidad",
                        desc_1: "Insistimos en una comunidad de tecnología abierta (Open Source), y damos la bienvenida a todos los desarrolladores para que construyamos entre todos un mundo blockchain más conveniente, seguro y próspero",
                        desc_2: "TP-Lab",
                        desc_3: "Comunidad",
                        desc_4: "Dev Docs"
                    },
                    DOWNLOAD: {
                        title: "¡Obten la billetera TokenPocket ahora!",
                        desc_1: "Su billetera cripto segura y confiable para explorar la blockchain"
                    },
                    FOLLOW: {
                        title: "Síganos",
                        desc1: "TokenPocket Staffs no te enviará mensajes privados!",
                        desc2: "¡Precaución! Está ingresando a la comunidad TokenPocket, ¡podría haber alguien haciéndose pasar por nosotros para enviarle mensajes privados! ¡Tenga en cuenta que cualquier persona que envíe mensajes privados podría ser un estafador! ¡Nunca te contactaremos primero!",
                        desc3: "Entendido, entra"
                    },
                    EXTENSIONMODAL: {
                        title: "¡La extensión ya está disponible!",
                        desc1: "Tus Cripto y DeFi y GameFi",
                        desc2: "billetera en la computadora",
                        btnText: "Úsalo ahora",
                        btnTextm: "Copiar el enlace",
                        tips: "Copie el enlace, vaya a la computadora para abrir"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "Se requiere plataforma",
                        title: "Se requiere el nombre de la DApp",
                        address: "Se requiere contrato de la DApp",
                        url: "Se requiere el sitio web de la DApp",
                        desc: "Se requiere Desc+",
                        icon_url: "Se requiere el logotipo de la DApp",
                        rakeBackAccount: "Se requiere cuenta del contrato",
                        email: "Se requiere de un correo electrónico",
                        others: "Se requiere otra información de contacto",
                        tp_connect: "Este elemento no puede estar en vacío"
                    },
                    title: "Nombre de la DApp",
                    address: "Contrato inteligente",
                    url: "Sitio web de la DApp",
                    desc: "Breve descripción",
                    icon: "Logotipo de la DApp (debe ser de 200 x 200; admite JPG, PNG).",
                    referral: "Referidol",
                    hasReferral: "Tiene un programa de referidos?",
                    referralReward: "Distribución de la recompensa por referidos",
                    reward_1: "Distribuir automáticamente por el contrato inteligente (Live)",
                    reward_2: "Necesita reclamarlo en la DApp manualmente",
                    hasInviteReward: "¿El remitente necesita hacer una transacción en la DApp para activar el enlace de referencia?",
                    inviteAccount: "El contrato inteligente de distribución por referidos",
                    DAppRequirement: "Requisito de la DApp",
                    requirement_1: "1. La DApp debe ser compatible tanto con la versión móvil como la extensión de TokenPocket.",
                    requirement_2: "2. El sitio web proporcionado es accesible y estable.",
                    requirement_3: "3. Los contratos inteligentes se implementaron en la red principal y la parte sensible debe ser de código abierto.",
                    requirement_4: "4. Los contratos sensibles requieren informes de auditoría por parte de agencias de seguridad certificadas por terceros.",
                    requirement_5: "5. La lógica de interacción es clara y se ha adaptado a la interfaz de usuario móvil.",
                    requirement_6: "6. Obedecer las leyes y reglamentos pertinentes, sin hechos de fraude ni infracción.",
                    requirement_7: "7. Si viola las leyes y regulaciones pertinentes, asumirá voluntariamente las responsabilidades legales correspondientes.",
                    dappInfo: "Información de la aplicación DApp:",
                    necessary: "requerido",
                    language: "Idioma de la DApp",
                    languageDesc: "(Envíe por separado para varios idiomas)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "Una breve descripción del proyecto en una frase, que aparecerá en el subtítulo de la DApp",
                    auditInfo: "Información de auditoría:",
                    hasAudit: "Si se ha realizado la auditoría del contrato.",
                    auditUrl: "URL del informe de auditoría",
                    auditUrlExample: "Por ejemplo: https://auditlink.com",
                    auditReport: "Informe de auditoría",
                    auditUpload: "Subir",
                    contact: "Detalles de contacto",
                    contactDesc: "Asegúrese de dejar la información de contacto del Servicio de Atención al Cliente que no sea el buzón, de lo contrario no pasará la revisión.",
                    emailAddr: "Correo electrónico",
                    emailExample: "Por ejemplo: servicio@tudominio.com",
                    others: "Otro",
                    othersExample: "Por ejemplo: Telegram: @123456789",
                    auditOptional: "Complete al menos un elemento de la información de auditoría",
                    oversize: " ha excedido los caracteres permitidos",
                    select: "Seleccione",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "Ver tutorial>>"
                },
                DOWNLOAD: {
                    TITLE: "Descargar TokenPocket",
                    TITLE_Android: "TokenPocket para Android",
                    TITLE_IOS: "TokenPocket para iOS",
                    TITLE_Chrome: "TokenPocket para tu navegador",
                    TEXT: "TokenPocket es una billetera criptográfica multi-cadena, fácil y segura de usar en la que confían millones de personas.",
                    TEXT_Chrome: "TokenPocket Extension es una billetera criptográfica multi-cadena, es compatible con todas las cadenas EVM. Fácil y segura de usar en el que confían millones de personas.",
                    TEXT_PC: "TokenPocket Desktop es la billetera multi-blockchain más grande basada en BTC ETH EOS ETH BOS TRON , nos esforzamos por brindarle a los usuarios una gestión, sólida y segura de sus activos digitales ",
                    scanCode: "Escanear para descargar",
                    installTutorial: "Tutorial de instalación",
                    desc_1: "Descarga la aplicación desde el sitio web oficial y verifique su certificación SSL",
                    desc_2: "Proteja su Frase de Recuperación (mnemotécnica) y Clave Privada de robos, nunca las comparta con otros",
                    desc_3: "Más información sobre consejos de seguridad",
                    verifyText: "Última versión de APK:",
                    verifyText1: "Cómo verificar la seguridad de una aplicación",
                    verifyText2: "Última versión:",
                    verifyText3: "Última versión de Google Play:",
                    footerDesc_1: "Compatible con BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST, etc.",
                    footerDesc_2: "Protecciones de seguridad multicapa",
                    footerDesc_3: "Compatible con DeFi, DApp, GameFi y NFT",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "ha sido designado oficialmente como el único editor de aplicaciones para iOS de TokenPocket",
                    tp_wallet_version: "TP Wallet Versión:",
                    token_pocket_version: "Token Pocket Versión:",
                    delisted: "Excluido",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "Se requiere de un correo electrónico",
                        address: "Se requiere de una dirección válida",
                        owner_address: "Se requiere la dirección del propietario",
                        symbol: "Se requiere del símbolo",
                        bl_symbol: "Se requiere el símbolo BL",
                        total_supply: "Se requiere de la emisión total",
                        decimal: "Se requiere el Decimal",
                        precision: "Se requiere de la Precisión",
                        gas: "Se requiere GAS",
                        website: "Se requiere sitio web",
                        companyName: "Se requiere el nombre de la empresa o del responsable",
                        contact: "Se requiere Información de Contacto",
                        name: "Se requiere presentación del proyecto",
                        icon_url: "Se requiere del logotipo"
                    },
                    icon: "Logotipo de token (200 * 200 píxeles, compatible con jpg, jpeg, png, formato de nombre de archivo de imagen: nombre de token, el logotipo no necesita esquinas redondeadas)",
                    handleText: "Procesaremos su solicitud en 2 días hábiles"
                },
                RECRUITING: {
                    title: " Programa de Reclutamiento de TP Man",
                    text: "Únase a la comunidad de TokenPocket",
                    text1: "Intégrate en el mundo blockchain y aporta tu grano de arena",
                    text2: "Construimos juntos un mundo Web3.0",
                    joinUs: "Únete a nosotros",
                    aboutTitle: "Acerca de TP Man",
                    aboutText: "TP Man es una parte importante de la comunidad TokenPocket, e invitamos cordialmente a unirse a nosotros!",
                    aboutText1: "Eres un entusiasta de blockchain y respaldas el valor de la industria.",
                    aboutText2: "Disfrute de la comodidad que le brinda la billetera TokenPocket cuando explore el mundo de la cadena de bloques.",
                    missionTitle: "La Misión del TP Man",
                    missionText: "Contribuya junto a TokenPocket a proporcionar a más usuarios, los servicios de la blockchain en todo el mundo. Esperamos que cumpla con dos de los siguientes requisitos para aplicar.",
                    missionText1: "Expandir y promover la cooperación de TokenPocket con empresas o proyectos tendencia en su país, a través de varios canales",
                    missionText2: "Planificar actividades de marketing que satisfagan las necesidades de los usuarios locales.",
                    missionText3: "Tener la capacidad de manejar las principales redes sociales como Twitter, Youtube, Telegram y Discord",
                    missionText4: "Fluidez en inglés y ser capaz de completar el trabajo de traducción.",
                    missionText5: "TokenPocket planea brindar más usos y soporte técnico para los usuarios globales de la blockchain, por lo que esperamos que tenga una cierta comprensión de los mercados de blockchain de no menos de un país y así como también de sus usuarios (India, Estados Unidos, Turquía, Rusia, Corea del Sur, Vietnam, Filipinas, etc.)",
                    getTitle: "¿Qué obtendrás?",
                    getText: "Una experiencia laboral directamente relacionada con varios campos de la industria Blockchain, y obtendrá oportunidades de interacción con proyectos DApp, Influencers y los principales medios de comunicación de la industria.",
                    getText1: "Obtén jugosas recompensas de acuerdo a su trabajo, como la traducción de tweets, la creación de videos, administración de los canales de información y cooperación empresarial.",
                    getText2: "Obtén la mejor capacitación profesional en temas de blockchain y explore junto al equipo, el mundo Web3.0.",
                    getText3: "Beneficios oficiales de TokenPocket, incluidos material de regalo de TokenPocket y billeteras de hardware.",
                    processTitle: "Proceso de reclutamiento",
                    processText: "Enviar CV",
                    processText1: "Selección rigurosa de CV",
                    processText2: "Entrevista en línea",
                    processText3: "Resultados de la entrevista",
                    processText4: "Bienvenido a bordo",
                    applyTitle: "¿Quién puede aplicar?",
                    applyText: "Enfréntate al mundo, sin importar el país",
                    applyText1: "Ser entusiasta y curioso sobre el mundo de la cadena de bloques",
                    applyText2: "Rellena el formulario y adjunta tu currículum, luego nos pondremos en contacto contigo lo antes posible",
                    footerTitle: "Acerca de TokenPocket",
                    footerText: "sobre",
                    footerText1_1: "20M",
                    footerText1_2: "usuarios globales",
                    footerText2_1: "3.5M",
                    footerText2_2: "usuarios activos mensuales",
                    footerText3_1: "200",
                    footerText3_2: "países y regiones",
                    footerText4: "TokenPocket es la billetera auto custodiada y multi-cadenas líder en el mundo",
                    footerText5: "Próximamente"
                },
                NAVIGATION: {
                    product: {
                        title: "Producto",
                        selfCustodyWallet: "Billetera Movil",
                        selfCustodyWalletDesc: "Billetera móvil Crypto & DeFi en Blockchain.",
                        hardwareWallet: "Billetera de hardware",
                        hardwareWalletDesc: "Obten tu KeyPal, para proteger tus activos.",
                        extensionWallet: "Billetera de Extensión",
                        extensionWalletDesc: "Una mejor billetera en su computadora.",
                        transit: "Transit",
                        transitDesc: "Agregador DEX multicadena y plataforma de mercado para el intercambio de NFT.",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Protocolo de red social en Web3.0.",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "Soporta tanto el staking de auto-custodia como el staking de pequeñas cantidades",
                        buyCrypto: "Comprar criptomonedas",
                        buyCryptoDesc: "Comprar criptomonedas con tus tarjetas de crédito"
                    },
                    assets: {title: "Activos"},
                    collaborations: {title: "Colaboraciones"},
                    community: {title: "Comunidad", developers: "Desarrolladores", recruiting: "TP Man"},
                    helpCenter: {title: "Ayuda"}
                },
                ABOUT: {
                    title: "Acerca de nosotros",
                    desc: "TokenPocket es una billetera descentralizada multi cadenas que proporciona a los usuarios una billetera móvil, una billetera de extensión y una billetera de hardware; admite cadenas públicas, incluidas Bitcoin, Ethereum, BNB Smart Chain, TRON, Polygon, Solana, Aptos, Polkadot, EOS y todas las cadenas compatibles con EVM. Sirviendo a más de 20 millones de usuarios de más de 200 países y regiones. Es una billetera cripto líder en la que los usuarios confían en todo el mundo.",
                    philosophy: {
                        title: "Nuestra Filosofía",
                        desc: "Insistimos en una comunidad de tecnología abierta y damos la bienvenida a todos los desarrolladores para que construyamos juntos un mundo blockchain más conveniente, seguro y próspero.",
                        ambition: "Visión",
                        ambition_desc: "Hacer que la cadena de bloques tenga presencia en todas partes",
                        value: "Valor",
                        value_desc: "Que la data regrese a los usuarios y que ésta pertenezca a los verdaderos propietarios",
                        attitude: "Actitud",
                        attitude_desc: "Colaboración mutua y de mente abierta."
                    },
                    milestones: {
                        title: "Hitos",
                        desc_2018_1: "Fundación de TokenPocket",
                        desc_2018_2: "Inversiones por parte de Huobi, Hofan, Byte Capital",
                        desc_2019_1: "Lanzamiento de la cartera de escritorio compatible con TRON",
                        desc_2019_2: "Las descargas de Google Play superan los más de 1.000.000",
                        desc_2020_1: "Cartera HD compatible",
                        desc_2020_2: "Admite las últimas tendencias BSC y DeFi ",
                        desc_2020_3: "Apoyo al Staking de Eth2.0",
                        desc_2021_1: "Transit Incubado",
                        desc_2021_2: "El número de usuarios superó los 20.000.000",
                        desc_2021_3: "Billetera de hardware KeyPal Incubado",
                        desc_2022_1: "Adquirió dFox y se procedió a cambiar el nombre a TokenPocket Extension",
                        January: "Enero",
                        February: "Febrero",
                        March: "Marzo",
                        April: "Abril",
                        May: "Mayo",
                        June: "Junio",
                        July: "Julio",
                        August: "Agostot",
                        September: "Septiembre",
                        October: "Octubre",
                        November: "Noviembre",
                        December: "Diciembre"
                    },
                    contact_us: {
                        title: "Contáctanos para:",
                        service: "Atención al Cliente",
                        service_desc: "service@tokenpocket.pro",
                        bd: "Colaboraciones Empresariales y Comerciales",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "Desarrolladores",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - Tu billetera digital universal | Cartera TP - Cartera ETH - Cartera BTC - Cartera BSC - Cartera HECO - Cartera OKExChain - Cartera Polkadot - Cartera Kusama - Cartera DeFi - Cartera Layer 2 - Cartera EOS - Cartera TRX - nostr",
                    description: "TokenPocket es una billetera de moneda digital líder en el mundo que admite cadenas de bloques públicas, incluidas BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS y Layer 2.",
                    keywords: "TokenPocket, Token Pocket, billetera TP, billetera Ethereum, Bitcoin, EOS, IOST, COSMOS, heco, bsc, capa 2, DeFi, billetera,cripto, cadena de bloques,web3,NFT,nostr"
                }
            }, hi: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "Batchsender",
                    YES: "हाँ",
                    NO: "नहीं",
                    HAS: "हाँ",
                    HAVENT: "नहीं",
                    BLOCKCHAIN: "ब्लॉकचेन",
                    MULTIPLE_CHOICE: "(बहुविकल्पी)",
                    IS_SUPPORT_TP_CONNECT: "क्या यह टोकनपॉकेट कनेक्शन का समर्थन करता है? (एक्सटेंशन और मोबाइल ऐप)",
                    SUPPORT_BOTH: "दोनों समर्थित हैं",
                    SUPPORT_EXTENSION: "केवल एक्सटेंशन",
                    SUPPORT_MOBILE: "केवल मोबाइल",
                    SUPPORT_NONE: "कोई भी नहीं",
                    blockchainWallet: "ब्लॉकचेन वॉलेट",
                    iostWallet: "IOST वॉलेट",
                    tronWallet: "TRON वॉलेट",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "प्रस्तुत करना",
                    symbol: "टोकन नाम",
                    success: "Success",
                    bl_symbol: "BL Symbol",
                    precision: "टोकन प्रेसिजन",
                    decimal: "टोकन दशमलव",
                    totalSupply: "कुल आपूर्ति",
                    contract: "टोकन अनुबंध",
                    website: "आधिकारिक वेबसाइट",
                    introduction: "टोकन परिचय",
                    example: "उदाहरण",
                    submitTokenInfoAndLogo: "टोकन लोगो और अन्य जानकारी अपडेट करें",
                    toGithubSubmit: "Github पर जाएं",
                    nftType: "NFT प्रोटोकॉल मानक",
                    LAYOUT: {
                        features: "विशेषताएँ",
                        buyCrypto: "क्रिप्टो खरीदें",
                        mobileWallet: "मोबाइल वॉलेट",
                        hardwareWallet: "हार्डवेयर वॉलेट",
                        extensionWallet: "एक्सटेंशन वॉलेट",
                        desktop: "डेस्कटॉप वॉलेट",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "अनुमोदन डिटेक्टर",
                        tokenSecurity: "टोकन सुरक्षा",
                        keyGenerator: "कुंजी जेनरेटर",
                        information: "जानकारी",
                        blockchainGuide: "ब्लॉकचेन गाइड",
                        tronWallet: "ट्रॉन गाइड",
                        iostWallet: "IOST गाइड",
                        tpMan: "TP Man",
                        developers: "डेवलपर्स",
                        github: "Github (TP-Lab)",
                        devCenter: "डेवलपर केंद्र",
                        subToken: "टोकन जमा करें",
                        subDApp: "DApp जमा करें",
                        subNFT: "NFT जमा करें",
                        subChain: "सार्वजनिक श्रृंखला जमा करें",
                        company: "कंपनी",
                        about: "के बारे में",
                        careers: "करियर",
                        pressKit: "प्रेस किट",
                        swagShop: "स्वैग की दुकान",
                        support: "सहायता",
                        helpCenter: "सहायता केंद्र",
                        contactUs: "संपर्क करें",
                        legal: "वैध",
                        privacyPolicy: "गोपनीयता नीति",
                        terms: "उपयोग की शर्तें",
                        toHome: "होम",
                        defiWallet: "DeFi वॉलेट",
                        ETHWallet: "Ethereum वॉलेट",
                        ethWallet: "ETH वॉलेट"
                    }
                },
                HOME: {
                    download: "डाउनलोड",
                    downloadNow: "अब डाउनलोड करो",
                    HEADER: {
                        title: "ब्लॉकचेन का पता लगाने के लिए आपका सुरक्षित क्रिप्टो वॉलेट",
                        desc_1: "खरीदने, स्टोर करने, भेजने, टोकन की अदला-बदली करने और NFTs एकत्र करने में आसान और सुरक्षित। 200+ देशों और क्षेत्रों के 20+ मिलियन उपयोगकर्ताओं द्वारा विश्वसनीय।"
                    },
                    INTRODUCTION: {
                        title: "वैश्विक उपयोगकर्ताओं द्वारा टोकनपॉकेट पर भरोसा किया जाता है",
                        desc_1: "हम दुनिया भर के 200+ देशों और क्षेत्रों में सुरक्षित और आसान क्रिप्टो वॉलेट सेवा प्रदान कर रहे हैं",
                        desc_2: "उपयोगकर्ताओं की सेवा",
                        desc_3: "दैनिक लेनदेन",
                        desc_4: "सहायक देश और क्षेत्र"
                    },
                    SECURITY: {
                        title: "सुरक्षा जैसी होनी चाहिए",
                        desc_1: "टोकनपॉकेट केवल आपके डिवाइस पर कुंजी और पासवर्ड बनाता है और संग्रहीत करता है, केवल आप ही अपने खाते और संपत्ति तक पहुंच सकते हैं।",
                        desc_2: "टोकनपॉकेट आपकी आवश्यकता के अनुसार सुरक्षा बढ़ाने के लिए हार्डवेयर कोल्ड वॉलेट और मल्टी-साइन वॉलेट सुविधा भी विकसित करता है।",
                        desc_3: "BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, Cosmos, Polkadot, EOS, IOST इत्यादि का समर्थन करना।"
                    },
                    EXCHANGE: {
                        title: "आसानी से एक्सचेंज और लेनदेन करें",
                        desc_1: "आप टोकनपॉकेट के भीतर कभी भी, कहीं भी अपने क्रिप्टो का व्यापार कर सकते हैं।",
                        desc_2: "क्रेडिट कार्ड से क्रिप्टो खरीदें। आसानी से स्टोर करें, भेजें, क्रॉस चेन और एक्सचेंज करें।",
                        desc_3: "बदलना",
                        desc_4: "तुरंत और आसानी से",
                        desc_5: "Bridge",
                        desc_6: "विभिन्न चेइनो के बीच",
                        desc_7: "क्रिप्टो खरीदें",
                        desc_8: "5 मिनट में"
                    },
                    DAPPSTORE: {
                        title: "एक DApp स्टोर",
                        desc_1: "आप अपने पसंदीदा विकेन्द्रीकृत एप्लिकेशन ढूंढ सकते हैं, नवीनतम और सबसे लोकप्रिय एप्लिकेशन खोज सकते हैं और बटुए को छोड़े बिना उनका उपयोग कर सकते हैं।",
                        desc_2: "DApps ब्राउज़र एकीकृत, आप हमेशा अपने लिंक के साथ DApps तक पहुंच सकते हैं।",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "समर्थित"
                    },
                    COMMUNITY: {
                        title: "समुदाय",
                        desc_1: "हम एक खुले प्रौद्योगिकी समुदाय पर जोर देते हैं, और हम सभी डेवलपर्स का एक साथ अधिक सुविधाजनक, सुरक्षित और समृद्ध ब्लॉकचेन दुनिया बनाने के लिए स्वागत करते हैं",
                        desc_2: "TP-Lab",
                        desc_3: "समुदाय",
                        desc_4: "Dev Docs"
                    },
                    DOWNLOAD: {
                        title: "टोकनपॉकेट वॉलेट अभी प्राप्त करें!",
                        desc_1: "ब्लॉकचेन का पता लगाने के लिए आपका सुरक्षित और विश्वसनीय क्रिप्टो वॉलेट"
                    },
                    FOLLOW: {
                        title: "हमारे पर का पालन करें",
                        desc1: "TokenPocket कर्मचारी आपको निजी संदेश नहीं भेजेंगे!",
                        desc2: "सावधानी! आप टोकनपॉकेट समुदाय में प्रवेश कर रहे हैं, हो सकता है कि कोई व्यक्ति आपको निजी संदेश भेजने के लिए प्रतिरूपित कर रहा हो! कृपया ध्यान रखें कि निजी संदेश भेजने वाला कोई भी व्यक्ति स्कैमर हो सकता है! हम आपसे पहले कभी संपर्क नहीं करेंगे!",
                        desc3: "समझे, दर्ज करें"
                    },
                    EXTENSIONMODAL: {
                        title: "एक्सटेंशन अब लाइव है!",
                        desc1: "आपका क्रिप्टो और DeFi और GameFi",
                        desc2: "कंप्यूटर पर वॉलेट",
                        btnText: "इसे अब प्रयोग करो",
                        btnTextm: "लिंक कॉपी करे",
                        tips: "लिंक को सफलतापूर्वक कॉपी करें, कृपया खोलने के लिए कंप्यूटर पर जाएं"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "प्लेटफार्म आवश्यक है",
                        title: "DApp नाम की आवश्यक है",
                        address: "DApp अनुबंध की आवश्यकता है",
                        url: "DApp वेबसाइट की आवश्यक है",
                        desc: "Desc की आवश्यक है",
                        icon_url: "DApp लोगो की आवश्यक है",
                        rakeBackAccount: "अनुबंध खाते की आवश्यकता है",
                        email: "Email की जरूरत है",
                        others: "अन्य संपर्क जानकारी की आवश्यकता है",
                        tp_connect: "यह आइटम खाली नहीं हो सकता"
                    },
                    title: "DApp नाम",
                    address: "स्मार्ट अनुबंध",
                    url: "DApp वेबसाइट",
                    desc: "संक्षिप्त वर्णन",
                    icon: "DApp Logo (Must be 200x200 - supports JPG, PNG.)",
                    referral: "रेफरल",
                    hasReferral: "क्या इसमें रेफरल सिस्टम है",
                    referralReward: "रेफरल इनाम का वितरण",
                    reward_1: "स्मार्ट अनुबंध द्वारा स्वचालित रूप से वितरित करें (लाइव)",
                    reward_2: "इसे मैन्युअल रूप से DApp पर दावा करने की आवश्यकता है",
                    hasInviteReward: "क्या रेफरल लिंक को सक्रिय करने के लिए आमंत्रणकर्ता को DApp में लेनदेन करने की आवश्यकता है",
                    inviteAccount: "रेफरल वितरण का स्मार्ट अनुबंध",
                    DAppRequirement: "DApp आवश्यकता",
                    requirement_1: "1. DApp को टोकनपॉकेट मोबाइल और टोकनपॉकेट एक्सटेंशन का समर्थन करने की आवश्यकता है।",
                    requirement_2: "2. प्रदान की गई वेबसाइट सुलभ और स्थिर है।",
                    requirement_3: "3. स्मार्ट कॉन्ट्रैक्ट्स मेननेट पर तैनात हैं, और संवेदनशील हिस्से को ओपन सोर्स होना चाहिए।",
                    requirement_4: "4. संवेदनशील अनुबंधों के लिए तृतीय-पक्ष सुरक्षा एजेंसियों से ऑडिट रिपोर्ट की आवश्यकता होती है।",
                    requirement_5: "5. इंटरैक्शन लॉजिक स्पष्ट है और इसे मोबाइल UI के लिए अनुकूलित किया गया है।",
                    requirement_6: "6. धोखाधड़ी और उल्लंघन के बिना प्रासंगिक कानूनों और विनियमों का पालन करें।",
                    requirement_7: "7. यदि आप प्रासंगिक कानूनों और विनियमों का उल्लंघन करते हैं, तो आप स्वेच्छा से संबंधित कानूनी जिम्मेदारियों को ग्रहण करेंगे।",
                    dappInfo: "DApp जानकारी:",
                    necessary: "आवश्यक",
                    language: "DApp भाषा",
                    languageDesc: "(कृपया अनेक भाषाओं के लिए अलग से सबमिट करें)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "एक वाक्य में परियोजना का संक्षिप्त विवरण, जो DApp उपशीर्षक में दिखाई देगा",
                    auditInfo: "लेखापरीक्षा जानकारी:",
                    hasAudit: "क्या अनुबंध लेखापरीक्षा की गई है",
                    auditUrl: "ऑडिट रिपोर्ट url",
                    auditUrlExample: "उदाहरण के लिए: https://auditlink.com",
                    auditReport: "परीक्षण विवरण",
                    auditUpload: "अपलोड करना",
                    contact: "संपर्क विवरण",
                    contactDesc: "कृपया मेलबॉक्स के अलावा ग्राहक सेवा संपर्क जानकारी छोड़ना सुनिश्चित करें, अन्यथा यह समीक्षा पास नहीं करेगा",
                    emailAddr: "Email",
                    emailExample: "उदाहरण के लिए: service@yourdomain.com",
                    others: "अन्य",
                    othersExample: "उदाहरण के लिए: टेलीग्राम：@123456789",
                    auditOptional: "ऑडिट जानकारी का कम से कम एक आइटम भरें",
                    oversize: " योग्य वर्णों को पार कर गया है",
                    select: "चयन",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "ट्यूटोरियल देखें >>"
                },
                DOWNLOAD: {
                    TITLE: "टोकनपॉकेट डाउनलोड करें",
                    TITLE_Android: "एंड्रॉयड के लिए टोकनपॉकेट",
                    TITLE_IOS: "iOS के लिए टोकनपॉकेट",
                    TITLE_Chrome: "आपके ब्राउज़र के लिए टोकनपॉकेट",
                    TEXT: "टोकनपॉकेट एक बहु-श्रृंखला क्रिप्टो वॉलेट है, जिसका उपयोग करना आसान और सुरक्षित है, जिस पर लाखों लोग भरोसा करते हैं।",
                    TEXT_Chrome: "टोकनपॉकेट एक्सटेंशन एक बहु-श्रृंखला क्रिप्टो वॉलेट है, जो सभी EVM संगत श्रृंखला समर्थित है। उपयोग करने में आसान और सुरक्षित, जिस पर लाखों लोग भरोसा करते हैं।",
                    TEXT_PC: "TokenPocket Desktop सबसे बड़ा मल्टी-ब्लॉकचेन वॉलेट आधारित EOS ETH BOS TRON है, हम उपयोगकर्ताओं को एक शक्तिशाली और सुरक्षित डिजिटल एसेट मैनेजमेंट प्रदान करने का प्रयास करते हैं।",
                    ALERT: "कृपया इस पेज को अपना मोबाइल फोन खोलें या कोबो वॉलेट इंस्टॉल करने के लिए दाईं ओर क्यूआर कोड स्कैन करें।",
                    scanCode: "डाउनलोड करने के लिए स्कैन करें",
                    installTutorial: "ट्यूटोरियल स्थापित करें",
                    desc_1: "आधिकारिक वेबसाइट से ऐप डाउनलोड करें और इसके एसएसएल प्रमाणन की जांच करें",
                    desc_2: "अपने पुनर्प्राप्ति वाक्यांश (स्मरक) और निजी कुंजी को लीक होने से बचाएं, इसे कभी भी दूसरों को साझा न करें",
                    desc_3: "अधिक सुरक्षा युक्तियाँ जानें",
                    verifyText: "नवीनतम एंड्रॉयड संस्करण:",
                    verifyText1: "किसी app's की सुरक्षा कैसे सत्यापित करें",
                    verifyText2: "नवीनतम संस्करण",
                    verifyText3: "नवीनतम Google Play संस्करण:",
                    footerTitle: "एक अच्छा पहला प्रभाव बनाएं",
                    footerDesc_1: "BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST इत्यादि का समर्थन करना।",
                    footerDesc_2: "बहु-परत सुरक्षा सुरक्षा",
                    footerDesc_3: "DeFi, DApp, GameFi and NFT समर्थित",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "आधिकारिक तौर पर टोकनपॉकेट के एकमात्र आईओएस ऐप प्रकाशक के रूप में नियुक्त किया गया है",
                    tp_wallet_version: "TP Wallet संस्करण:",
                    token_pocket_version: "Token Pocket संस्करण:",
                    delisted: "हटाए",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "Email की जरूरत है",
                        address: "पता आवश्यक है",
                        owner_address: "मालिक का पता आवश्यक है",
                        symbol: "प्रतीक आवश्यक है",
                        bl_symbol: "BL प्रतीक आवश्यक है",
                        total_supply: "कुल आपूर्ति की आवश्यकता है",
                        decimal: "दशमलव आवश्यक है",
                        precision: "प्रेसिजन की आवश्यकता है",
                        gas: "गैस की आवश्यकता है",
                        website: "वेबसाइट की आवश्यकता है",
                        companyName: "कंपनी या व्यक्तिगत नाम आवश्यक है",
                        contact: "संपर्क आवश्यक है",
                        name: "परियोजना परिचय की आवश्यकता है",
                        icon_url: "लोगो की आवश्यकता है"
                    },
                    icon: "टोकन लोगो (200 * 200 pixels, supporting jpg, jpeg, png, image फ़ाइल नामकरण प्रारूप का समर्थन: टोकन नाम, लोगो को गोल कोनों की आवश्यकता नहीं है)",
                    handleText: "हम आपके अनुरोध को 2 कार्यदिवसों में संसाधित करेंगे"
                },
                RECRUITING: {
                    title: "TP Man भर्ती योजना",
                    text: "टोकनपॉकेट समुदाय में शामिल हों",
                    text1: "ब्लॉकचेन की दुनिया के लिए प्रतिबद्ध और अपना योगदान दें",
                    text2: "हम एक साथ एक Web3.0 दुनिया का निर्माण करते हैं",
                    joinUs: "हमसे जुड़ें",
                    aboutTitle: "TP Man के बारे में",
                    aboutText: "TP Man टोकनपॉकेट समुदाय का एक महत्वपूर्ण हिस्सा है, और हम ईमानदारी से आपको हमसे जुड़ने के लिए आमंत्रित करते हैं!",
                    aboutText1: "आप एक ब्लॉकचेन उत्साही हैं और उद्योग मूल्य का समर्थन करते हैं।",
                    aboutText2: "जब आप ब्लॉकचेन की दुनिया का पता लगाते हैं तो टोकनपॉकेट वॉलेट द्वारा लाई गई सुविधा का आनंद लें।",
                    missionTitle: "TP Man का मिशन",
                    missionText: "दुनिया भर में अधिक ब्लॉकचेन उपयोगकर्ताओं की सेवा करने के लिए टोकनपॉकेट की मदद करें। हम आशा करते हैं कि आप आवेदन करने के लिए निम्नलिखित में से दो आवश्यकताओं को पूरा करेंगे।",
                    missionText1: "विभिन्न चैनलों के माध्यम से अपने देश में कंपनियों या हॉट प्रोजेक्ट्स के साथ टोकनपॉकेट सहयोग का विस्तार और प्रचार करें",
                    missionText2: "स्थानीय उपयोगकर्ताओं की जरूरतों को पूरा करने वाली मार्केटिंग गतिविधियों की योजना बनाएं",
                    missionText3: "मुख्यधारा के सोशल मीडिया जैसे ट्विटर, यूट्यूब, टेलीग्राम और डिस्कॉर्ड को संचालित करने की क्षमता रखते हैं",
                    missionText4: "अंग्रेजी में धाराप्रवाह, और अनुवाद कार्य पूरा करने में सक्षम हो",
                    missionText5: "टोकनपॉकेट वैश्विक ब्लॉकचेन उपयोगकर्ताओं के लिए अधिक उपयोग और तकनीकी सहायता प्रदान करने की योजना बना रहा है, इसलिए हम आशा करते हैं कि आपको कम से कम एक देश और उनके उपयोगकर्ताओं (भारत, संयुक्त राज्य अमेरिका, तुर्की, रूस, दक्षिण कोरिया) के ब्लॉकचेन बाजारों की एक निश्चित समझ है। वियतनाम, फिलीपींस, आदि)",
                    getTitle: "आपको क्या मिलेगा?",
                    getText: "ब्लॉकचैन उद्योग के विभिन्न क्षेत्रों में सीधे तौर पर शामिल एक कार्य अनुभव, और आपको उद्योग में DApp परियोजनाओं, इन्फ्लुएंसर और मुख्यधारा के मीडिया के साथ संचार के अवसर मिलेंगे, लेकिन सीमित नहीं होंगे।",
                    getText1: "अपने काम से समृद्ध पुरस्कार प्राप्त करें जैसे कि ट्वीट अनुवाद, वीडियो बनाना, सामुदायिक संचालन और व्यावसायिक सहयोग।",
                    getText2: "सबसे अधिक पेशेवर ब्लॉकचेन ज्ञान प्रशिक्षण प्राप्त करें और टीम के साथ मिलकर Web3.0 दुनिया का अन्वेषण करें।",
                    getText3: "टोकनपॉकेट आधिकारिक लाभ, जिसमें टोकनपॉकेट स्वैग और हार्डवेयर वॉलेट शामिल हैं।",
                    processTitle: "भर्ती प्रक्रिया",
                    processText: "CV जमा करें",
                    processText1: "CV जाँच",
                    processText2: "ऑनलाइन साक्षात्कार ",
                    processText3: "साक्षात्कार के परिणाम",
                    processText4: "नाव पर स्वागत है",
                    applyTitle: "कौन आवेदन कर सकता है",
                    applyText: "देश की परवाह किए बिना दुनिया का सामना करें",
                    applyText1: "ब्लॉकचेन की दुनिया के बारे में उत्सुक और उत्सुक रहें",
                    applyText2: "फॉर्म भरें और अपना बायोडाटा संलग्न करें, फिर हम आपसे जल्द से जल्द संपर्क करेंगे",
                    footerTitle: "टोकनपॉकेट के बारे में",
                    footerText: "ऊपर",
                    footerText1_1: "20M",
                    footerText1_2: "वैश्विक उपयोगकर्ता",
                    footerText2_1: "3.5M",
                    footerText2_2: "मासिक सक्रिय उपयोगकर्ता",
                    footerText3_1: "200",
                    footerText3_2: "देश और क्षेत्र",
                    footerText4: "टोकनपॉकेट दुनिया का अग्रणी मल्टी-चेन सेल्फ-कस्टोडियल वॉलेट है",
                    footerText5: "जल्द आ रहा है"
                },
                NAVIGATION: {
                    product: {
                        title: "प्रोडक्ट",
                        selfCustodyWallet: "मोबाइल वॉलेट",
                        selfCustodyWalletDesc: "ब्लॉकचेन पर क्रिप्टो और डेफी मोबाइल वॉलेट।",
                        hardwareWallet: "हार्डवेयर वॉलेट",
                        hardwareWalletDesc: "अपनी संपत्ति की रक्षा के लिए अपना KeyPal प्राप्त करें.",
                        extensionWallet: "एक्सटेंशन वॉलेट",
                        extensionWalletDesc: "आपके कंप्यूटर पर एक बेहतर वॉलेट।",
                        transit: "ट्रांजिट",
                        transitDesc: "मल्टी-चेन DEX एग्रीगेटर और NFT मार्केटप्लेस प्लेटफॉर्म।",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Web3.0 में सोशल नेटवर्क प्रोटोकॉल।",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "स्व-संग्रह स्टेकिंग और छोटी मात्रा स्टेकिंग दोनों का समर्थन करता है",
                        buyCrypto: "क्रिप्टो मुद्रा खरीदें",
                        buyCryptoDesc: "क्रेडिट कार्ड के साथ क्रिप्टोकरेंसी खरीदें"
                    },
                    assets: {title: "संपत्ति"},
                    collaborations: {title: "सहयोग"},
                    community: {title: "समुदाय", developers: "डेवलपर्स", recruiting: "TP Man"},
                    helpCenter: {title: "सेवा"}
                },
                ABOUT: {
                    title: "हमारे बारे में",
                    desc: "टोकनपॉकेट एक बहु-श्रृंखला विकेन्द्रीकृत वॉलेट है, यह उपयोगकर्ताओं को मोबाइल वॉलेट, एक्सटेंशन वॉलेट और हार्डवेयर वॉलेट प्रदान करता है, Bitcoin, Ethereum, BNB Smart Chain, TRON, Polygon, Solana, Aptos, Polkadot, EOS और सभी EVM संगत चेन सहित सार्वजनिक श्रृंखलाओं का समर्थन करता है। . 200 से अधिक देशों और क्षेत्रों के 20 मिलियन से अधिक उपयोगकर्ताओं को सेवा प्रदान करना। यह एक विश्वव्यापी अग्रणी क्रिप्टो वॉलेट है जिस पर वैश्विक उपयोगकर्ताओं द्वारा भरोसा किया जाता है।",
                    philosophy: {
                        title: "हमारा दर्शन",
                        desc: "हम एक खुले प्रौद्योगिकी समुदाय पर जोर देते हैं, और हम सभी डेवलपर्स का एक साथ अधिक सुविधाजनक, सुरक्षित और समृद्ध ब्लॉकचेन दुनिया बनाने के लिए स्वागत करते हैं",
                        ambition: "महत्वाकांक्षा",
                        ambition_desc: "ब्लॉकचेन को हर जगह बनाएं",
                        value: "मूल्य",
                        value_desc: "उपयोगकर्ताओं को डेटा वापस करने दें, मूल्य को वास्तविक स्वामियों का बनाएं",
                        attitude: "मनोभाव",
                        attitude_desc: "खुले विचारों वाला, आपसी सहयोग"
                    },
                    milestones: {
                        title: "उपलब्धि",
                        desc_2018_1: "टोकनपॉकेट की स्थापना",
                        desc_2018_2: "हुओबी, होफन, बाइट कैपिटल द्वारा निवेश किया गया",
                        desc_2019_1: "जारी किया गया डेस्कटॉप वॉलेट, समर्थित TRON",
                        desc_2019_2: "गूगल प्ले डाउनलोड 1,000,000 से अधिक हो गया",
                        desc_2020_1: "HD वॉलेट समर्थित",
                        desc_2020_2: "समर्थित BSC और DeFi प्रवृत्ति",
                        desc_2020_3: "समर्थित Eth2.0 स्टेकिंग",
                        desc_2021_1: "इनक्यूबेटेड ट्रांजिट",
                        desc_2021_2: "उपयोगकर्ता आधार 20,000,000 से अधिक हो गया",
                        desc_2021_3: "इनक्यूबेटेड कीपाल हार्डवेयर वॉलेट",
                        desc_2022_1: "dFox का अधिग्रहण किया और टोकन पॉकेट एक्सटेंशन में पुनः ब्रांडेड किया गया",
                        January: "जनवरी",
                        February: "फ़रवरी",
                        March: "मार्च",
                        April: "अप्रैल",
                        May: "मई",
                        June: "जून",
                        July: "जुलाई",
                        August: "अगस्त",
                        September: "सितंबर",
                        October: "अक्टूबर",
                        November: "नवंबर",
                        December: "दिसंबर"
                    },
                    contact_us: {
                        title: "संपर्क करें",
                        service: "ग्राहक सेवा",
                        service_desc: "service@tokenpocket.pro",
                        bd: "व्यापार सहयोग",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "डेवलपर्स",
                        developers_desc: "Discord link"
                    }
                },
                SEO: {
                    title: "टोकनपॉकेट - आपका सार्वभौमिक डिजिटल वॉलेट | TP वॉलेट - ETH वॉलेट - BTC वॉलेट - BSC वॉलेट - HECO वॉलेट - OKExChain वॉलेट - Polkadot वॉलेट - Kusama वॉलेट - DeFi वॉलेट - Layer 2 वॉलेट - EOS वॉलेट - TRX वॉलेट - nostr",
                    description: "TokenPocket एक विश्व-अग्रणी डिजिटल मुद्रा वॉलेट है, जो BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS और Layer 2 सहित सार्वजनिक ब्लॉकचेन का समर्थन करता है।",
                    keywords: "TokenPocket,Token Pocket,TP wallet,Ethereum wallet,Bitcoin,EOS,IOST,COSMOS,heco,bsc,layer2,DeFi,wallet,crypto,blockchain,web3,NFT,nostr"
                }
            }, ja: {
                COMMON: {
                    EMAIL: "メール",
                    BATCH_SENDER: "バッチセンダー",
                    YES: "Yes",
                    NO: "No",
                    HAS: "Yes",
                    HAVENT: "No",
                    BLOCKCHAIN: "ブロックチェーン",
                    MULTIPLE_CHOICE: "(複数選択)",
                    IS_SUPPORT_TP_CONNECT: "TokenPocketのコネクトに対応していますか？(モバイルアプリと拡張機能)",
                    SUPPORT_BOTH: "両方に対応しています。",
                    SUPPORT_EXTENSION: "拡張機能にのみ対応しています。",
                    SUPPORT_MOBILE: "モバイルにのみ対応しています。",
                    SUPPORT_NONE: "対応していません。",
                    blockchainWallet: "ブロックチェーンウォレット",
                    iostWallet: "IOST Wallet",
                    tronWallet: "TRON Wallet",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "完了",
                    symbol: "トークンネーム",
                    success: "Success",
                    bl_symbol: "シンボル",
                    precision: "精度",
                    decimal: "小数点の桁数",
                    totalSupply: "発行量",
                    contract: "ントラクト",
                    website: "公式サイト",
                    introduction: "説明",
                    example: "サンプル",
                    submitTokenInfoAndLogo: "トークンのロゴとその他の情報をアップデート",
                    toGithubSubmit: "Githubへ移動",
                    nftType: "NFTのプロトコル規格",
                    LAYOUT: {
                        features: "プロダクト",
                        buyCrypto: "暗号資産を購入",
                        mobileWallet: "モバイルウォレット",
                        hardwareWallet: "ハードウェアウォレット",
                        extensionWallet: "拡張ウォレット",
                        desktop: "デスクトップウォレット",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "アプルーバルディテクター",
                        tokenSecurity: "トークンセキュリティ",
                        keyGenerator: "キージェネレーター",
                        information: "詳細",
                        blockchainGuide: "ブロックチェーンガイド",
                        tronWallet: "TRON Guide",
                        iostWallet: "IOST Guide",
                        tpMan: "TPマン",
                        developers: "開発者",
                        github: "Github (TP-Lab)",
                        devCenter: "開発者センター",
                        subToken: "トークンを投稿",
                        subDApp: "DAppを投稿",
                        subNFT: "NFTを投稿",
                        subChain: "チェーン",
                        company: "会社",
                        about: "TokenPocketについて",
                        careers: "キャリア",
                        pressKit: "プレスキット",
                        swagShop: "スワッグショップ",
                        support: "サポート",
                        helpCenter: "ヘルプセンター",
                        contactUs: "お問い合わせ",
                        legal: "法的情報",
                        privacyPolicy: "プライバシーポリシー",
                        terms: "利用規約",
                        toHome: "ホーム",
                        defiWallet: "DeFiウォレット",
                        ETHWallet: "イーサリアムウォレット",
                        ethWallet: "ETHウォレット"
                    }
                },
                HOME: {
                    download: "ダウンロード",
                    downloadNow: "ダウンロードする",
                    HEADER: {
                        title: "安全にブロックチェーンを探索できる暗号資産ウォレット",
                        desc_1: "安全で簡単に、トークンの購入、保管、送受信、スワップ、NFTの収集ができ、200以上の国と地域、2000万人以上のユーザーに信頼されています。"
                    },
                    INTRODUCTION: {
                        title: "TokenPocketは世界中のユーザーから信用されています。",
                        desc_1: "200以上の国や地域で、安全で簡単な暗号資産のウォレットサービスを提供しています。",
                        desc_2: "ユーザー数",
                        desc_3: "1日のトランザクション数",
                        desc_4: "提供している国と地域"
                    },
                    SECURITY: {
                        title: "セキュリティのあるべき姿",
                        desc_1: "TokenPocketは、ユーザーのデバイスのみにキーとパスワードを生成して保存しており、あなただけがあなたの資産をコントロールできます。",
                        desc_2: "また、必要に応じてよりセキュリティを強化できるよう、ハードウェアウォレットのKeyPalや、マルチシグウォレットを開発しています。",
                        desc_3: "BTC、ETH、BSC、TRON、Polygon、Solana、Cosmos、Polkadot、EOS、IOSTなど対応。"
                    },
                    EXCHANGE: {
                        title: "簡単な交換・取引",
                        desc_1: "TokenPocketから、いつでもどこでも暗号資産を取引することができます。",
                        desc_2: "クレジットカードで暗号資産を購入でき、保管、送受信、クロスチェーン、取引を簡単に行うことができます。",
                        desc_3: "スワップ",
                        desc_4: "瞬時に、そして簡単に",
                        desc_5: "ブリッジ",
                        desc_6: "異なるチェーンの間で",
                        desc_7: "暗号資産の購入",
                        desc_8: "5分で"
                    },
                    DAPPSTORE: {
                        title: "DAppストア",
                        desc_1: "ウォレットに搭載されたDAppブラウザーでお気に入りの分散型アプリケーションを見つけ、最新でホットなものを発見し、",
                        desc_2: "ウォレットから離れることなく使用することができ、いつでもDAppsにアクセスすることができます。",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "サポート"
                    },
                    COMMUNITY: {
                        title: "コミュニティ",
                        desc_1: "オープンな開発者コミュニティにこだわり、より便利に安全で豊かなブロックチェーンの世界を一緒に作ってくれる開発者の方々を歓迎します",
                        desc_2: "TP-Lab",
                        desc_3: "開発者コミュニティ",
                        desc_4: "開発者向けドキュメント"
                    },
                    DOWNLOAD: {title: "TokenPocketを手に入れよう！", desc_1: "安全にブロックチェーンを探索できる暗号資産ウォレット"},
                    FOLLOW: {
                        title: "フォローする",
                        desc1: "TokenPocket スタッフからプライベート メッセージは送信されません!",
                        desc2: "注意！ TokenPocket コミュニティに参加しようとしています。誰かが私たちになりすましてプライベート メッセージを送信している可能性があります。 プライベート メッセージを送信する人は詐欺師である可能性があることに注意してください。 最初に連絡することはありません！",
                        desc3: "了解、入力"
                    },
                    EXTENSIONMODAL: {
                        title: "拡張機能のウォレットが利用できます！",
                        desc1: "暗号資産&DeFi&GaneFi",
                        desc2: "コンピューターで",
                        btnText: "利用可能",
                        btnTextm: "リンクをコビーする",
                        tips: "リンクをコピーして、コンピューターから開いてください。"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "プラットフォームが必要です",
                        title: "DAppの名前が必要です",
                        address: "DAppのコントラクトが必要です",
                        url: "DAppのウェブサイトが必要です",
                        desc: "説明が必要です",
                        icon_url: "DAppのロゴが必要です",
                        rakeBackAccount: "コントラクトのアカウントが必要です",
                        email: "Eメールアドレスが必要です",
                        others: "その他の連絡先情報が必要です",
                        tp_connect: "このアイテムは空白にすることができません"
                    },
                    title: "DAppの名前",
                    address: "スマートコントラクト",
                    url: "DAppのウェブサイト",
                    desc: "短い説明",
                    icon: "DAppのロゴ(200x200のJPG,PNG形式)",
                    referral: "リファラル",
                    hasReferral: "リファラルシステムの有無",
                    referralReward: "リファラルリワードの分配について",
                    reward_1: "スマートコントラクトによる自動配信(Live)",
                    reward_2: "DAppに手動でクレームする必要がある",
                    hasInviteReward: "リファラルリンクを有効にするためにはDAppで取引をする必要がありますか？",
                    inviteAccount: "リファラルを配信するコントラクト",
                    DAppRequirement: "DAppの必要条件",
                    requirement_1: "1. TokenPocketのモバイル及び拡張ウォレットをサポートしていること",
                    requirement_2: "2.ウェブサイトがアクセス可能で安定していること.",
                    requirement_3: "3. オープンソースかつ、メインネットでデプロイされていること",
                    requirement_4: "4. 機密性の高いコントラクトの場合、第三者のセキュリティエージェントから監査を受けていること",
                    requirement_5: "5. インタラクションロジックが明確で、モバイルのUIに適していること",
                    requirement_6: "6. 関連する法令を遵守し、不正や侵害を行わないこと",
                    requirement_7: "7. 関連する法令に違反した場合、対応する法的責任を負うこと",
                    dappInfo: "DAppの情報:",
                    necessary: "必須",
                    language: "DAppの言語",
                    languageDesc: "(多言語に対応されている場合は別途ご提出ください)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "DAppのサブタイトルに表示される、プロジェクトの簡単な説明(1文)",
                    auditInfo: "監査に関する情報:",
                    hasAudit: "コントラクトの監査の実施有無",
                    auditUrl: "監査報告書のURL",
                    auditUrlExample: "例: https://auditlink.com",
                    auditReport: "監査報告",
                    auditUpload: "アップロード",
                    contact: "コントラクトの詳細",
                    contactDesc: "メール以外のカスタマーサービスの連絡先を必ず記入してください",
                    emailAddr: "Eメール",
                    emailExample: "例: service@yourdomain.com",
                    others: "その他",
                    othersExample: "例: Telegram：@123456789",
                    auditOptional: "監査情報を1項目以上入力してください",
                    oversize: "サイズを超えています",
                    select: "選択",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "チュートリアルを見る>>"
                },
                DOWNLOAD: {
                    TITLE: "TokenPocketをダウンロード",
                    TITLE_Android: "TokenPocket for Android",
                    TITLE_IOS: "TokenPocket for iOS",
                    TITLE_Chrome: "TokenPocket for browser",
                    TEXT: "TokenPocketは、数百万人に信頼されている安全で簡単に使用できるマルチチェーンの暗号資産ウォレットです。",
                    TEXT_Chrome: "TokenPocketは、数百万人に信頼されている安全で簡単に使用できるマルチチェーンの暗号資産ウォレットです。",
                    TEXT_PC: "TokenPocketのデスクトップウォレットは、EOS,ETH,BOS,TRONをベースとした最大級のマルチブチェーンウォレットで、ユーザーに強力かつ安全な暗号資産資産管理を提供するために努力しています。",
                    scanCode: "スキャンしてダウンロード",
                    installTutorial: "チュートリアルのインストール",
                    desc_1: "SSL認証を確認して、公式サイトからダウンロードしてください",
                    desc_2: "ニーモニックフレーズ/秘密鍵は漏洩しないように管理し、絶対に他人に教えないでください。",
                    desc_3: "セキュリティについてもっと見る",
                    verifyText: "最新のAndroidバージョン:",
                    verifyText1: "アプリのセキュリティを確認する方法",
                    verifyText2: "最新のバージョン:",
                    verifyText3: "最新のGoogle Playバージョン:",
                    footerTitle: "ファーストインプレッションを高める",
                    footerDesc_1: "BTC, ETH, BSC, TRON,Polygon, Aptos, Solana, EOS, Polkadot, IOSTなどをサポート",
                    footerDesc_2: "マルチレイヤーのセキュリティプロテクション",
                    footerDesc_3: "DeFi, DApp, GameFi&NFT をサポート",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "は、TokenPocket の唯一の iOS アプリ発行者として正式に任命されました。",
                    tp_wallet_version: "TP Wallet バージョン:",
                    token_pocket_version: "Token Pocket バージョン:",
                    delisted: "上場廃止",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "メールが必要です",
                        address: "アドレスが必要です",
                        owner_address: "オーナーのアドレスが必要です",
                        symbol: "シンボルが必要です",
                        bl_symbol: "BL シンボルが必要です",
                        total_supply: "総発行量が必要です",
                        decimal: "小数点が必要です",
                        precision: "精度が必要です",
                        gas: "ガスが必要です",
                        website: "ウェブサイトが必要です",
                        companyName: "会社名または個人名が必要です",
                        contact: "連絡先が必要です",
                        name: "プロジェクトの説明が必要です",
                        icon_url: "ロゴが必要です"
                    },
                    icon: "トークンのロゴ(200 * 200ピクセルのJPG,JPEG,PNG形式にのみ対応、画像ファイルの名前はトークン名にしてください。ロゴに角丸は必要ありません。)",
                    handleText: "2営業日以内に処理します。"
                },
                RECRUITING: {
                    title: "TP Man Recruitment Plan",
                    text: "Join the TokenPocket community",
                    text1: "Committed to the blockchain world and contribute your part",
                    text2: "We build a Web3.0 world together",
                    joinUs: "Join Us",
                    aboutTitle: "About TP Man",
                    aboutText: "TP Man is an important part of the TokenPocket community, and we sincerely invite you to join us!",
                    aboutText1: "You are a blockchain enthusiast and endorse the industry value.",
                    aboutText2: "Enjoy the convenience brought by TokenPocket wallet when you explore the blockchain world.",
                    missionTitle: "The Mission of TP Man",
                    missionText: "Help TokenPocket to serve more blockchain users around the world. We hope you, meet two of the following requirements to apply.",
                    missionText1: "Expand and promote TokenPocket cooperation with companies or hot projects in your country through various channels",
                    missionText2: "Plan marketing activities that meet the needs of local users",
                    missionText3: "Have the ability to operate mainstream social medias such as Twitter, Youtube, Telegram, and Discord",
                    missionText4: "Fluent in English, and be able to complete translation work",
                    missionText5: "TokenPocket plans to provide more usage and technical support for global blockchain users, so we hope that you have a certain understanding of the blockchain markets of no less than one country and their users (India, the United States, Turkey, Russia, South Korea, Vietnam, the Philippines, etc.)",
                    getTitle: "What will you get?",
                    getText: "A work experience directly involved with various fields of the blockchain industry, and you will get but not limited to communication opportunities with DApp projects, Influencers, and mainstream media in the industry.",
                    getText1: "Get rich rewards from your work such as tweets translation, making video, community operation and business cooperation.",
                    getText2: "Get the most professional blockchain knowledge training and explore the Web3.0 world with the team together.",
                    getText3: "TokenPocket official benefits, including TokenPocket Swag and hardware wallets.",
                    processTitle: "Recruitment process",
                    processText: "Submit CV",
                    processText1: "CV screening",
                    processText2: "Online interview ",
                    processText3: "Interview results",
                    processText4: "Welcome aboard",
                    applyTitle: "Who can apply",
                    applyText: "Face the world, regardless of country",
                    applyText1: "Be keen and curious about the blockchain world",
                    applyText2: "Fill out the form and attach your resume, then we will contact you as soon as possible",
                    footerTitle: "About TokenPocket",
                    footerText: "over",
                    footerText1_1: "20M",
                    footerText1_2: "global users",
                    footerText2_1: "3.5M",
                    footerText2_2: "monthly active users",
                    footerText3_1: "200",
                    footerText3_2: "countries and regions",
                    footerText4: "TokenPocket is the world's leading multi-chain self-custodial wallet",
                    footerText5: "Coming soon"
                },
                NAVIGATION: {
                    product: {
                        title: "製品",
                        selfCustodyWallet: "モバイルウォレット",
                        selfCustodyWalletDesc: "ブロックチェーンの暗号資産&DeFiモバイルウォレット",
                        hardwareWallet: "ハードウェアウォレット",
                        hardwareWalletDesc: "あなたの資産を守る、KeyPalをゲットしよう。",
                        extensionWallet: "拡張ウォレット",
                        extensionWalletDesc: "デスクトップでより良いウォレットを。",
                        transit: "Transit",
                        transitDesc: "マルチチェーンのDEXアグリゲーター&NFTマーケットプレイス",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Web3.0のソーシャルネットワークプロトコル",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "自己保管のステーキングと少額ステーキングの両方をサポートしています",
                        buyCrypto: "クリプトを購入する",
                        buyCryptoDesc: "クレジットカードで暗号通貨を購入する"
                    },
                    assets: {title: "アセット"},
                    collaborations: {title: "コラボレーション"},
                    community: {title: "コミュニティ", developers: "開発者", recruiting: "TPマン(採用)"},
                    helpCenter: {title: "ヘルプセンター"}
                },
                ABOUT: {
                    title: "TokenPocketについて",
                    desc: "TokenPocketは、BTC、ETH、BNB、TRON、Polygon、Solana、HECO、Klaytn、Avalanche、OKC、HSC、Fantom、Polkadot、Kusama、IOSTなど主流のパブリックチェーンをデフォルトでサポートし、すべてのEVM互換、Polkadot互換、EOS互換のパブリックチェーンに対応する世界有数のマルチチェーンセルフカストディウォレットで、現在までに、全世界200カ国以上、2000万人以上のユーザーに信頼性の高いサービスを提供し、月間アクティブユーザー数は350万人を超えています。三位一体となる、モバイルウォレット(iOS、iPadOS、Android)、Chrome拡張ウォレット、ハードウェアウォレット(KeyPal)を提供しており、あらゆるデバイスからご利用いただけます。",
                    philosophy: {
                        title: "私たちの理念",
                        desc: "私たちはオープンな技術コミュニティにこだわり、より便利で安全で豊かなブロックチェーンの世界を一緒に作ってくれる開発者の方々を歓迎します",
                        ambition: "目的",
                        ambition_desc: "ブロックチェーンをあらゆる場所で実現すること",
                        value: "価値",
                        value_desc: "データをユーザーの手に戻し、価値を真の所有者に帰属させる。",
                        attitude: "姿勢",
                        attitude_desc: "オープンマインドで、互いに協力し合う"
                    },
                    milestones: {
                        title: "マイルストーン",
                        desc_2018_1: "TokenPocketの設立",
                        desc_2018_2: "Huobi、Hofan、Byte Capitalから投資を受ける",
                        desc_2019_1: "デスクトップウォレットをリリース、TRONをサポート",
                        desc_2019_2: "Google Playでのダウンロード数が100万を突破",
                        desc_2020_1: "HDウォレットをサポート",
                        desc_2020_2: "BSCとDeFuをサポート",
                        desc_2020_3: "ETH2.0のステーキングをサポート",
                        desc_2021_1: "TransitFinanceを提供開始",
                        desc_2021_2: "ユーザー数が2000万人を突破",
                        desc_2021_3: "KeyPal ハードウェアウォレットを販売開始",
                        desc_2022_1: "dFoxを買収し、Chrome拡張ウォレットを提供開始",
                        January: "1月",
                        February: "2月",
                        March: "3月",
                        April: "4月",
                        May: "5月",
                        June: "6月",
                        July: "7月",
                        August: "8月",
                        September: "9月",
                        October: "10月",
                        November: "11月",
                        December: "12月"
                    },
                    contact_us: {
                        title: "お問い合わせ",
                        service: "カスタマーサービス",
                        service_desc: "service@tokenpocket.pro",
                        bd: "ビジネスコラボレーション",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "開発者",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - ユニバーサルデザインウォレット｜TPウォレット - ETHウォレット - BTCウォレット - BSCウォレット - HECOウォレット - OKExChainウォレット - Polkadotウォレット - Kusamaウォレット - DeFiウォレット - レイヤー2ウォレット - EOSウォレット - TRXウォレット - nostr",
                    description: "TokenPocketは、BTC、ETH、BSC、HECO、TRON、OKExChain、Polkadot、Kusama、EOS、Layer 2などのパブリックブロックチェーンをサポートする世界トップレベルの暗号資産ウォレットです。",
                    keywords: "TokenPocket,Token Pocket,TP ウォレット,トークンポケット,仮想通貨,暗号資産,ウォレット,イーサリアムウォレット,ビットコイン,EOS,IOST,COSMOS,heco,bsc,レイヤー2,DeFi,ウォレット,web3,NFT,nostr"
                }
            }, fil: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "Batchsender",
                    YES: "Oo",
                    NO: "Hindi",
                    HAS: "Oo",
                    HAVENT: "Hindi",
                    BLOCKCHAIN: "Blockchain",
                    WALLET_GUIDE: "Gabay sa Wallet",
                    MULTIPLE_CHOICE: "(Maraming pagpipilian)",
                    IS_SUPPORT_TP_CONNECT: "Sinusuportahan ba nito ang koneksyon ng TokenPocket? (Extension at Mobile app)",
                    SUPPORT_BOTH: "Parehong sinusuportahan",
                    SUPPORT_EXTENSION: "Tanging Extension",
                    SUPPORT_MOBILE: "Tanging mobile",
                    SUPPORT_NONE: "wala",
                    blockchainWallet: "Blockchain Wallet",
                    iostWallet: "IOST Wallet",
                    tronWallet: "TRON Wallet",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "I-submit",
                    symbol: "Pangalan ng Token",
                    success: "Success",
                    bl_symbol: "Simbolo ng BL",
                    precision: "Precision ng Token",
                    decimal: "Decimal ng Token",
                    totalSupply: "Kabuuang Supply",
                    contract: "Contract ng Token",
                    website: "Opisyal na website",
                    introduction: "Panimula ng Token",
                    example: "Halimbawa",
                    submitTokenInfoAndLogo: "I-update ang logo ng token at iba pang Impormasyon",
                    toGithubSubmit: "Pumunta sa Github",
                    nftType: "Pamantayan ng protocol ng NFT",
                    LAYOUT: {
                        features: "Mga tampok",
                        buyCrypto: "Bumili ng Crypto",
                        mobileWallet: "Mobile na Wallet",
                        hardwareWallet: "Hardware na Wallet",
                        extensionWallet: "Extension na Wallet",
                        desktop: "Desktop na Wallet",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "Detektor ng Pag-apruba",
                        tokenSecurity: "Seguridad ng Token",
                        keyGenerator: "Key Generator",
                        information: "Impormasyon",
                        blockchainGuide: "Gabay sa Blockchain",
                        tronWallet: "Gabay sa TRON",
                        iostWallet: "Gabay sa IOST",
                        tpMan: "TP Man",
                        developers: "Mga developer",
                        github: "Github (TP-Lab)",
                        devCenter: "Dev Center",
                        subToken: "I-submit ang Token",
                        subDApp: "I-submit ang DApp",
                        subNFT: "I-submit ang NFT",
                        subChain: "Isumite ang Chain",
                        company: "kumpanya",
                        about: "Tungkol sa",
                        careers: "Mga Career",
                        pressKit: "Pindutin ang Kit",
                        swagShop: "Swag Shop",
                        support: "Suporta",
                        helpCenter: "Help Center",
                        contactUs: "Makipag-ugnayan sa amin",
                        legal: "Legal",
                        privacyPolicy: "Patakaran sa Privacy",
                        terms: "Mga Tuntunin ng Paggamit",
                        toHome: "Home",
                        defiWallet: "DeFi na Wallet",
                        ETHWallet: "Ethereum Wallet",
                        ethWallet: "ETH na Wallet"
                    }
                },
                HOME: {
                    download: "I-download",
                    downloadNow: "I-download na ngayon",
                    HEADER: {
                        title: "Ang iyong secure na crypto wallet para i-explore ang blockchain",
                        desc_1: "Madali at ligtas na bumili, mag-imbak, magpadala, mag-swap ng mga token at mangolekta ng mga NFT. Pinagkakatiwalaan ng 20+ milyong user mula sa 200+ na bansa at rehiyon."
                    },
                    INTRODUCTION: {
                        title: "Ang TokenPocket ay pinagkakatiwalaan ng mga global users",
                        desc_1: "Nagbibigay kami ng ligtas at madaling serbisyo ng crypto wallet sa 200+ na bansa at rehiyon sa buong mundo",
                        desc_2: "Naglilingkod sa mga user",
                        desc_3: "Pang-araw-araw na Transaksyon",
                        desc_4: "Pagsuporta sa mga bansa at rehiyon"
                    },
                    SECURITY: {
                        title: "Seguridad tulad ng nararapat",
                        desc_1: "Ang TokenPocket ay bumubuo at nag-iimbak ng mga key at password sa iyong device lamang, ikaw lang ang makaka-access sa iyong account at mga asset.",
                        desc_2: "Gumagawa din ang TokenPocket ng hardware cold wallet at feature na multi-sign wallet para mapahusay ang seguridad ayon sa kailangan mo.",
                        desc_3: "Sinusuportahan ang BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, Cosmos, Polkadot, EOS, IOST at iba pa."
                    },
                    EXCHANGE: {
                        title: "Exchange & Madaling Transact",
                        desc_1: "Maaari mong i-trade ang iyong crypto anumang oras, kahit saan sa loob ng TokenPocket.",
                        desc_2: "Bumili ng crypto gamit ang mga credit card. Mag-imbak, magpadala, mag-cross chain at mag-exchange ng madali.",
                        desc_3: "I-swap",
                        desc_4: "Agad at madali",
                        desc_5: "Bridge",
                        desc_6: "Kabilang sa iba't ibang mga chain",
                        desc_7: "Bumili ng Crypto",
                        desc_8: "Sa loob ng 5 minuto"
                    },
                    DAPPSTORE: {
                        title: "Isang DApp Store",
                        desc_1: "Maaari mong mahanap ang iyong mga paboritong desentralisadong application, tuklasin ang pinakabago at pinakamainit at gamitin ang mga ito nang hindi umaalis sa wallet.",
                        desc_2: "Pinagsama ang DApp Browser, maaari mong palaging ma-access ang DApps gamit ang iyong mga link.",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "Sinusuportahan"
                    },
                    COMMUNITY: {
                        title: "Komunidad",
                        desc_1: "Iginigiit namin ang isang bukas na komunidad ng teknolohiya, at tinatanggap namin ang lahat ng mga developer na bumuo ng isang mas maginhawa, secure at mas mayamang mundo ng blockchain nang magkasama.",
                        desc_2: "TP-Lab",
                        desc_3: "Komunidad",
                        desc_4: "Dev Docs"
                    },
                    DOWNLOAD: {
                        title: "Kunin ang TokenPocket Wallet ngayon!",
                        desc_1: "Ang iyong secure at pinagkakatiwalaang crypto wallet para i-explore ang blockchain"
                    },
                    FOLLOW: {
                        title: "Sundan mo kami",
                        desc1: "Ang TokenPocket Staffs ay hindi magpapadala sa iyo ng mga pribadong mensahe!",
                        desc2: "Ingat! Pumapasok ka sa komunidad ng TokenPocket, maaaring may gumagaya sa amin para magpadala sa iyo ng mga pribadong mensahe! Mangyaring magkaroon ng kamalayan na, sinuman na nagpapadala ng mga pribadong mensahe ay maaaring isang scammer! Hindi ka muna namin makokontak!",
                        desc3: "Naiintindihan, pumasok"
                    },
                    EXTENSIONMODAL: {
                        title: "Live na ngayon ang extension!",
                        desc1: "Ang iyong Crypto at DeFi at GameFi",
                        desc2: "wallet sa computer",
                        btnText: "Gamitin Ito Ngayon",
                        btnTextm: "Kopyahin ang Link",
                        tips: "Matagumpay na kopyahin ang link, mangyaring pumunta sa computer para buksan"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "Kinakailangan ang platform",
                        title: "Kinakailangan ang Pangalan ng DApp",
                        address: "Kinakailangan ang Contract ng DApp",
                        url: "Kinakailangan ang Website ng DApp",
                        desc: "Kinakailangan ang desc",
                        icon_url: "Kinakailangan ang Logo ng DApp",
                        rakeBackAccount: "Kinakailangan ang account ng Contract",
                        email: "Kinakailangan ang email",
                        others: "Kinakailangan ang iba pang impormasyon sa pakikipag-ugnayan",
                        tp_connect: "Hindi maaaring blangko ang item na ito"
                    },
                    title: "Pangalan ng DApp",
                    address: "Smart Contract",
                    url: "Website ng DApp",
                    desc: "Maikling Description",
                    icon: "Logo ng DApp (Dapat ay 200x200 - sumusuporta sa JPG, PNG.)",
                    referral: "Referral",
                    hasReferral: "May referral system ba ito",
                    referralReward: "Ang pamamahagi ng reward sa referral",
                    reward_1: "Awtomatikong ipamahagi sa pamamagitan ng smart contract (Live)",
                    reward_2: "Kailangang i-claim ito sa DApp nang Manu-mano",
                    hasInviteReward: "Kailangan bang gumawa ng transaksyon ang nag-imbita sa DApp para ma-activate ang referral link",
                    inviteAccount: "Ang smart contract ng referral distribution",
                    DAppRequirement: "DApp Requirement",
                    requirement_1: "1. Kailangang suportahan ng DApp ang TokenPocket mobile at TokenPocket extension.",
                    requirement_2: "2. Ang ibinigay na website ay naa-access at stable.",
                    requirement_3: "3. Ang mga smart contract ay na-deploy sa mainnet, at ang sensitibong bahagi ay nangangailangan na maging open source.",
                    requirement_4: "4. Ang mga sensitibong contract ay nangangailangan ng mga ulat sa pag-audit mula sa mga ahensya ng seguridad ng third-party.",
                    requirement_5: "5. Ang logic ng pakikipag-ugnayan ay malinaw at inangkop sa mobile UI.",
                    requirement_6: "6. Sundin ang mga nauugnay na batas at regulasyon, nang walang pandaraya at paglabag.",
                    requirement_7: "7. Kung lalabag ka sa mga nauugnay na batas at regulasyon, kusang-loob mong aakohin ang kaukulang mga legal na responsibilidad.",
                    dappInfo: "Impormasyon ng DApp:",
                    necessary: "kailangan",
                    language: "Wika ng DApp",
                    languageDesc: "(Mangyaring i-submit nang hiwalay para sa maraming wika)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "Isang maikling paglalarawan ng proyekto sa isang pangungusap, na lalabas sa subtitle ng DApp",
                    auditInfo: "Impormasyon sa pag-audit:",
                    hasAudit: "Kung ang pag-audit ng contract ay naisagawa",
                    auditUrl: "Url ng ulat ng audit",
                    auditUrlExample: "Halimbawa: https://auditlink.com",
                    auditReport: "Ulat sa Pag-audit",
                    auditUpload: "Mag-upload",
                    contact: "Mga detalye ng contact",
                    contactDesc: "Pakitiyak na iwanan ang impormasyon sa pakikipag-ugnayan sa customer service maliban sa mailbox, kung hindi, hindi ito papasa sa pagsusuri",
                    emailAddr: "Email",
                    emailExample: "Halimbawa: service@yourdomain.com",
                    others: "Iba pa",
                    othersExample: "Halimbawa: Telegram：@123456789",
                    auditOptional: "Punan ang hindi bababa sa isang item ng impormasyon sa pag-audit",
                    oversize: " ay lumampas sa mga kwalipikadong character",
                    select: "Mag-select",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "Tingnan ang tutorial>>"
                },
                DOWNLOAD: {
                    TITLE: "I-download ang TokenPocket",
                    TITLE_Android: "TokenPocket para sa Android",
                    TITLE_IOS: "TokenPocket para sa iOS",
                    TITLE_Chrome: "TokenPocket para sa iyong browser",
                    TEXT: "Ang TokenPocket ay isang multi-chain na crypto wallet, madali at secure na gamitin na pinagkakatiwalaan ng milyun-milyon.",
                    TEXT_Chrome: "Ang TokenPocket Extension ay isang multi-chain na crypto wallet, lahat ng EVM compatible na chain ay sinusuportahan. Madali at secure na gamitin ang pinagkakatiwalaan ng milyun-milyon.",
                    TEXT_PC: "Ang TokenPocket Desktop ay ang pinakamalaking multi-blockchain wallet na nakabatay sa EOS ETH BOS TRON, nagsusumikap kaming magbigay ng malakas at secure na pamamahala ng digital asset sa mga user.",
                    scanCode: "Scan to Download",
                    installTutorial: "I-install ang Tutorial",
                    desc_1: "I-download ang app mula sa opisyal na website at suriin ang SSL certification nito",
                    desc_2: "Protektahan ang iyong Recovery Phrase (mnemonic) at Private Key mula sa pag-leaking, huwag na huwag itong ibahagi sa iba",
                    desc_3: "Matuto pa ng mga tip sa seguridad",
                    verifyText: "Pinakabagong Bersyon ng Android:",
                    verifyText1: "Paano i-verify ang seguridad ng isang app",
                    verifyText2: "Pinakabagong bersyon",
                    verifyText3: "Pinakabagong Bersyon ng Google Play:",
                    footerDesc_1: "Sinusuportahan ang BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST at iba pa.",
                    footerDesc_2: "Multi-layer na mga proteksyon sa seguridad",
                    footerDesc_3: "Sinusuportahan ang DeFi, DApp, GameFi at NFT",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "ay opisyal na itinalaga bilang nag-iisang iOS App publisher ng TokenPocket",
                    tp_wallet_version: "TP Wallet Bersyon:",
                    token_pocket_version: "Token Pocket Bersyon:",
                    delisted: "Na-delist",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "Kinakailangan ang email",
                        address: "Kinakailangan ang address",
                        owner_address: "Kinakailangan ang address ng may-ari",
                        symbol: "Kinakailangan ang simbolo",
                        bl_symbol: "Kinakailangan ang Simbolo ng BL",
                        total_supply: "Kinakailangan ang kabuuang supply",
                        decimal: "Kinakailangan ang decimal",
                        precision: "Kinakailangan ang Precision",
                        gas: "Kinakailangan ang GAS",
                        website: "Kailangan ang website",
                        companyName: "Kinakailangan ang pangalan ng kumpanya o personal",
                        contact: "Kinakailangan ang Contact",
                        name: "Kinakailangan ang Introduction ng proyekto",
                        icon_url: "Kinakailangan ang logo"
                    },
                    icon: "Logo ng Token (200 * 200 pixels, sumusuporta sa jpg, jpeg, png, format ng pagpapangalan ng file ng imahe: pangalan ng token, hindi kailangan ng mga bilog na sulok ang logo)",
                    handleText: "Ipoproseso namin ang iyong kahilingan sa loob ng 2 working days"
                },
                RECRUITING: {
                    title: "TP Man Recruitment Plan",
                    text: "Sumali sa komunidad ng TokenPocket",
                    text1: "Nakatuon sa mundo ng blockchain at mag-ambag ng iyong bahagi",
                    text2: "Bumuo kami ng isang Web3.0 na mundo nang magkasama",
                    joinUs: "Sumali sa amin",
                    aboutTitle: "Tungkol sa TP Man",
                    aboutText: "Ang TP Man ay isang mahalagang bahagi ng komunidad ng TokenPocket, at taos-puso kaming nag-aanyaya sa iyo na sumali sa amin!",
                    aboutText1: "Ikaw ay isang mahilig sa blockchain at ini-endorso ang halaga ng industriya.",
                    aboutText2: "Tangkilikin ang kaginhawaan na hatid ng TokenPocket wallet kapag i-explore mo ang mundo ng blockchain.",
                    missionTitle: "Ang Misyon ng TP Man",
                    missionText: "Tulungan ang TokenPocket na maghatid ng higit pang mga gumagamit ng blockchain sa buong mundo. Umaasa kami na matugunan mo ang dalawa sa mga sumusunod na kinakailangan para mag-apply.",
                    missionText1: "Palawakin at isulong ang pakikipagtulungan ng TokenPocket sa mga kumpanya o maiinit na proyekto sa iyong bansa sa pamamagitan ng iba't ibang channel",
                    missionText2: "Magplano ng mga aktibidad sa marketing na nakakatugon sa mga pangangailangan ng mga lokal na user",
                    missionText3: "Magkaroon ng kakayahang magpatakbo ng mga pangunahing social media tulad ng Twitter, Youtube, Telegram, at Discord",
                    missionText4: "Fluent sa Ingles, at makatapos ng gawaing pagsasalin",
                    missionText5: "Plano ng TokenPocket na magbigay ng higit pang paggamit at teknikal na suporta para sa mga global na gumagamit ng blockchain, kaya umaasa kami na mayroon kang tiyak na pag-unawa sa mga merkado ng blockchain ng hindi bababa sa isang bansa at ang kanilang mga user (India, United States, Turkey, Russia, South Korea, Vietnam, Pilipinas, atbp.)",
                    getTitle: "Ano ang makukuha mo?",
                    getText: "Isang karanasan sa trabaho na direktang kasangkot sa iba't ibang larangan ng industriya ng blockchain, at makakakuha ka ngunit hindi limitado sa mga pagkakataon sa komunikasyon sa mga proyekto ng DApp, Influencer, at mainstream na media sa industriya.",
                    getText1: "Makakuha ng masaganang gantimpala mula sa iyong trabaho gaya ng pagsasalin ng mga tweet, paggawa ng video, pagpapatakbo ng komunidad at pakikipagtulungan sa negosyo.",
                    getText2: "Kunin ang pinakapropesyonal na pagsasanay sa kaalaman sa blockchain at galugarin ang mundo ng Web3.0 kasama ang koponan nang magkasama.",
                    getText3: "Mga opisyal na benepisyo ng TokenPocket, kabilang ang TokenPocket Swag at mga wallet ng hardware.",
                    processTitle: "Proseso ng pangangalap",
                    processText: "I-submit ang CV",
                    processText1: "Pagsusuri ng CV",
                    processText2: "Online na panayam ",
                    processText3: "Mga resulta ng panayam",
                    processText4: "Welcome sa aboard",
                    applyTitle: "Sino ang maaaring mag-apply",
                    applyText: "Harapin ang mundo, anuman ang bansa",
                    applyText1: "Maging masigasig at mausisa tungkol sa mundo ng blockchain",
                    applyText2: "Punan ang form at ilakip ang iyong resume, pagkatapos ay makikipag-ugnayan kami sa iyo sa lalong madaling panahon",
                    footerTitle: "Tungkol sa TokenPocket",
                    footerText: "sa buo",
                    footerText1_1: "20M",
                    footerText1_2: "pandaigdigang mga user",
                    footerText2_1: "3.5M",
                    footerText2_2: "buwanang aktibong user",
                    footerText3_1: "200",
                    footerText3_2: "mga bansa at rehiyon",
                    footerText4: "Ang TokenPocket ay ang nangungunang multi-chain na self-custodial wallet sa buong mundo",
                    footerText5: "Malapit na"
                },
                NAVIGATION: {
                    product: {
                        title: "Produkto",
                        selfCustodyWallet: "Mobile na Wallet",
                        selfCustodyWalletDesc: "Crypto&DeFi Mobile Wallet sa Blockchain.",
                        hardwareWallet: "Hardware na Wallet",
                        hardwareWalletDesc: "Kunin ang Iyong KeyPal, para Bantayan ang Iyong Mga Asset.",
                        extensionWallet: "Extension na Wallet",
                        extensionWalletDesc: "Isang Mas Mahusay na Wallet sa Iyong Computer.",
                        transit: "Transit",
                        transitDesc: "Multi-chain DEX Aggregator at NFT Marketplace Platform.",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Social Network Protocol sa Web3.0.",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "Sinusuportahan ang self-custodial staking at small amount staking",
                        buyCrypto: "Bumili ng kriptocurrency",
                        buyCryptoDesc: "Bumili ng kriptocurrency gamit ang iyong mga credit card"
                    },
                    assets: {title: "Mga asset"},
                    collaborations: {title: "pakikipag-kolaborasyon"},
                    community: {title: "Komunidad", developers: "mga developer", recruiting: "TP Man"},
                    helpCenter: {title: "Tulong"}
                },
                ABOUT: {
                    title: "Tungkol sa Amin",
                    desc: "Ang TokenPocket ay isang multi-chain na desentralisadong wallet, nagbibigay ito sa mga user ng mobile wallet, extension wallet at hardware wallet, na sumusuporta sa mga public chain kabilang ang Bitcoin, Ethereum, BNB Smart Chain, TRON, Polygon, Solana, Aptos, Polkadot, EOS at lahat ng EVM compatible chain. . Naglilingkod sa mahigit 20 milyong user mula sa mahigit 200 bansa at rehiyon. Ito ay isang nangungunang crypto wallet sa buong mundo na pinagkakatiwalaan ng mga global user.",
                    philosophy: {
                        title: "Ang aming Pilosopiya",
                        desc: "Iginigiit namin ang isang bukas na komunidad ng teknolohiya, at tinatanggap namin ang lahat ng mga developer na bumuo ng isang mas maginhawa, secure at mas mayamang mundo ng blockchain nang magkasama.",
                        ambition: "Ambisyon",
                        ambition_desc: "Gawin ang blockchain na mangyari sa lahat ng dako",
                        value: "kahalagahan",
                        value_desc: "Hayaang bumalik ang data sa mga user, gawing halaga ang pagmamay-ari ng mga tunay na may-ari",
                        attitude: "Saloobin",
                        attitude_desc: "Bukas ang isipan, pagtutulungan sa isa't isa"
                    },
                    milestones: {
                        title: "Milestones",
                        desc_2018_1: "Itinatag ang TokenPocket",
                        desc_2018_2: "Namuhunan ng Huobi, Hofan, Byte Capital",
                        desc_2019_1: "Inilabas ang desktop wallet, suportado ang TRON",
                        desc_2019_2: "Ang pag-download ng Google Play ay lumampas sa 1,000,000",
                        desc_2020_1: "Sinusuportahan ang HD wallet",
                        desc_2020_2: "Sinusuportahan ang BSC at DeFi tendency",
                        desc_2020_3: "Sinusuportahan ang Eth2.0 Staking",
                        desc_2021_1: "Incubated Transit",
                        desc_2021_2: "User base exceeded 20,000,000",
                        desc_2021_3: "Incubated KeyPal hardware wallet",
                        desc_2022_1: "Nakuha ang dFox at na-rebranded sa TokenPocket Extension",
                        January: "Enero",
                        February: "Pebrero",
                        March: "Marso",
                        April: "Abril",
                        May: "Mayo",
                        June: "Hunyo",
                        July: "Hulyo",
                        August: "Agosto",
                        September: "Setyembre",
                        October: "Oktubre",
                        November: "Nobyembre",
                        December: "Disyembre"
                    },
                    contact_us: {
                        title: "Makipag-ugnayan sa amin",
                        service: "Serbisyo sa Customer",
                        service_desc: "service@tokenpocket.pro",
                        bd: "Pakikipagtulungan sa Negosyo",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "Mga Developer",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - Ang iyong universal digital wallet | TP wallet - ETH wallet - BTC wallet - BSC wallet - HECO wallet - OKExChain wallet - Polkadot wallet - Kusama wallet - DeFi wallet - Layer 2 wallet - EOS wallet - TRX wallet - nostr",
                    description: "Ang TokenPocket ay isang world-leading digital currency wallet, na sumusuporta sa mga public blockchain kabilang ang BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS at Layer 2.",
                    keywords: "TokenPocket,Token Pocket,TP wallet,Ethereum wallet,Bitcoin,EOS,IOST,COSMOS,heco,bsc,layer2,DeFi,wallet,crypto,blockchain,web3,NFT,nostr"
                }
            }, pt: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "Batchsender",
                    YES: "Sim",
                    NO: "Não",
                    HAS: "Sim",
                    HAVENT: "Não",
                    BLOCKCHAIN: "Blockchain",
                    MULTIPLE_CHOICE: "(Escolha múltipla)",
                    IS_SUPPORT_TP_CONNECT: "Suporta conexão com TokenPocket (app móvel e extensão)?",
                    SUPPORT_BOTH: "Ambas são suportadas",
                    SUPPORT_EXTENSION: "Apenas extensão",
                    SUPPORT_MOBILE: "Apenas móvel",
                    SUPPORT_NONE: "Nenhuma",
                    blockchainWallet: "Carteira Blockchain",
                    iostWallet: "Carteira IOST",
                    tronWallet: "Carteira TRON",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "Submeter",
                    symbol: "Nome do Token",
                    success: "Success",
                    bl_symbol: "Símbolo BL",
                    precision: "Precisão do Token",
                    decimal: "Decimais do Token",
                    totalSupply: "Fornecimento total",
                    contract: "Contrato do token",
                    website: "Site Oficial",
                    introduction: "Introdução do Token",
                    example: "Exemplo",
                    submitTokenInfoAndLogo: "Actualizar Logo do Token e outras informações",
                    toGithubSubmit: "Ir para Github",
                    nftType: "Protocolo estandardizado NFT",
                    LAYOUT: {
                        features: "características",
                        buyCrypto: "Comprar cripto",
                        mobileWallet: "Carteira móve",
                        hardwareWallet: "Carteira de Hardware",
                        extensionWallet: "Extensão da Carteira",
                        desktop: "Carteira Desktop",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "Detector de Aprovação",
                        tokenSecurity: "Segurança do Token",
                        keyGenerator: "Gerador de Chaves",
                        information: "Informação",
                        blockchainGuide: "Guia da Blockchain",
                        tronWallet: "Guia TRON",
                        iostWallet: "Guia IOST",
                        tpMan: "Homem TP",
                        developers: "Programadores",
                        github: "Github (TP-Lab)",
                        devCenter: "Centro de Programadores",
                        subToken: "Submeter Token",
                        subDApp: "Submeter DApp",
                        subNFT: "Submeter NFT",
                        subChain: "Submeter Chain",
                        company: "Companhia",
                        about: "Acerca (de)",
                        careers: "Carreiras",
                        pressKit: "Kit de Imprensa",
                        swagShop: "Loja Swag",
                        support: "Suporte",
                        helpCenter: "Centro de Ajuda",
                        contactUs: "Contacta-nos",
                        legal: "Legal",
                        privacyPolicy: "Política de Privacidade",
                        terms: "Termos de Utilização",
                        toHome: "Página principal",
                        defiWallet: "Carteira DeF",
                        ETHWallet: "Carteira Ethereum",
                        ethWallet: "Carteira ETH"
                    }
                },
                HOME: {
                    download: "Descarga",
                    downloadNow: "Descarrega agora",
                    HEADER: {
                        title: "A tua carteira cripto segura para explorar a blockchain",
                        desc_1: "Fácil e segura para comprar, armazenar, enviar, trocar tokens e colecionar NFTs. Com a confiança de mais de 20 milhões de utilizadores de mais de 200 países e regiões"
                    },
                    INTRODUCTION: {
                        title: "Utilizadores à escala global confiam na Tokenpocket",
                        desc_1: "Providenciamos uma carteira segura e fácil de utilizar em mais de 200 países e regiões por todo o mundo",
                        desc_2: "Servindo os utilizadores",
                        desc_3: "Transações diárias",
                        desc_4: "Suporta países e reguões"
                    },
                    SECURITY: {
                        title: "Segurança como ela deve ser",
                        desc_1: "A TokenPocket gera e armazena chaves e passwords no teu dispositivo apenas, só tu podes aceder à tua conta e aos teus fundos.",
                        desc_2: "A TokenPocket também desenvolve carteiras frias e carteiras multi-sig a fim de melhorar a segurança de acordo com as tuas necessidades.",
                        desc_3: "Suportando BTC, ETH, BSC, TRON, Aptos, Polygon, Solana, Cosmos, Polkadot, EOS, IOST and so on."
                    },
                    EXCHANGE: {
                        title: "Troca e transaciona facilmente",
                        desc_1: "Podes negociar as tuas criptos a qualquer momento, em qualquer lado com a TokenPocket.",
                        desc_2: "Compra criptos com cartão de crédito. Armazena, envia, troca de cadeira e negoceia com facilidade.",
                        desc_3: "Swap",
                        desc_4: "Instantânea e fácil",
                        desc_5: "Bridge",
                        desc_6: "Entre diferentes cadeias",
                        desc_7: "Compra cripto",
                        desc_8: "Em 5 minutos"
                    },
                    DAPPSTORE: {
                        title: "Uma loja de DApps",
                        desc_1: "Podes encontrar as tuas aplicações descentralizadas favoritas, descobrir as mais recentes e populares sem sair da carteira.",
                        desc_2: "Explorador de DAapps integrado, podes sempre aceder às DApps com os teus links.",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "Suportado"
                    },
                    COMMUNITY: {
                        title: "Comunidade",
                        desc_1: "Insistimos numa tecnologia aberta à comunidade e convidamos todos os programadores a desenvolver de uma forma mais conveniente e segura uma blockchain mais rica",
                        desc_2: "TP-Lab",
                        desc_3: "Comunidade",
                        desc_4: "Dev Docs"
                    },
                    DOWNLOAD: {
                        title: "Obtém uma carteira TokenPocket agora!",
                        desc_1: "A tua carteira segura e confiável para explorar a blockchain"
                    },
                    FOLLOW: {
                        title: "Siga-nos",
                        desc1: "TokenPocket Os funcionários não enviarão mensagens privadas!",
                        desc2: "uidado! Você está entrando na comunidade TokenPocket, pode haver alguém se passando por nós para lhe enviar mensagens privadas! Esteja ciente de que qualquer pessoa que envie mensagens privadas pode ser um golpista! Nós nunca entraremos em contato com você primeiro!",
                        desc3: "Entendido, digite"
                    },
                    EXTENSIONMODAL: {
                        title: "Extension is now live!",
                        desc1: "Your Crypto & DeFi & GameFi",
                        desc2: "wallet on computer",
                        btnText: "Use It Now",
                        btnTextm: "Copy Link",
                        tips: "Copy the link successfully, please go to the computer to open"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "Plataforma é necessária",
                        title: "Nome da DApp é necessário",
                        address: "Contrato da DApp é necessário",
                        url: "Website é necessário",
                        desc: "Descrição é necessária",
                        icon_url: "Logo da DApp é necessário",
                        rakeBackAccount: "Conta do contrato é necessária",
                        email: "Email é necessário",
                        others: "Outras informações de contacto são necessárias”",
                        tp_connect: "Este campo não pode ser deixado em branco"
                    },
                    title: "Nome da DApp”",
                    address: "Smart Contract",
                    url: "ebsite da DApp",
                    desc: "Curta descrição”",
                    icon: "Logo da DApp (tem que ser 200x2000 - suporta JPG,PNG)",
                    referral: "Referenciação",
                    hasReferral: "em sistema de referenciação?",
                    referralReward: "Distribuição das recompensas de referenciação",
                    reward_1: "Distribui automaticamente pelo smart contract",
                    reward_2: "Necessária a colheita manual na DApp",
                    hasInviteReward: "O referenciador tem que efectuar uma transação na DApp para activar link de referenciação?",
                    inviteAccount: "O referenciador tem que efectuar uma transação na DApp para activar link de referenciação",
                    DAppRequirement: "Requerimentos da DApp",
                    requirement_1: "1. A DApp precisa de suportar TokenPocket móvel e extensão TokenPocket.",
                    requirement_2: "2. A DApp precisa de suportar TokenPocket móvel e extensão TokenPocket.",
                    requirement_3: "3. Os smart contracts estão implantados na mainnet e a parte sensitiva tem que ser open source.",
                    requirement_4: "4. Os contratos sensitivos requerem auditoria por parte de agentes de segurança terciários.",
                    requirement_5: "5. A lógica de integração é clara e foi adapatda ao UI móvel.",
                    requirement_6: "6. Obedece a leis e regulações relevantes, sem infringir a lei e sem fraude.",
                    requirement_7: "7. Se violares leis e regulações relevantes, assumirá voluntariamente as respectivas responsabilidades legais.",
                    dappInfo: "Informação da DApp:",
                    necessary: "requerido",
                    language: "Idioma da DApp",
                    languageDesc: "(Por favor submeter vários idiomas separadamente)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "Uma breve descrição do projecto numa só frase, que irá aparecer como subtítulo",
                    auditInfo: "Informação sobre Auditoria:",
                    hasAudit: "Se o contracto foi auditado",
                    auditUrl: "URL do relatório de auditoria",
                    auditUrlExample: "For example: https://auditlink.com",
                    auditReport: "Relatório de Auditoria",
                    auditUpload: "Carregar",
                    contact: "Detalhes de contacto",
                    contactDesc: "Por favor assegura-te que forneces informação de contacto relativa ao serviço de apoio ao cliente para além do endereço de email, caso contrário não será aprovada",
                    emailAddr: "Email",
                    emailExample: "por exemplo: service@yourdomain.com",
                    others: "Outros",
                    othersExample: "por exemplo: Telegram：@123456789",
                    auditOptional: "Preenche pelo menos um dos items acerca da auditoria",
                    oversize: "excedeu o número de caracteres",
                    select: "selecionar",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "Ver tutorial>>"
                },
                DOWNLOAD: {
                    TITLE: "Descarregar TokenPocket",
                    TITLE_Android: "TokenPocket para Android",
                    TITLE_IOS: "TokenPocket para iOS",
                    TITLE_Chrome: "TokenPocket para explorador",
                    TEXT: "A TokenPocket é uma carteira cripto multi-cadeia, fácil e segura de utilizar, confiada por milhões.",
                    TEXT_Chrome: "A extensão TokenPocket é uma carteira cripto multi-cadeia que suporta todas as cadeiras EVM. Fácil e segura, confiada por milhões.",
                    TEXT_PC: "A TokenPocket Desktop é a maior carteira multi-cadeira EOS ETH BOS TRON, providenciamos uma gestão segura e poderosa dos teus activos.",
                    scanCode: "Scan to Download",
                    installTutorial: "Install Tutorial",
                    desc_1: "Descarrega a app do website oficial e verifica a certificação SSL",
                    desc_2: "Protege a tua frase de recuperação (mnemónica) e a tua chave privada, nunca partilhes com terceiros",
                    desc_3: "Aprende mais dicas de segurança",
                    verifyText: "última versão APK:",
                    verifyText1: "Como verificar a segurança de uma app",
                    verifyText2: "última versão:",
                    verifyText3: "última versão no Google Play:",
                    footerDesc_1: "Suporta BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST and so on.",
                    footerDesc_2: "Várias camadas de protecção",
                    footerDesc_3: "DeFi, DApp, GameFi and NFT supported",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "foi oficialmente nomeada como a única editora de aplicativos iOS do TokenPocket",
                    tp_wallet_version: "TP Wallet Versão:",
                    token_pocket_version: "Token Pocket Versão:",
                    delisted: "Removido",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "Email é necessário",
                        address: "Endereço é necessário",
                        owner_address: "Endereço do proprietário é necessário",
                        symbol: "Símbolo é necessário",
                        bl_symbol: "Símbolo BL é necessário",
                        total_supply: "Fornecimento total é necessário",
                        decimal: "Decimais são necessários",
                        precision: "Precisão é necessária",
                        gas: "Gas é necessário",
                        website: "Website é necessário",
                        companyName: "Companhia ou nome pessoal é necessário",
                        contact: "Contacto é necessário",
                        name: "Introdução ao projecto é necessária",
                        icon_url: "Logo é necessário"
                    },
                    icon: "Logo do token (200*200 pixels, suportando jpg, jpeg, png, formato do nome do ficheiro de imagem: nome do token, logo não necessita de cantos arredondados",
                    handleText: "Processaremos o teu pedido em 2 dias úteis"
                },
                RECRUITING: {
                    title: "Plano de Recrutamento Homem TP",
                    text: "Junta-te à comunidade TokenPocket",
                    text1: "Comprometidos com a blockchain, contribui também",
                    text2: "Juntos construímos um mundo Web3.0",
                    joinUs: "Junta-te a nós",
                    aboutTitle: "Acerca do Homem TP",
                    aboutText: "O Homem TP é uma parte importante da comunidade TokenPocket, convidamos-te a juntares-te a nós!",
                    aboutText1: "És um entusiasta da blockchain e apoias o valor da industria",
                    aboutText2: "Disfruta da conveniência trazida pela carteira TokenPocket na exploração da blockchain",
                    missionTitle: "A missão do Homem TP",
                    missionText: "Ajuda a TokenPocket a servir mais utilizadores por todo o mundo. Esperamos que preenchas aos dois seguintes requisitos",
                    missionText1: "Expandir e promover a cooperação da Tokenpocket com outras companhias ou projectos no teu país através de vários canais",
                    missionText2: "Planear actividades de marketing dirigidas aos utilizadores locais",
                    missionText3: "Ter a habilidade para operar redes sociais tais como Twitter, Youtube, Telegram ou Discord",
                    missionText4: "Fluência em inglês e ser capaz de realizar traduções",
                    missionText5: "A TokenPocket planeia expandir a sua utilização bem como suporte técnico por isso esperamos que tenhas algum entendimento sobre a blockchain e os seus mercados em pelo menos um país (Índia, Estados Unidos, Turquia, Russia, Coreia do Sul, Vietname, Filipinas, etc",
                    getTitle: "O que irei receber?",
                    getText: "Uma experiência de trabalho em várias áreas da industria da blockchain e irás ter oportunidade de comunicar com outros projectos, influenciadores e meios de comunicação mainstream",
                    getText1: "Ganha recompensas pelos teus trabalhos, sejam eles traduções de tweets, vídeos, trabalho junto da comunidade ou desenvolvimento de negócios",
                    getText2: "Acede a conhecimentos profissionais e vamos explorar a Web3.0 juntos, em equipa",
                    getText3: "Benefícios oficiais da TokenPocket, incluindo TokenPocket Swag e carteiras frias",
                    processTitle: "Processo de recrutamento",
                    processText: "Submete o teu CV",
                    processText1: "Análise de CV",
                    processText2: "Entrevista Online",
                    processText3: "Resultados da entrevista",
                    processText4: "Sê bem-vindo",
                    applyTitle: "Quem pode candidatar-se",
                    applyText: "Aborda o mundo, independentemente do país",
                    applyText1: "Aplica-te e sê curioso acerca da blockchain",
                    applyText2: "Fill out the form and attach your resume, then we will contact you as soon as possible",
                    footerTitle: "Preenche o formulário e anexa o teu CV, iremos contactar-te o mais breve possível",
                    footerText: "mais",
                    footerText1_1: "20M",
                    footerText1_2: "Utilizadores globais",
                    footerText2_1: "3.5M",
                    footerText2_2: "utilizadores activos mensais",
                    footerText3_1: "200",
                    footerText3_2: "países e regiões",
                    footerText4: "A TokenPocket é a carteira líder a nível mundial",
                    footerText5: "Em breve"
                },
                NAVIGATION: {
                    product: {
                        title: "Produto",
                        selfCustodyWallet: "Carteira móvel",
                        selfCustodyWalletDesc: "Carteira móvel cripto e Defi na Blockchain.",
                        hardwareWallet: "Carteira Hardware",
                        hardwareWalletDesc: "Obtém a tua KeyPal, para guardar os teus activos.",
                        extensionWallet: "Extensão de carteira",
                        extensionWalletDesc: "Uma carteira melhor no teu computador.",
                        transit: "Transit",
                        transitDesc: "Agregador de DEX Multi-cadeira e mercado de NFT.",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Protocolo de Rede Social em Web3.0.",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "Suporta tanto o staking de auto-custódia como o staking de pequenas quantidades",
                        buyCrypto: "Comprar criptomoedas",
                        buyCryptoDesc: "Comprar criptomoedas com seus cartões de crédito"
                    },
                    assets: {title: "Activos"},
                    collaborations: {title: "Colaborações"},
                    community: {title: "Comunidade", developers: "Programadores", recruiting: "Homem TP"},
                    helpCenter: {title: "Ajuda"}
                },
                ABOUT: {
                    title: "Acerca de Nós",
                    desc: "A TokenPocket é uma carteira descentralizada multi-cadeia disponível em carteira móvel, extensão do explorador e carteira fria, suportando cadeias públicas tais como Bitcoin, Ethereum, BNB Smart Chain, TRON, Polygon, Solana, Aptos, Polkadot, EOS e todas as cadeias compatíveis com EVM. É uma carteira lider a nível mundial, com a confiança de mais de 20 milhões de utilizadores em mais de 200 países e regiões em todo o mundo",
                    philosophy: {
                        title: "A nossa filosofia",
                        desc: "Acreditamos uma comunidade tecnológica aberta, pelo que convidamos todos os programadores de desenvolver uma blockchain mais rica conosco, de forma segura e conveniente",
                        ambition: " Ambição",
                        ambition_desc: "Fazer a blockchain acontecer em todo o lado",
                        value: "Valor",
                        value_desc: "Deixar os dados voltar aos utilizadores, fazer com que o valor pertença aos seus verdadeiros donos",
                        attitude: "Atitude",
                        attitude_desc: "Colaboração mútua de mente aberta"
                    },
                    milestones: {
                        title: "Marcos alcançados",
                        desc_2018_1: "Fundação da TokenPocket",
                        desc_2018_2: "Investimento da Huobi, Hofan, Byte Capital",
                        desc_2019_1: "Lançamento da carteira desktop, suportando TRON",
                        desc_2019_2: "Mais de 1M de downloads na Google Play",
                        desc_2020_1: "Suporte para carteira fria",
                        desc_2020_2: "Suporte da BSC e plataformas DeFi",
                        desc_2020_3: "Suporte de staking ETH2.0",
                        desc_2021_1: "Incubação da TransitSwap",
                        desc_2021_2: "Número de utilizadores ultrapassa os 20M",
                        desc_2021_3: "Incubação da carteira fria KeyPal",
                        desc_2022_1: "Aquisição da dFox e rebranding da mesma para Extensão TokenPocket",
                        January: "Janeiro",
                        February: "Fevereiro",
                        March: "Março",
                        April: "Abril",
                        May: "Maio",
                        June: "Junho",
                        July: "Julho",
                        August: "Agosto",
                        September: "Setembro",
                        October: "Outubro",
                        November: "Novembro",
                        December: "Dezembro"
                    },
                    contact_us: {
                        title: "Contacta-nos",
                        service: "Apoio ao Cliente",
                        service_desc: "service@tokenpocket.pro",
                        bd: "Propostas de Colaboração",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "Programadores",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - Your universal digital wallet | TP wallet - ETH wallet - BTC wallet - BSC wallet - HECO wallet - OKExChain wallet - Polkadot wallet - Kusama wallet - DeFi wallet - Layer 2 wallet - EOS wallet - TRX wallet - nostr",
                    description: "A TokenPocket é uma carteira de activos digitais líder a nível mundial que suporta blockchains incluindo BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS e Layer 2",
                    keywords: "TokenPocket,Token Pocket,TP wallet,Ethereum wallet,Bitcoin,EOS,IOST,COSMOS,heco,bsc,layer2,DeFi,wallet,crypto,blockchain,web3,NFT,nostr"
                }
            }, vi: {
                COMMON: {
                    EMAIL: "Email",
                    BATCH_SENDER: "BatchSender",
                    YES: "Có",
                    NO: "Không",
                    HAS: "Có",
                    HAVENT: "Không",
                    BLOCKCHAIN: "Blockchain",
                    MULTIPLE_CHOICE: "(Nhiều lựa chọn)",
                    IS_SUPPORT_TP_CONNECT: "Có hỗ trợ kết nối TokenPocket không? (Ứng dụng mở rộng và ứng dụng dành cho thiết bị di động)",
                    SUPPORT_BOTH: "Cả hai đều được hỗ trợ",
                    SUPPORT_EXTENSION: "Chỉ ứng dụng mở rộng",
                    SUPPORT_MOBILE: "Chỉ ứng dụng dành cho thiết bị di động",
                    SUPPORT_NONE: "Không có",
                    blockchainWallet: "Ví Blockchain",
                    iostWallet: "Ví IOST",
                    tronWallet: "Ví TRON",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "Nộp",
                    symbol: "Tên Token",
                    success: "Success",
                    bl_symbol: "Biểu tượng BL",
                    precision: "Độ chính xác của Token",
                    decimal: "Số thập phân của Token",
                    totalSupply: "Tổng cung",
                    contract: "Hợp đồng Token",
                    website: "Trang web chính thức",
                    introduction: "Giới thiệu Token",
                    example: "Ví dụ",
                    submitTokenInfoAndLogo: "Cập nhật biểu tượng Token và các Thông tin khác",
                    toGithubSubmit: "Đi tới Github",
                    nftType: "Tiêu chuẩn giao thức NFT",
                    LAYOUT: {
                        features: "Tính năng",
                        buyCrypto: "Mua tiền điện tử",
                        mobileWallet: "Ví di động",
                        hardwareWallet: "Ví phần cứng",
                        extensionWallet: "Ví mở rộng",
                        desktop: "Ví trên máy tính để bàn",
                        fiveDegrees: "5Degrees",
                        versionVerification: "Version Verification",
                        approvalDetector: "Approval Detector",
                        tokenSecurity: "Bảo mật Token",
                        keyGenerator: "Tạo khóa",
                        information: "Thông tin",
                        blockchainGuide: "Hướng dẫn về Blockchain",
                        tronWallet: "Hướng dẫn về TRON",
                        iostWallet: "Hướng dẫn về IOST",
                        tpMan: "TP Man",
                        developers: "Nhà phát triển",
                        github: "Github (TP-Labs)",
                        devCenter: "Trung tâm phát triển",
                        subToken: "Gửi Token",
                        subDApp: "Gửi DApp",
                        subNFT: "Gửi NFT",
                        subChain: "Gửi chuỗi",
                        company: "Công ty",
                        about: "Giới thiệu",
                        careers: "Nghề nghiệp",
                        pressKit: "Press Kit",
                        swagShop: "Swag Shop",
                        support: "Ủng hộ",
                        helpCenter: "Trung tâm trợ giúp",
                        contactUs: "Liên hệ với chúng tôi",
                        legal: "Hợp pháp",
                        privacyPolicy: "Chính sách bảo mật",
                        terms: "Điều khoản Sử dụng",
                        toHome: "Trang chủ",
                        defiWallet: "Ví DeFi",
                        ETHWallet: "Ví Ethereum",
                        ethWallet: "Ví ETH"
                    }
                },
                HOME: {
                    download: "Tải xuống",
                    downloadNow: "Tải ngay",
                    HEADER: {
                        title: "Ví tiền điện tử an toàn của bạn giúp khám phá blockchain",
                        desc_1: "Dễ dàng và an toàn để mua, lưu trữ, gửi, hoán đổi token và thu thập NFT. Được tin dùng bởi hơn 20 triệu người dùng từ hơn 200 quốc gia và khu vực."
                    },
                    INTRODUCTION: {
                        title: "TokenPocket được người dùng toàn cầu tin cậy",
                        desc_1: "Chúng tôi đang cung cấp dịch vụ ví tiền điện tử an toàn và dễ dàng tại hơn 200 quốc gia và khu vực trên thế giới",
                        desc_2: "Phục vụ người dùng",
                        desc_3: "Giao dịch hàng ngày",
                        desc_4: "Hỗ trợ các quốc gia và khu vực"
                    },
                    SECURITY: {
                        title: "Bảo mật đúng cấp độ",
                        desc_1: "TokenPocket chỉ tạo và lưu trữ khóa và mật khẩu trên thiết bị của bạn, chỉ bạn mới có thể truy cập vào tài khoản và tài sản của mình.",
                        desc_2: "TokenPocket cũng phát triển ví lạnh phần cứng và tính năng ví đa chữ ký để tăng cường bảo mật khi bạn cần.",
                        desc_3: "Hỗ trợ BTC, ETH, BSC, TRON, Polygon, Solana, Cosmos, Polkadot, EOS, IOST, v.v."
                    },
                    EXCHANGE: {
                        title: "Trao đổi & Giao dịch Dễ dàng",
                        desc_1: "Bạn có thể giao dịch bằng tiền điện tử của mình mọi lúc, mọi nơi trong TokenPocket.",
                        desc_2: "Mua tiền điện tử bằng thẻ tín dụng. Lưu trữ, gửi, chuỗi chéo và trao đổi một cách dễ dàng.",
                        desc_3: "Tráo đổi",
                        desc_4: "Tức thì và dễ dàng",
                        desc_5: "Cầu",
                        desc_6: "Giữa các chuỗi khác nhau",
                        desc_7: "Mua tiền điện tử",
                        desc_8: "Trong 5 phút"
                    },
                    DAPPSTORE: {
                        title: "A DApp Store",
                        desc_1: "Bạn có thể tìm thấy các ứng dụng phi tập trung yêu thích của mình, khám phá và sử dụng những ứng dụng mới nhất và hấp dẫn nhất mà không cần rời khỏi ví.",
                        desc_2: "Trình duyệt DApp được tích hợp, bạn luôn có thể truy cập DApp bằng các liên kết của mình.",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "Được hỗ trợ"
                    },
                    COMMUNITY: {
                        title: "Cộng đồng",
                        desc_1: "Chúng tôi quyết tâm tạo ra một cộng đồng công nghệ mở và hoan nghênh tất cả các nhà phát triển cùng nhau xây dựng một thế giới blockchain thuận tiện, an toàn và phong phú hơn",
                        desc_2: "TP-Lab",
                        desc_3: "Cộng đồng",
                        desc_4: "Tài liệu phát triển"
                    },
                    DOWNLOAD: {
                        title: "Nhận Ví TokenPocket ngay bây giờ!",
                        desc_1: "Ví tiền điện tử an toàn và uy tín của bạn giúp khám phá blockchain"
                    },
                    FOLLOW: {
                        title: "Theo chúng tôi",
                        desc1: "Nhân viên TokenPocket sẽ không gửi tin nhắn riêng tư cho bạn!",
                        desc2: "Thận trọng! Bạn đang tham gia cộng đồng TokenPocket, có thể có ai đó mạo danh chúng tôi để gửi tin nhắn riêng tư cho bạn! Xin lưu ý rằng bất kỳ ai gửi tin nhắn riêng tư đều có thể là kẻ lừa đảo! Chúng tôi sẽ không bao giờ liên hệ với bạn trước!",
                        desc3: "Đã hiểu, nhập"
                    },
                    EXTENSIONMODAL: {
                        title: "Ứng dụng mở rộng hiện đã hoạt động!",
                        desc1: "Crypto & DeFi & GameFi của bạn",
                        desc2: "ví trên máy tính",
                        btnText: "Sử dụng ngay",
                        btnTextm: "Sao chép link",
                        tips: "Copy link thành công, vui lòng vào máy tính để mở"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "Bắt buộc phải có platfrom",
                        title: "Bắt buộc phải có tên DApp",
                        address: "Bắt buộc phải có hợp đồng DApp",
                        url: "Bắt buộc phải có trang web DApp",
                        desc: "Bắt buộc phải có mô tả",
                        icon_url: "Bắt buộc phải có logo DApp",
                        rakeBackAccount: "Bắt buộc phải có tài khoản hợp đồng",
                        email: "Bắt buộc phải có email",
                        others: "Bắt buộc phải có thông tin liên hệ khác",
                        tp_connect: "Mục này không được để trống"
                    },
                    title: "Tên DApp",
                    address: "Hợp đồng Thông minh",
                    url: "Trang web DApp",
                    desc: "Mô tả ngắn",
                    icon: "Logo DApp (Phải có kích thước 200x200 - hỗ trợ JPG, PNG.)",
                    referral: "Giới thiệu",
                    hasReferral: "Có hệ thống giới thiệu không",
                    referralReward: "Phát phần thưởng giới thiệu",
                    reward_1: "Tự động phát theo hợp đồng thông minh (Trực tiếp)",
                    reward_2: "Cần phải nhận phần thưởng trên DApp theo cách thủ công",
                    hasInviteReward: "Người mời có cần thực hiện giao dịch trong DApp để kích hoạt link giới thiệu không",
                    inviteAccount: "Hợp đồng thông minh về chuyển lời mời giới thiệu",
                    DAppRequirement: "Yêu cầu DApp",
                    requirement_1: "1. DApp cần phải hỗ trợ ứng dụngTokenPocket trên thiết bị di động và ứng dụng TokenPocket mở rộng.",
                    requirement_2: "2. Trang web được cung cấp có thể truy cập được và ổn định.",
                    requirement_3: "3. Các hợp đồng thông minh đã được triển khai trên mạng chính và phần nhạy cảm phải là mã nguồn mở.",
                    requirement_4: "4. Các hợp đồng nhạy cảm yêu cầu phải có báo cáo kiểm tra từ các cơ quan an ninh bên thứ ba",
                    requirement_5: "5. Logic tương tác rõ ràng và đã được điều chỉnh cho phù hợp với giao diện người dùng di động.",
                    requirement_6: "6. Tuân thủ luật định có liên quan, không gian lận và vi phạm.",
                    requirement_7: "7. Nếu bạn vi phạm các luật định liên quan, bạn sẽ phải tự chịu trách nhiệm pháp lý tương ứng.",
                    dappInfo: "Thông tin DApp:",
                    necessary: "yêu cầu",
                    language: "Ngôn ngữ DApp",
                    languageDesc: "(Vui lòng gửi riêng nếu có nhiều ngôn ngữ)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "Mô tả ngắn gọn về dự án trong một câu, câu này sẽ xuất hiện trong phụ đề DApp",
                    auditInfo: "Thông tin kiểm tra:",
                    hasAudit: "Việc kiểm tra hợp đồng đã được thực hiện hay chưa",
                    auditUrl: "Url báo cáo kiểm tra",
                    auditUrlExample: "Ví dụ: https://auditlink.com",
                    auditReport: "Báo cáo kiểm tra",
                    auditUpload: "Tải lên",
                    contact: "Thông tin liên hệ",
                    contactDesc: "Hãy chắc chắn để lại thông tin liên hệ cho bộ phận dịch vụ khách hàng ngoài hộp thư, nếu không sẽ không được xem xét",
                    emailAddr: "Email",
                    emailExample: "Ví dụ: service@yourdomain.com",
                    others: "Khác",
                    othersExample: "Ví dụ: Telegram：@123456789",
                    auditOptional: "Điền vào ít nhất một mục thông tin kiểm tra",
                    oversize: "đã vượt quá số ký tự đủ điều kiện",
                    select: "Lựa chọn",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "Xem hướng dẫn >>"
                },
                DOWNLOAD: {
                    TITLE: "Tải xuống TokenPocket",
                    TITLE_Android: "TokenPocket dành cho Android",
                    TITLE_IOS: "TokenPocket dành cho iOS",
                    TITLE_Chrome: "TokenPocket dành cho trình duyệt của bạn",
                    TEXT: "TokenPocket là một ví tiền điện tử đa chuỗi, dễ sử dụng và an toàn, được hàng triệu người tin tưởng.",
                    TEXT_Chrome: "TokenPocket mở rộng là một ví tiền điện tử đa chuỗi, tất cả các chuỗi tương thích EVM đều được hỗ trợ. Sử dụng dễ dàng và an toàn, được hàng triệu người tin cậy.",
                    TEXT_PC: "TokenPocket Desktop là ví đa chuỗi lớn nhất dựa trên nền tảng EOS ETH BOS TRON, chúng tôi cố gắng cung cấp khả năng quản lý tài sản số mạnh mẽ và an toàn cho người dùng.",
                    scanCode: "Quét để tải xuống",
                    installTutorial: "Hướng dẫn cài đặt",
                    desc_1: "Tải xuống ứng dụng từ trang web chính thức và kiểm tra chứng nhận SSL của ứng dụng",
                    desc_2: "Bảo vệ Recovery Phrase (mnemonic) và Private key của bạn khỏi bị rò rỉ, không bao giờ chia sẻ với người khác",
                    desc_3: "Tìm hiểu thêm các mẹo bảo mật",
                    verifyText: "Phiên bản Android mới nhất:",
                    verifyText1: "Cách xác minh tính bảo mật của ứng dụng",
                    verifyText2: "Phiên bản mới nhất:",
                    verifyText3: "Phiên bản Google Play mới nhất:",
                    footerTitle: "Tạo ấn tượng ban đầu tuyệt vời",
                    footerDesc_1: "Hỗ trợ BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST, v.v.",
                    footerDesc_2: "Bảo vệ an ninh nhiều lớp",
                    footerDesc_3: "Hỗ trợ DeFi, DApp, GameFi và NFT",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "đã chính thức được chỉ định là nhà xuất bản Ứng dụng iOS duy nhất của TokenPocket",
                    tp_wallet_version: "TP Wallet Phiên bản:",
                    token_pocket_version: "Token Pocket Phiên bản:",
                    delisted: "Đã hủy niêm yết",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "Bắt buộc phải có email",
                        address: "Bắt buộc phải có địa chỉ",
                        owner_address: "Bắt buộc phải có địa chỉ chủ sở hữu",
                        symbol: "Bắt buộc phải có biểu tượng",
                        bl_symbol: "Bắt buộc phải có biểu tượng BL",
                        total_supply: "Bắt buộc phải có tổng cung",
                        decimal: "Bắt buộc phải có dấu thập phân",
                        precision: "Bắt buộc phải có độ chính xác",
                        gas: "Bắt buộc phải có GAS",
                        website: "Bắt buộc phải có trang web",
                        companyName: "Bắt buộc phải có tên công ty hoặc tên cá nhân",
                        contact: "Bắt buộc phải có liên hệ",
                        name: "Bắt buộc phải có giới thiệu về dự án",
                        icon_url: "Bắt buộc phải có logo"
                    },
                    icon: "Logo của token (200*200 pixel, hỗ trợ jpg, jpeg, png, định dạng đặt tên tệp hình ảnh: tên token, logo không cần bo góc tròn)",
                    handleText: "Chúng tôi sẽ xử lý yêu cầu của bạn trong 2 ngày làm việc"
                },
                RECRUITING: {
                    title: "TP Man Recruitment Plan",
                    text: "Join the TokenPocket community",
                    text1: "Committed to the blockchain world and contribute your part",
                    text2: "We build a Web3.0 world together",
                    joinUs: "Join Us",
                    aboutTitle: "About TP Man",
                    aboutText: "TP Man is an important part of the TokenPocket community, and we sincerely invite you to join us!",
                    aboutText1: "You are a blockchain enthusiast and endorse the industry value.",
                    aboutText2: "Enjoy the convenience brought by TokenPocket wallet when you explore the blockchain world.",
                    missionTitle: "The Mission of TP Man",
                    missionText: "Help TokenPocket to serve more blockchain users around the world. We hope you, meet two of the following requirements to apply.",
                    missionText1: "Expand and promote TokenPocket cooperation with companies or hot projects in your country through various channels",
                    missionText2: "Plan marketing activities that meet the needs of local users",
                    missionText3: "Have the ability to operate mainstream social medias such as Twitter, Youtube, Telegram, and Discord",
                    missionText4: "Fluent in English, and be able to complete translation work",
                    missionText5: "TokenPocket plans to provide more usage and technical support for global blockchain users, so we hope that you have a certain understanding of the blockchain markets of no less than one country and their users (India, the United States, Turkey, Russia, South Korea, Vietnam, the Philippines, etc.)",
                    getTitle: "What will you get?",
                    getText: "A work experience directly involved with various fields of the blockchain industry, and you will get but not limited to communication opportunities with DApp projects, Influencers, and mainstream media in the industry.",
                    getText1: "Get rich rewards from your work such as tweets translation, making video, community operation and business cooperation.",
                    getText2: "Get the most professional blockchain knowledge training and explore the Web3.0 world with the team together.",
                    getText3: "TokenPocket official benefits, including TokenPocket Swag and hardware wallets.",
                    processTitle: "Recruitment process",
                    processText: "Submit CV",
                    processText1: "CV screening",
                    processText2: "Online interview ",
                    processText3: "Interview results",
                    processText4: "Welcome aboard",
                    applyTitle: "Who can apply",
                    applyText: "Face the world, regardless of country",
                    applyText1: "Be keen and curious about the blockchain world",
                    applyText2: "Fill out the form and attach your resume, then we will contact you as soon as possible",
                    footerTitle: "About TokenPocket",
                    footerText: "over",
                    footerText1_1: "20M",
                    footerText1_2: "global users",
                    footerText2_1: "3.5M",
                    footerText2_2: "monthly active users",
                    footerText3_1: "200",
                    footerText3_2: "countries and regions",
                    footerText4: "TokenPocket is the world's leading multi-chain self-custodial wallet",
                    footerText5: "Coming soon"
                },
                NAVIGATION: {
                    product: {
                        title: "Sản phẩm",
                        selfCustodyWallet: "Ví di động",
                        selfCustodyWalletDesc: "Ví di động Crypto & DeFi trên Blockchain.",
                        hardwareWallet: "Ví phần cứng",
                        hardwareWalletDesc: "Nhận KeyPal của bạn, để bảo vệ tài sản của bạn.",
                        extensionWallet: "Ví mở rộng",
                        extensionWalletDesc: "Một loại ví tốt hơn trên máy tính của bạn.",
                        transit: "Chuyển tuyến",
                        transitDesc: "Công cụ tổng hợp đa chuỗi DEX và Nền tảng thị trường NFT.",
                        fiveDegrees: "5Degrees",
                        fiveDegreesDesc: "Giao thức mạng xã hội trong Web3.0.",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "Hỗ trợ cả self-custodial staking và small amount staking",
                        buyCrypto: "Mua tiền điện tử",
                        buyCryptoDesc: "Mua tiền điện tử bằng thẻ tín dụng của bạn"
                    },
                    assets: {title: "Tài sản"},
                    collaborations: {title: "hợp tác"},
                    community: {title: "cộng đồng", developers: "nhà phát triển", recruiting: "TP Man"},
                    helpCenter: {title: "Hỗ trợ"}
                },
                ABOUT: {
                    title: "About Us",
                    desc: "TokenPocket is a multi-chain decentralized wallet, it provides users with mobile wallet, extension wallet and hardware wallet, supporting public chains including Bitcoin, Ethereum, BNB Smart Chain, TRON, Aptos, Polygon, Solana, Polkadot, EOS and all EVM compatible chains. Serving over 20 millions users from more than 200 countries and regions. It is a world-wide leading crypto wallet that trusted by global users.",
                    philosophy: {
                        title: "Our philosophy",
                        desc: "We insist on an open technology community, and we welcome all developers to build a more convenient, secure and richer blockchain world together",
                        ambition: "Ambition",
                        ambition_desc: "Make the blockchain happen everywhere",
                        value: "Value",
                        value_desc: "Let data return to users, make value belong to real owners",
                        attitude: "Attitude",
                        attitude_desc: "Open-minded, mutual collaboration"
                    },
                    milestones: {
                        title: "Milestones",
                        desc_2018_1: "TokenPocket Founded",
                        desc_2018_2: "Invested by Huobi, Hofan, Byte Capital",
                        desc_2019_1: "Released desktop wallet, supported TRON",
                        desc_2019_2: "Google Play download exceeded 1,000,000",
                        desc_2020_1: "HD wallet supported",
                        desc_2020_2: "Supported BSC and DeFi tendency",
                        desc_2020_3: "Supported Eth2.0 Staking",
                        desc_2021_1: "Incubated Transit",
                        desc_2021_2: "User base exceeded 20,000,000",
                        desc_2021_3: "Incubated KeyPal hardware wallet",
                        desc_2022_1: "Acquired dFox and rebranded to TokenPocket Extension",
                        January: "January",
                        February: "February",
                        March: "March",
                        April: "April",
                        May: "May",
                        June: "June",
                        July: "July",
                        August: "August",
                        September: "September",
                        October: "October",
                        November: "November",
                        December: "December"
                    },
                    contact_us: {
                        title: "Contact Us",
                        service: "Customer Service",
                        service_desc: "service@tokenpocket.pro",
                        bd: "Business Collaborations",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "Developers",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - Ví kĩ thuật số toàn cầu của bạn | Ví TP - Ví ETH - Ví BTC - Ví BSC - Ví HECO - Ví OKExChain - Ví Polkadot - Ví Kusama - Ví DeFi - Ví Layer 2 - Ví EOS - Ví TRX - nostr",
                    description: "TokenPocket là ví kỹ thuật số hàng đầu thế giới, hỗ trợ các blockchain công khai bao gồm BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS và Layer 2.",
                    keywords: "TokenPocket, Token Pocket, ví TP, ví Ethereum, Bitcoin, EOS, IOST, COSMOS, heco, bsc, layer2, DeFi, ví,wallet,crypto,blockchain,web3,NFT,nostr"
                }
            }, th: {
                COMMON: {
                    EMAIL: "อีเมล",
                    BATCH_SENDER: "ผู้ส่งแบทช์",
                    YES: "ใช่",
                    NO: "ไม่",
                    HAS: "ใช่",
                    HAVENT: "ไม่",
                    BLOCKCHAIN: "บล็อกเชน",
                    MULTIPLE_CHOICE: "(ตัวเลือกหลากหลาย)",
                    IS_SUPPORT_TP_CONNECT: "องรับการเชื่อมต่อ โทเค็นพ็อกเก็ต หรือไม่ (ส่วนขยายและแอพมือถือ)",
                    SUPPORT_BOTH: "รองรับทั้งคู่",
                    SUPPORT_EXTENSION: "เฉพาะส่วนขยาย",
                    SUPPORT_MOBILE: "เฉพาะมือถือ",
                    SUPPORT_NONE: "ไม่มี",
                    blockchainWallet: "บล็อกเชนกระเป๋าเงิน",
                    iostWallet: "กระเป๋าเงิน IOST",
                    tronWallet: "กระเป๋าเงิน TRON",
                    platformInfo: {
                        eos: "EOS",
                        moac: "MOAC",
                        eth: "ETH",
                        jt: "Jingtum ",
                        enu: "ENU",
                        bos: "BOS",
                        iost: "IOST",
                        cosmos: "COSMOS",
                        bnb: "BNB",
                        trx: "TRON",
                        bsc: "BSC",
                        heco: "HECO",
                        okex: "OKExChain",
                        dot: "Polkadot",
                        hsc: "HSC",
                        matic: "Polygon",
                        klaytn: "Klaytn",
                        arb: "Arbitrum One",
                        arbn: "Arbirtum Nova",
                        ftm: "Fantom",
                        etc: "Ethereum Classic",
                        cfx: "Conflux eSpace",
                        solana: "Solana",
                        avax: "AVAX",
                        oe: "Optimistic Ethereum",
                        xdai: "Gnosis Chain",
                        harmony: "Harmony",
                        wax: "WAX",
                        aurora: "Aurora",
                        ksm: "Kusama",
                        mb: "Moonbeam",
                        sbg: "SubGame",
                        kcc: "KCC Mainnet",
                        lat: "PlatON",
                        bttc: "BTTC",
                        gt: "GateChain",
                        halo: "HALO",
                        aptos: "Aptos",
                        fil: "Filecoin FVM",
                        zks: "zkSync Era",
                        eosevm: "EOS EVM",
                        mantle: "Mantle",
                        linea: "Linea",
                        base: "Base",
                        opbnb: "opBNB",
                        polyzk: "Polygon zkEVM"
                    },
                    submit: "ส่ง",
                    symbol: "ชื่อโทเค็น",
                    success: "Success",
                    bl_symbol: "สัญลักษณ์ BL",
                    precision: "ความแม่นยำของโทเค็น",
                    decimal: "ทศนิยมของโทเค็น",
                    totalSupply: "อุปทานทั้งหมด",
                    contract: "สัญญาโทเค็น",
                    website: "เว็บไซต์อย่างเป็นทางการ",
                    introduction: "โทเค็นแนะนำ",
                    example: "ตัวอย่าง",
                    submitTokenInfoAndLogo: "Uอัปเดตโลโก้โทเค็นและข้อมูลอื่น ๆ",
                    toGithubSubmit: "ไปที่ Github",
                    nftType: "มาตรฐานโปรโตคอล NFT",
                    LAYOUT: {
                        features: "คุณสมบัติ",
                        buyCrypto: "ซื้อคริปโต",
                        mobileWallet: "กระเป๋าเงินมือถือ",
                        hardwareWallet: "กระเป๋าเงินฮาร์ดแวร์",
                        extensionWallet: "กระเป๋าเงินเสริม",
                        desktop: "กระเป๋าเงินเดสก์ท็อป",
                        fiveDegrees: "5องศา",
                        versionVerification: "Version Verification",
                        approvalDetector: "Approval Detector",
                        tokenSecurity: "ความปลอดภัยของโทเค็น",
                        keyGenerator: "ตัวสร้างคีย์",
                        information: "ข้อมูล",
                        blockchainGuide: "คู่มือบล็อคเชน",
                        tronWallet: "คู่มือ TRON",
                        iostWallet: "คู่มือ IOST",
                        tpMan: "ชาย TP",
                        developers: "นักพัฒนา",
                        github: "Github (TP-Labs)",
                        devCenter: "ศูนย์นักพัฒนา",
                        subToken: "ส่งโทเค็น",
                        subDApp: "ส่งดีแอป",
                        subNFT: "ส่ง NFT",
                        subChain: "ส่ง โซ่",
                        company: "บริษัท",
                        about: "กี่ยวกับ",
                        careers: "อาชีพ",
                        pressKit: "Press Kit",
                        swagShop: "Swag Shop",
                        support: "สนับสนุน",
                        helpCenter: "ศูนย์ช่วยเหลือ",
                        contactUs: "ติดต่อเรา",
                        legal: "ถูกกฎหมาย",
                        privacyPolicy: "นโยบายความเป็นส่วนตัว",
                        terms: "ข้อกำหนดการใช้งาน",
                        toHome: "บ้าน",
                        defiWallet: "กระเป๋าเงินDeFi",
                        ETHWallet: "กระเป๋าเงินEthereum",
                        ethWallet: "กระเป๋าเงินETH"
                    }
                },
                HOME: {
                    download: "ดาวน์โหลด",
                    downloadNow: "ดาวน์โหลดทันที",
                    HEADER: {
                        title: "กระเป๋าเงินคริปโตที่ปลอดภัยของคุณเพื่อสำรวจบล็อคเชน",
                        desc_1: "ซื้อ จัดเก็บ ส่ง แลกเปลี่ยนโทเค็นและรวบรวม NFT ได้ง่ายและปลอดภัย ได้รับความไว้วางใจจากผู้ใช้กว่า 20 ล้านคนจาก 200 กว่าประเทศและภูมิภาค"
                    },
                    INTRODUCTION: {
                        title: "โทเค็นพ็อกเก็ต ได้รับความไว้วางใจจากผู้ใช้ทั่วโลก",
                        desc_1: "เราให้บริการกระเป๋าเงินคริปโตที่ปลอดภัยและง่ายดายกว่า 200 ประเทศและภูมิภาคทั่วโลก",
                        desc_2: "ให้บริการผู้ใช้",
                        desc_3: "ธุรกรรมรายวัน",
                        desc_4: "ประเทศและภูมิภาคที่สนับสนุน"
                    },
                    SECURITY: {
                        title: "ความปลอดภัยตามที่ควรจะเป็น",
                        desc_1: "โทเค็นพ็อกเก็ต สร้างและจัดเก็บคีย์และรหัสผ่านบนอุปกรณ์ของคุณเท่านั้น มีเพียงคุณเท่านั้นที่สามารถเข้าถึงบัญชีและทรัพย์สินของคุณ",
                        desc_2: "โทเค็นพ็อกเก็ต ยังพัฒนาฮาร์ดแวร์กระเป๋าเงินเย็นและคุณสมบัติกระเป๋าเงินหลายป้ายเพื่อเพิ่มความปลอดภัยตามที่คุณต้องการ",
                        desc_3: "รองรับ BTC, ETH, BSC, TRON, Polygon, Solana, Cosmos, Polkadot, EOS, IOST และอื่นๆ"
                    },
                    EXCHANGE: {
                        title: "แลกเปลี่ยนและทำธุรกรรมได้อย่างง่ายดาย",
                        desc_1: "คุณสามารถแลกเปลี่ยนคริปโตของคุณได้ทุกที่ทุกเวลาในโทเค็นพ็อกเก็ต",
                        desc_2: "ซื้อคริปโต ด้วยบัตรเครดิต จัดเก็บ ส่ง ข้ามห่วงโซ่และแลกเปลี่ยนได้อย่างง่ายดาย",
                        desc_3: "สลับ",
                        desc_4: "ทันทีและง่ายมาก",
                        desc_5: "สะพาน",
                        desc_6: "ท่ามกลางสายโซ่ต่างๆ",
                        desc_7: "ซื้อคริปโต",
                        desc_8: "ภายใน 5 นาที"
                    },
                    DAPPSTORE: {
                        title: "ดีแอปสโตร์",
                        desc_1: "คุณสามารถค้นหาแอปพลิเคชั่นกระจายอำนาจที่คุณชื่นชอบ ค้นพบแอปพลิเคชั่นล่าสุดและร้อนแรงที่สุด และใช้งานได้โดยไม่ต้องออกจากกระเป๋าเงิน",
                        desc_2: "รวมดีแอปเบราว์เซอร์อด้วย คุณสามารถเข้าถึง ดีแอป ด้วยลิงก์ของคุณได้ตลอดเวลา",
                        desc_3: "DeFi",
                        desc_4: "NFT",
                        desc_5: "DApp",
                        desc_6: "รองรับ"
                    },
                    COMMUNITY: {
                        title: "ชุมชน",
                        desc_1: "เรายืนกรานในชุมชนเทคโนโลยีแบบเปิด และเรายินดีต้อนรับนักพัฒนาทุกคนเพื่อสร้างโลกบล็อกเชนที่สะดวก ปลอดภัย และสมบูรณ์ยิ่งขึ้นไปด้วยกัน",
                        desc_2: "TP-Lab",
                        desc_3: "ชุมชน",
                        desc_4: "เอกสารสำหรับนักพัฒนา"
                    },
                    DOWNLOAD: {
                        title: "รับ กระเป๋าเงินโทเค็นพ็อกเก็ต ทันที!",
                        desc_1: "กระเป๋าเงินคริปโตที่ปลอดภัยและเชื่อถือได้ของคุณในการสำรวจบล็อคเชน"
                    },
                    FOLLOW: {
                        title: "ตามเรามา",
                        desc1: "พนักงาน TokenPocket จะไม่ส่งข้อความส่วนตัวถึงคุณ!",
                        desc2: "คำเตือน! คุณกำลังเข้าสู่ชุมชน TokenPocket อาจมีใครบางคนแอบอ้างเราเพื่อส่งข้อความส่วนตัวถึงคุณ! โปรดทราบว่าทุกคนที่ส่งข้อความส่วนตัวอาจเป็นสแกมเมอร์! เราจะไม่ติดต่อคุณก่อน!",
                        desc3: "เข้าใจแล้ว ป้อน"
                    },
                    EXTENSIONMODAL: {
                        title: "ส่วนขยายใช้งานได้แล้ว",
                        desc1: "คริปโต และ DeFi และ GameFi ของคุณ",
                        desc2: "กระเป๋าเงินบนคอมพิวเตอร์",
                        btnText: "ใช้งานเดี๋ยวนี้",
                        btnTextm: "คัดลอกลิงก์",
                        tips: "คัดลอกลิงก์สำเร็จ โปรดไปที่คอมพิวเตอร์เพื่อเปิด"
                    }
                },
                DAPP: {
                    RULES: {
                        platform: "จำเป็นต้องมีแพลตฟอร์ม",
                        title: "ต้องระบุชื่อดีแอป",
                        address: "ต้องมีสัญญาดีแอป",
                        url: "จำเป็นต้องมีเว็บไซต์ดีแอป",
                        desc: "ต้องระบุ",
                        icon_url: "ต้องมีโลโก้ดีแอป",
                        rakeBackAccount: "ต้องมีบัญชีสัญญา",
                        email: "จำเป็นต้องใช้อีเมล",
                        others: "ต้องการข้อมูลติดต่ออื่น",
                        tp_connect: "รายการนี้ไม่สามารถเว้นว่างได้"
                    },
                    title: "ชื่อดีแอป",
                    address: "Smart Contract",
                    url: "เว็บไซต์ดีแอป",
                    desc: "คำอธิบายสั้นๆ",
                    icon: "โลโก้ ดีแอป(ต้องเป็น 200x200 - supports JPG, PNG.)",
                    referral: "อ้างอิง",
                    hasReferral: "มีระบบการอ้างอิงหรือไม่",
                    referralReward: "การกระจายรางวัลผู้อ้างอิ",
                    reward_1: "แจกจ่ายอัตโนมัติตามสัญญาอัจฉริยะ (สด)",
                    reward_2: "จำเป็นต้องรับสิทธิ์ในดีแอป ด้วยตนเอง",
                    hasInviteReward: "ผู้เชิญจำเป็นต้องทำธุรกรรมในดีแอป เพื่อเปิดใช้งานลิงก์ผู้อ้างอิงหรือไม่",
                    inviteAccount: "สัญญาอัจฉริยะของการกระจายผู้อ้างอิง",
                    DAppRequirement: "ข้อกำหนดของดีแอป",
                    requirement_1: "1. ดีแอปต้องรองรับ โทเค็นพ็อกเก็ตมือถือ และส่วนขยาย โทเค็นพ็อกเก็ต",
                    requirement_2: "2. เว็บไซต์ที่ให้มานั้นสามารถเข้าถึงได้และเสถียร",
                    requirement_3: "3. สัญญาอัจฉริยะได้ปรับใช้บน mainnet และส่วนที่ละเอียดอ่อนต้องเป็นโอเพ่นซอร์ส",
                    requirement_4: "4. สัญญาที่มีความละเอียดอ่อนต้องมีรายงานการตรวจสอบจากหน่วยงานรักษาความปลอดภัยบุคคลที่สาม",
                    requirement_5: "5. ตรรกะการโต้ตอบมีความชัดเจนและได้รับการปรับให้เข้ากับ UI บนมือถือแล้ว",
                    requirement_6: "6. ปฏิบัติตามกฎหมายและข้อบังคับที่เกี่ยวข้อง โดยปราศจากการฉ้อโกงและการละเมิด",
                    requirement_7: "7. หากคุณละเมิดกฎหมายและข้อบังคับที่เกี่ยวข้อง คุณจะต้องรับผิดชอบทางกฎหมายที่เกี่ยวข้องโดยสมัครใจ",
                    dappInfo: "ข้อมูลดีแอป",
                    necessary: "จำเป็น",
                    language: "ภาษาดีแอป",
                    languageDesc: "(โปรดส่งแยกกันสำหรับหลายภาษา)",
                    en: "English",
                    zh: "中文简体",
                    zhTW: "中文繁体",
                    descDesc: "คำอธิบายสั้น ๆ ของโครงการในหนึ่งประโยค ซึ่งจะปรากฏในคำบรรยายของดีแอป",
                    auditInfo: "ข้อมูลการตรวจสอบ",
                    hasAudit: "ไม่ว่าจะมีการตรวจสอบสัญญาหรือไม่",
                    auditUrl: "รายงานการตรวจสอบURL",
                    auditUrlExample: "ตัวอย่างเช่น: https://auditlink.com",
                    auditReport: "รายงานการตรวจสอบ",
                    auditUpload: "อัพโหลด",
                    contact: "รายละเอียดการติดต่อ",
                    contactDesc: "โปรดทิ้งข้อมูลติดต่อฝ่ายบริการลูกค้านอกเหนือจากกล่องจดหมาย มิฉะนั้น จะไม่ผ่านการตรวจสอบ",
                    emailAddr: "อีเมล",
                    emailExample: "ตัวอย่างเช่น: service@yourdomain.com",
                    others: "อื่นๆ",
                    othersExample: "ตัวอย่างเช่น: โทรเลข：@123456789",
                    auditOptional: "ใส่ข้อมูลการตรวจสอบอย่างน้อยหนึ่งรายการ",
                    oversize: " เกินอักขระที่ผ่านการรับรอง",
                    select: "เลือก",
                    tutorial_url: "https://help.tokenpocket.pro/developer-en/",
                    tutorial: "ดูบทช่วยสอน>>"
                },
                DOWNLOAD: {
                    TITLE: "ดาวน์โหลด โทเค็นพ็อกเก็ต",
                    TITLE_Android: "โทเค็นพ็อกเก็ต สำหรับ แอนดรอยด์",
                    TITLE_IOS: "โทเค็นพ็อกเก็ต สำหรับ iOS",
                    TITLE_Chrome: "โทเค็นพ็อกเก็ตสำหรับเบราว์เซอร์ของคุณ",
                    TEXT: "โทเค็นพ็อกเก็ตเป็นกระเป๋าเงินดิจิตอลเข้ารหัสหลายสาย ใช้งานง่ายและปลอดภัยซึ่งคนนับล้านไว้วางใจ",
                    TEXT_Chrome: "โทเค็นพ็อกเก็ต Extension เป็นกระเป๋าเงินดิจิตอลเข้ารหัสหลายสาย รองรับ EVM ที่เข้ากันได้กับ EVM ทั้งหมด ง่ายและปลอดภัยในการใช้งานที่ได้รับความไว้วางใจจากคนนับล้าน",
                    TEXT_PC: "โทเค็นพ็อกเก็ต Desktop เป็นกระเป๋าเงิน multi-blockchain ที่ใหญ่ที่สุดตาม EOS ETH BOS TRON เรามุ่งมั่นที่จะมอบการจัดการสินทรัพย์ดิจิทัลที่มีประสิทธิภาพและปลอดภัยแก่ผู้ใช้",
                    scanCode: "Scan to Download",
                    installTutorial: "Install Tutorial",
                    desc_1: "ดาวน์โหลดแอปจากเว็บไซต์อย่างเป็นทางการและตรวจสอบใบรับรอง SSL",
                    desc_2: "ปกป้อง Recovery Phrase (mnemonic) และ Private Key ของคุณไม่ให้รั่วไหล อย่าแชร์ให้ผู้อื่นทราบ",
                    desc_3: "เรียนรู้เคล็ดลับความปลอดภัยเพิ่มเติม",
                    verifyText: "เวอร์ชัน แอนดรอย ล่าสุด",
                    verifyText1: "วิธีตรวจสอบความปลอดภัยของแอป",
                    verifyText2: "เวอร์ชันล่าสุด:",
                    verifyText3: "เวอร์ชันล่าสุดของ Google Play",
                    footerTitle: "สร้างความประทับใจแรกพบที่ยอดเยี่ยม",
                    footerDesc_1: "รองรับ BTC, ETH, BSC, TRON, Matic, Aptos, Solana, EOS, Polkadot, IOST และอื่นๆ",
                    footerDesc_2: "การป้องกันความปลอดภัยหลายชั้น",
                    footerDesc_3: "รองรับ DeFi, DApp, GameFi และ NFT",
                    coming_soon: "Coming Soon",
                    desc_tp_wallet: "ได้รับการแต่งตั้งอย่างเป็นทางการให้เป็นผู้เผยแพร่แอป iOS ของ TokenPocket แต่เพียงผู้เดียว",
                    tp_wallet_version: "TP Wallet รุ่น:",
                    token_pocket_version: "Token Pocket รุ่น:",
                    delisted: "ถูกเพิกถอน",
                    checkoutAllVersion: "Check All Versions"
                },
                TOKEN: {
                    RULES: {
                        email: "จำเป็นต้องใช้อีเมล",
                        address: "ต้องระบุที่อยู่",
                        owner_address: "ต้องระบุที่อยู่ของเจ้าของ",
                        symbol: "ต้องมีสัญลักษณ์",
                        bl_symbol: "จำเป็นต้องใช้สัญลักษณ์ BL",
                        total_supply: "ต้องจัดหาทั้งหมด",
                        decimal: "ต้องมีทศนิยม",
                        precision: "ต้องมีความแม่นยำ",
                        gas: "จำเป็นต้องใช้ GAS",
                        website: "จำเป็นต้องมีเว็บไซต์",
                        companyName: "จำเป็นต้องระบุชื่อบริษัทหรือบุคคล",
                        contact: "ต้องติดต่อ",
                        name: "จำเป็นต้องมีการแนะนำโครงการ",
                        icon_url: "ต้องมีโลโก้"
                    },
                    icon: "โลโก้โทเค็น (200 * 200 พิกเซล รองรับ jpg, jpeg, png, รูปแบบการตั้งชื่อไฟล์รูปภาพ: ชื่อโทเค็น โลโก้ไม่ต้องการมุมมน)",
                    handleText: "เราจะดำเนินการตามคำขอของคุณใน 2 วันทำการ"
                },
                RECRUITING: {
                    title: "TP Man Recruitment Plan",
                    text: "Join the TokenPocket community",
                    text1: "Committed to the blockchain world and contribute your part",
                    text2: "We build a Web3.0 world together",
                    joinUs: "Join Us",
                    aboutTitle: "About TP Man",
                    aboutText: "TP Man is an important part of the TokenPocket community, and we sincerely invite you to join us!",
                    aboutText1: "You are a blockchain enthusiast and endorse the industry value.",
                    aboutText2: "Enjoy the convenience brought by TokenPocket wallet when you explore the blockchain world.",
                    missionTitle: "The Mission of TP Man",
                    missionText: "Help TokenPocket to serve more blockchain users around the world. We hope you, meet two of the following requirements to apply.",
                    missionText1: "Expand and promote TokenPocket cooperation with companies or hot projects in your country through various channels",
                    missionText2: "Plan marketing activities that meet the needs of local users",
                    missionText3: "Have the ability to operate mainstream social medias such as Twitter, Youtube, Telegram, and Discord",
                    missionText4: "Fluent in English, and be able to complete translation work",
                    missionText5: "TokenPocket plans to provide more usage and technical support for global blockchain users, so we hope that you have a certain understanding of the blockchain markets of no less than one country and their users (India, the United States, Turkey, Russia, South Korea, Vietnam, the Philippines, etc.)",
                    getTitle: "What will you get?",
                    getText: "A work experience directly involved with various fields of the blockchain industry, and you will get but not limited to communication opportunities with DApp projects, Influencers, and mainstream media in the industry.",
                    getText1: "Get rich rewards from your work such as tweets translation, making video, community operation and business cooperation.",
                    getText2: "Get the most professional blockchain knowledge training and explore the Web3.0 world with the team together.",
                    getText3: "TokenPocket official benefits, including TokenPocket Swag and hardware wallets.",
                    processTitle: "Recruitment process",
                    processText: "Submit CV",
                    processText1: "CV screening",
                    processText2: "Online interview ",
                    processText3: "Interview results",
                    processText4: "Welcome aboard",
                    applyTitle: "Who can apply",
                    applyText: "Face the world, regardless of country",
                    applyText1: "Be keen and curious about the blockchain world",
                    applyText2: "Fill out the form and attach your resume, then we will contact you as soon as possible",
                    footerTitle: "About TokenPocket",
                    footerText: "over",
                    footerText1_1: "20M",
                    footerText1_2: "global users",
                    footerText2_1: "3.5M",
                    footerText2_2: "monthly active users",
                    footerText3_1: "200",
                    footerText3_2: "countries and regions",
                    footerText4: "TokenPocket is the world's leading multi-chain self-custodial wallet",
                    footerText5: "Coming soon"
                },
                NAVIGATION: {
                    product: {
                        title: "ผลิตภัณฑ์",
                        selfCustodyWallet: "กระเป๋าเงินมือถือ",
                        selfCustodyWalletDesc: "คริปโต&DeFi กระเป๋าเงินมือถือ บนบล็อคเชน",
                        hardwareWallet: "กระเป๋าเงินฮาร์ดแวร์",
                        hardwareWalletDesc: "รับ KeyPal ของคุณเพื่อปกป้องทรัพย์สินของคุณ",
                        extensionWallet: "กระเป๋าสเงินเสริม",
                        extensionWalletDesc: "กระเป๋าเงินที่ดีกว่าบนคอมพิวเตอร์ของคุณ",
                        transit: "ขนส่ง",
                        transitDesc: "Multi-chain DEX Aggregator และ  NFT Marketplace แพลตฟอร์ม",
                        fiveDegrees: "5องศา",
                        fiveDegreesDesc: "โซเชียลเน็ตเวิร์กโปรโตคอลใน Web3.0",
                        stakeVault: "ETH Staking Vault",
                        stakeVaultDesc: "สนับสนุนทั้ง self-custodial staking และ small amount staking",
                        buyCrypto: "ซื้อเหรียญสกุลเงินดิจิทัล",
                        buyCryptoDesc: "ซื้อเหรียญสกุลเงินดิจิทัลด้วยบัตรเครดิตของคุณ"
                    },
                    assets: {title: "ทรัพย์สิน"},
                    collaborations: {title: "ความร่วมมือ"},
                    community: {title: "ชุมชน", developers: "นักพัฒนา", recruiting: "ชายTP"},
                    helpCenter: {title: "ช่วย"}
                },
                ABOUT: {
                    title: "About Us",
                    desc: "TokenPocket is a multi-chain decentralized wallet, it provides users with mobile wallet, extension wallet and hardware wallet, supporting public chains including Bitcoin, Ethereum, BNB Smart Chain, TRON, Aptos, Polygon, Solana, Polkadot, EOS and all EVM compatible chains. Serving over 20 millions users from more than 200 countries and regions. It is a world-wide leading crypto wallet that trusted by global users.",
                    philosophy: {
                        title: "Our philosophy",
                        desc: "We insist on an open technology community, and we welcome all developers to build a more convenient, secure and richer blockchain world together",
                        ambition: "Ambition",
                        ambition_desc: "Make the blockchain happen everywhere",
                        value: "Value",
                        value_desc: "Let data return to users, make value belong to real owners",
                        attitude: "Attitude",
                        attitude_desc: "Open-minded, mutual collaboration"
                    },
                    milestones: {
                        title: "Milestones",
                        desc_2018_1: "TokenPocket Founded",
                        desc_2018_2: "Invested by Huobi, Hofan, Byte Capital",
                        desc_2019_1: "Released desktop wallet, supported TRON",
                        desc_2019_2: "Google Play download exceeded 1,000,000",
                        desc_2020_1: "HD wallet supported",
                        desc_2020_2: "Supported BSC and DeFi tendency",
                        desc_2020_3: "Supported Eth2.0 Staking",
                        desc_2021_1: "Incubated Transit",
                        desc_2021_2: "User base exceeded 20,000,000",
                        desc_2021_3: "Incubated KeyPal hardware wallet",
                        desc_2022_1: "Acquired dFox and rebranded to TokenPocket Extension",
                        January: "January",
                        February: "February",
                        March: "March",
                        April: "April",
                        May: "May",
                        June: "June",
                        July: "July",
                        August: "August",
                        September: "September",
                        October: "October",
                        November: "November",
                        December: "December"
                    },
                    contact_us: {
                        title: "Contact Us",
                        service: "Customer Service",
                        service_desc: "service@tokenpocket.pro",
                        bd: "Business Collaborations",
                        bd_desc: "bd@tokenpocket.pro",
                        developers: "Developers",
                        developers_desc: "Discord"
                    }
                },
                SEO: {
                    title: "TokenPocket - Your universal digital wallet | TP wallet - ETH wallet - BTC wallet - BSC wallet - HECO wallet - OKExChain wallet - Polkadot wallet - Kusama wallet - DeFi wallet - Layer 2 wallet - EOS wallet - TRX wallet - nostr",
                    description: "โทเค็นพ็อกเก็ต เป็นกระเป๋าเงินสกุลเงินดิจิทัลชั้นนำของโลก รองรับบล็อคเชนสาธารณะรวมถึง BTC, ETH, BSC, HECO, TRON, OKExChain, Polkadot, Kusama, EOS and เลเยอร์ 2.",
                    keywords: "โทเค็นพ็อกเก็ต,โทเค็นพ็อกเก็ต,กระเป๋าเงินTP,กระเป๋าเงินEthereum ,Bitcoin,EOS,IOST,COSMOS,heco,bsc,เลเยอร์2,DeFi,กระเป๋าเงิน,crypto,blockchain,web3,NFT,nostr"
                }
            }
        };

        function fe(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function be(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? fe(Object(source), !0).forEach((function (t) {
                    Object(r.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : fe(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        c.default.use(ge.a);
        var ke = function (e) {
            var t = e.app, n = e.store;
            t.i18n = new ge.a({
                locale: n.state.language,
                fallbackLocale: "en",
                messages: {
                    zh: be({}, Te.zh),
                    "zh-tw": be({}, Te.zhTw),
                    en: be({}, Te.en),
                    ko: be({}, Te.ko),
                    ru: be({}, Te.ru),
                    es: be({}, Te.es),
                    hi: be({}, Te.hi),
                    fil: be({}, Te.fil),
                    pt: be({}, Te.pt),
                    ja: be({}, Te.ja),
                    vi: be({}, Te.vi),
                    th: be({}, Te.th)
                }
            }), t.i18n.path = function (link) {
                return "/".concat(t.i18n.locale).concat(link)
            }
        }, ye = (n(115), function (e) {
            e.app.router.afterEach((function (e, t, n) {
                !function () {
                    var e = document.createElement("script");
                    e.src = "https://hm.baidu.com/hm.js?b46777860a3e1d6895b3546afafc8b0f";
                    var s = document.getElementsByTagName("script")[0];
                    s.parentNode.insertBefore(e, s)
                }(), function () {
                    var e = document.createElement("script"), t = window.location.protocol.split(":")[0];
                    e.src = "https" === t ? "https://zz.bdstatic.com/linksubmit/push.js" : "http://push.zhanzhang.baidu.com/push.js";
                    var s = document.getElementsByTagName("script")[0];
                    s.parentNode.insertBefore(e, s)
                }()
            }))
        }), Oe = n(217), _e = n.n(Oe);
        c.default.use(_e.a);
        var i, s, ve, Ae, a, Ce, xe = n(218), Pe = n.n(xe);
        c.default.use(Pe.a), i = window, s = document, ve = "script", Ae = "ga", i.GoogleAnalyticsObject = Ae, i.ga = i.ga || function () {
            (i.ga.q = i.ga.q || []).push(arguments)
        }, i.ga.l = 1 * new Date, a = s.createElement(ve), Ce = s.getElementsByTagName(ve)[0], a.async = 1, a.src = "https://www.google-analytics.com/analytics.js", Ce.parentNode.insertBefore(a, Ce), ga("create", "UA-153148934-1", "auto");
        var we = function (e) {
            var t = e.app.router;
            e.store;
            t.afterEach((function (e, t) {
                ga("set", "page", e.fullPath), ga("send", "pageview")
            }))
        };

        function Ee(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function Se(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? Ee(Object(source), !0).forEach((function (t) {
                    Object(r.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : Ee(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        c.default.component(h.a.name, h.a), c.default.component(f.a.name, Se(Se({}, f.a), {}, {
            render: function (e, t) {
                return f.a._warned || (f.a._warned = !0, console.warn("<no-ssr> has been deprecated and will be removed in Nuxt 3, please use <client-only> instead")), f.a.render(e, t)
            }
        })), c.default.component(P.name, P), c.default.component("NChild", P), c.default.component(H.name, H), Object.defineProperty(c.default.prototype, "$nuxt", {
            get: function () {
                var e = this.$root.$options.$nuxt;
                return e || "undefined" == typeof window ? e : window.$nuxt
            }, configurable: !0
        }), c.default.use(d.a, {
            keyName: "head",
            attribute: "data-n-head",
            ssrAttribute: "data-n-head-ssr",
            tagIDKeyName: "hid"
        });
        var De = {
            name: "page",
            mode: "out-in",
            appear: !1,
            appearClass: "appear",
            appearActiveClass: "appear-active",
            appearToClass: "appear-to"
        }, Ne = l.a.Store.prototype.registerModule;

        function Me(path, e) {
            var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                n = Array.isArray(path) ? !!path.reduce((function (e, path) {
                    return e && e[path]
                }), this.state) : path in this.state;
            return Ne.call(this, path, e, Se({preserveState: n}, t))
        }

        function Ie(e) {
            return Le.apply(this, arguments)
        }

        function Le() {
            return (Le = Object(o.a)(regeneratorRuntime.mark((function e(t) {
                var n, r, l, d, m, h, path, T, f = arguments;
                return regeneratorRuntime.wrap((function (e) {
                    for (; ;) switch (e.prev = e.next) {
                        case 0:
                            return T = function (e, t) {
                                if (!e) throw new Error("inject(key, value) has no key provided");
                                if (void 0 === t) throw new Error("inject('".concat(e, "', value) has no value provided"));
                                d[e = "$" + e] = t, d.context[e] || (d.context[e] = t), l[e] = d[e];
                                var n = "__nuxt_" + e + "_installed__";
                                c.default[n] || (c.default[n] = !0, c.default.use((function () {
                                    Object.prototype.hasOwnProperty.call(c.default.prototype, e) || Object.defineProperty(c.default.prototype, e, {
                                        get: function () {
                                            return this.$root.$options[e]
                                        }
                                    })
                                })))
                            }, n = f.length > 1 && void 0 !== f[1] ? f[1] : {}, e.next = 4, x(0, n);
                        case 4:
                            return r = e.sent, (l = te(t)).$router = r, l.registerModule = Me, d = Se({
                                head: {
                                    title: "TokenPocket - 你的通用数字钱包 | TP钱包 - EOS钱包 - ETH钱包 - BTC钱包 - 波卡钱包 - TRX钱包 - IOST钱包 - BOS钱包  - COSMOS钱包 - Binance钱包 - 墨客钱包 - 井通钱包 - ENU钱包",
                                    meta: [{charset: "utf-8"}, {
                                        name: "viewport",
                                        content: "width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
                                    }, {
                                        hid: "description",
                                        name: "description",
                                        content: "TokenPocket是全球最大的数字货币钱包，支持包括BTC、ETH、BSC、HECO、TRON、APTOS、OKExChain、Polkadot、Kusama、EOS等在内的所有主流公链及Layer 2，已为全球近千万用户提供可信赖的数字货币资产管理服务，也是当前DeFi用户必备的工具钱包。其中月度活跃用户数超100万，TokenPocket用户遍布全球两百多个国家和地区，海外用户占总用户数的60%以上。"
                                    }, {
                                        hid: "keywords",
                                        name: "keywords",
                                        content: "TokenPocket是全球最大的数字货币钱包，支持包括BTC、ETH、BSC、HECO、TRON、APTOS、APTOSOKExChain、Polkadot、Kusama、EOS等在内的所有主流公链及Layer 2，已为全球近千万用户提供可信赖的数字货币资产管理服务，也是当前DeFi用户必备的工具钱包。其中月度活跃用户数超100万，TokenPocket用户遍布全球两百多个国家和地区，海外用户占总用户数的60%以上。"
                                    }, {property: "og:type", content: "website"}, {
                                        hid: "og:title",
                                        property: "og:title",
                                        content: "TokenPocket - 你的通用数字钱包 | TP钱包 - EOS钱包 - ETH钱包 - BTC钱包 - TRX钱包 - IOST钱包 - BOS钱包  - COSMOS钱包 - Binance钱包 - 墨客钱包 - 井通钱包 - ENU钱包"
                                    }, {
                                        property: "og:url",
                                        content: "https://www.tokenpocket.pro"
                                    }, {
                                        hid: "og:site_name",
                                        property: "og:site_name",
                                        content: "TokenPocket - 你的通用数字钱包 | TP钱包 - EOS钱包 - ETH钱包 - BTC钱包 - TRX钱包 - IOST钱包 - BOS钱包  - COSMOS钱包 - Binance钱包 - 墨客钱包 - 井通钱包 - ENU钱包"
                                    }, {
                                        hid: "og:description",
                                        property: "og:description",
                                        content: "TokenPocket是全球最大的数字货币钱包，支持包括BTC、ETH、BSC、HECO、TRON、APTOS、OKExChain、Polkadot、Kusama、EOS等在内的所有主流公链及Layer 2，已为全球近千万用户提供可信赖的数字货币资产管理服务，也是当前DeFi用户必备的工具钱包。其中月度活跃用户数超100万，TokenPocket用户遍布全球两百多个国家和地区，海外用户占总用户数的60%以上。"
                                    }, {
                                        property: "og:locale", content: function () {
                                            return console.log(this), "zh-CN"
                                        }
                                    }, {
                                        hid: "twitter:card",
                                        property: "twitter:card",
                                        content: "summary"
                                    }, {
                                        hid: "twitter:title",
                                        property: "twitter:title",
                                        content: "TokenPocket - 你的通用数字钱包 | TP钱包 - EOS钱包 - ETH钱包 - BTC钱包 - TRX钱包 - IOST钱包 - BOS钱包  - COSMOS钱包 - Binance钱包 - 墨客钱包 - 井通钱包 - ENU钱包"
                                    }, {
                                        hid: "twitter:description",
                                        property: "twitter:description",
                                        content: "TokenPocket是全球最大的数字货币钱包，支持包括BTC、ETH、BSC、HECO、TRON、APTOS、OKExChain、Polkadot、Kusama、EOS等在内的所有主流公链及Layer 2，已为全球近千万用户提供可信赖的数字货币资产管理服务，也是当前DeFi用户必备的工具钱包。其中月度活跃用户数超100万，TokenPocket用户遍布全球两百多个国家和地区，海外用户占总用户数的60%以上。"
                                    }],
                                    link: [{
                                        rel: "icon",
                                        type: "image/x-icon",
                                        href: "/favicon.png"
                                    }, {rel: "stylesheet", href: "https://hk.tpstatic.net/bootstrap-grid.min.css"}],
                                    script: [],
                                    style: []
                                },
                                store: l,
                                router: r,
                                nuxt: {
                                    defaultTransition: De, transitions: [De], setTransitions: function (e) {
                                        return Array.isArray(e) || (e = [e]), e = e.map((function (e) {
                                            return e = e ? "string" == typeof e ? Object.assign({}, De, {name: e}) : Object.assign({}, De, e) : De
                                        })), this.$options.nuxt.transitions = e, e
                                    }, err: null, dateErr: null, error: function (e) {
                                        e = e || null, d.context._errored = Boolean(e), e = e ? Object(O.p)(e) : null;
                                        var n = d.nuxt;
                                        return this && (n = this.nuxt || this.$options.nuxt), n.dateErr = Date.now(), n.err = e, t && (t.nuxt.error = e), e
                                    }
                                }
                            }, Q), l.app = d, m = t ? t.next : function (e) {
                                return d.router.push(e)
                            }, t ? h = r.resolve(t.url).route : (path = Object(O.f)(r.options.base, r.options.mode), h = r.resolve(path).route), e.next = 14, Object(O.t)(d, {
                                store: l,
                                route: h,
                                next: m,
                                error: d.nuxt.error.bind(d),
                                payload: t ? t.payload : void 0,
                                req: t ? t.req : void 0,
                                res: t ? t.res : void 0,
                                beforeRenderFns: t ? t.beforeRenderFns : void 0,
                                ssrContext: t
                            });
                        case 14:
                            return T("config", n), window.__NUXT__ && window.__NUXT__.state && l.replaceState(window.__NUXT__.state), e.next = 20, ue(d.context, T);
                        case 20:
                            e.next = 23;
                            break;
                        case 23:
                            e.next = 26;
                            break;
                        case 26:
                            return e.next = 29, ke(d.context);
                        case 29:
                            return e.next = 32, ye(d.context);
                        case 32:
                            e.next = 35;
                            break;
                        case 35:
                            e.next = 38;
                            break;
                        case 38:
                            return e.next = 41, we(d.context);
                        case 41:
                            return e.next = 44, new Promise((function (e, t) {
                                var n = r.resolve(d.context.route.fullPath).route;
                                if (!n.matched.length) return e();
                                r.replace(n, e, (function (n) {
                                    if (!n._isRouter) return t(n);
                                    if (2 !== n.type) return e();
                                    var c = r.afterEach(function () {
                                        var t = Object(o.a)(regeneratorRuntime.mark((function t(n, o) {
                                            return regeneratorRuntime.wrap((function (t) {
                                                for (; ;) switch (t.prev = t.next) {
                                                    case 0:
                                                        return t.next = 3, Object(O.j)(n);
                                                    case 3:
                                                        d.context.route = t.sent, d.context.params = n.params || {}, d.context.query = n.query || {}, c(), e();
                                                    case 8:
                                                    case"end":
                                                        return t.stop()
                                                }
                                            }), t)
                                        })));
                                        return function (e, n) {
                                            return t.apply(this, arguments)
                                        }
                                    }())
                                }))
                            }));
                        case 44:
                            return e.abrupt("return", {store: l, app: d, router: r});
                        case 45:
                        case"end":
                            return e.stop()
                    }
                }), e)
            })))).apply(this, arguments)
        }
    }, 303: function (e, t, n) {
        "use strict";
        n(192)
    }, 304: function (e, t, n) {
        "use strict";
        n(193)
    }, 36: function (e, t, n) {
        "use strict";
        n.d(t, "g", (function () {
            return r
        })), n.d(t, "f", (function () {
            return c
        })), n.d(t, "c", (function () {
            return l
        })), n.d(t, "a", (function () {
            return d
        })), n.d(t, "d", (function () {
            return m
        })), n.d(t, "e", (function () {
            return h
        })), n.d(t, "b", (function () {
            return T
        }));
        var o = "https://betaserver.mytokenpocket.vip", r = "".concat(o, "/v1/news/list"),
            c = "".concat(o, "/v1/news/"), l = "".concat(o, "/v1/banner/list"), d = "".concat(o, "/v1/activity/list"),
            m = "".concat(o, "/v1/category/list"), h = "".concat(o, "/v1/application/list"),
            T = "".concat(o, "/v1/ad/list")
    }, 59: function (e, t, n) {
        "use strict";
        n(13), n(9), n(11), n(18), n(19);
        var o = n(3), r = (n(34), n(62)), c = n(10), l = n(180), d = n(99);

        function m(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function h(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? m(Object(source), !0).forEach((function (t) {
                    Object(o.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : m(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        t.a = {
            name: "HeaderLayout",
            mixins: [l.a, d.a],
            components: {normalNav: r.a},
            props: {
                navLogo: {type: String, default: n(181)},
                navTitleColor: {type: String, default: "#fff"},
                navIconColor: {type: String, default: "#fff"},
                arrowClass: {type: String, default: "icon-down-fff"},
                langClass: {type: String, default: "icon-earth"}
            },
            data: function () {
                return {black: "#000", navIndex: "", menuState: !1, clientWidth: 0, canRun: !0, eventListen: null}
            },
            computed: h(h({}, Object(c.b)(["language"])), {}, {
                titleLang: function () {
                    switch (this.language) {
                        case"zh":
                            return "中文简体";
                        case"zh-tw":
                            return "中文繁体";
                        case"en":
                            return "English";
                        case"ko":
                            return "한국어";
                        case"ru":
                            return "Русский";
                        case"es":
                            return "Español";
                        case"hi":
                            return "हिन्दी";
                        case"fil":
                            return "Filipino";
                        case"pt":
                            return "Português";
                        case"ja":
                            return "日本語";
                        case"vi":
                            return "Tiếng Việt";
                        case"th":
                            return "ภาษาไทย";
                        default:
                            return "中文"
                    }
                }, navList: function () {
                    return [{
                        local: !0,
                        title: this.$t("NAVIGATION.product.title"),
                        translateX: "translateX(-30%)",
                        children: [{
                            width: "224px",
                            class: "nav-icon-1",
                            desc: this.$t("NAVIGATION.product.selfCustodyWalletDesc"),
                            line: !0,
                            local: !0,
                            title: this.$t("NAVIGATION.product.selfCustodyWallet"),
                            url: this.$i18n.path("/")
                        }, {
                            width: "224px",
                            class: "nav-icon-2",
                            desc: this.$t("NAVIGATION.product.hardwareWalletDesc"),
                            line: !0,
                            title: this.$t("NAVIGATION.product.hardwareWallet"),
                            url: this.keypalUrl
                        }, {
                            width: "224px",
                            class: "nav-icon-3",
                            desc: this.$t("NAVIGATION.product.extensionWalletDesc"),
                            line: !0,
                            title: this.$t("NAVIGATION.product.extensionWallet"),
                            url: this.extensionUrl
                        }, {
                            width: "224px",
                            class: "nav-icon-4",
                            desc: this.$t("NAVIGATION.product.transitDesc"),
                            line: !0,
                            title: this.$t("NAVIGATION.product.transit"),
                            url: this.transitFinanceUrl
                        }, {
                            width: "224px",
                            class: "nav-icon-5",
                            desc: this.$t("NAVIGATION.product.fiveDegreesDesc"),
                            line: !1,
                            title: this.$t("NAVIGATION.product.fiveDegrees"),
                            url: this.fiveDegreesUrl
                        }, {
                            width: "224px",
                            class: "nav-icon-13",
                            desc: this.$t("NAVIGATION.product.buyCryptoDesc"),
                            line: !1,
                            title: this.$t("NAVIGATION.product.buyCrypto"),
                            url: "https://openc.pro/widget-page/?widgetId=UjcyR3hQVlk"
                        }]
                    }, {
                        title: this.$t("NAVIGATION.collaborations.title"),
                        leftDis: !0,
                        children: [{
                            class: "nav-icon-6",
                            desc: !1,
                            line: !0,
                            local: !0,
                            title: this.$t("COMMON.LAYOUT.subDApp"),
                            url: this.$i18n.path("/submit/dapp")
                        }, {
                            class: "nav-icon-7",
                            desc: !1,
                            line: !0,
                            local: !0,
                            title: this.$t("COMMON.LAYOUT.subToken"),
                            url: this.$i18n.path("/submit/token")
                        }, {
                            class: "nav-icon-8",
                            desc: !1,
                            line: !0,
                            local: !0,
                            title: this.$t("COMMON.LAYOUT.subNFT"),
                            url: this.$i18n.path("/submit/nft")
                        }, {
                            class: "nav-icon-9",
                            desc: !1,
                            line: !1,
                            title: this.$t("COMMON.LAYOUT.subChain"),
                            url: "https://github.com/TP-Lab/networklist-org"
                        }]
                    }, {
                        local: !0,
                        title: this.$t("NAVIGATION.community.title"),
                        leftDis: !0,
                        children: [{
                            class: "nav-icon-10",
                            line: !0,
                            title: this.$t("NAVIGATION.community.developers"),
                            url: this.developerUrl
                        }, {
                            class: "nav-icon-11",
                            line: !0,
                            local: !0,
                            title: this.$t("NAVIGATION.community.recruiting"),
                            url: this.$i18n.path("/recruiting")
                        }]
                    }, {
                        title: this.$t("NAVIGATION.helpCenter.title"),
                        url: this.helpUrl
                    }, {title: ""}, {
                        title: this.titleLang,
                        lang: !0,
                        class: "language-changes",
                        children: [{title: "简体中文", lang: "zh", link: "/zh", class: "locale-zh"}, {
                            title: "繁体中文",
                            lang: "zh-tw",
                            link: "/zh-tw",
                            class: "locale-zh-tw"
                        }, {title: "English", lang: "en", link: "/en", class: "locale-en"}, {
                            title: "한국어",
                            lang: "ko",
                            link: "/ko",
                            class: "locale-ko"
                        }, {title: "Русский", lang: "ru", link: "/ru", class: "locale-ru"}, {
                            title: "Español",
                            lang: "es",
                            link: "/es",
                            class: "locale-es"
                        }, {title: "हिन्दी", lang: "hi", link: "/hi", class: "locale-hi"}, {
                            title: "Filipino",
                            lang: "fil",
                            link: "/fil",
                            class: "locale-fil"
                        }, {title: "Português", lang: "pt", link: "/pt", class: "locale-pt"}, {
                            title: "日本語",
                            lang: "ja",
                            link: "/ja",
                            class: "locale-ja"
                        }, {title: "Tiếng Việt", lang: "vi", link: "/vi", class: "locale-vi"}, {
                            title: "ภาษาไทย",
                            lang: "th",
                            link: "/th",
                            class: "locale-th"
                        }]
                    }]
                }
            }),
            watch: {
                clientWidth: function () {
                    this.navIndex = ""
                }
            },
            mounted: function () {
                this.clientWidth = document.body.clientWidth, this.navState(), this.windowChange()
            },
            beforeDestroy: function () {
                document.removeEventListener("click", this.eventListen)
            },
            methods: {
                changeMenuState: function () {
                    this.menuState = !this.menuState, this.navIndex = ""
                }, navClass: function (e, t) {
                    var n = -1 !== ["/", "/en", "/zh", "/ko", "/zh-tw"].indexOf(this.$route.fullPath);
                    return n && !e.lang ? "icon-down-fff" : n || e.lang ? n && e.lang ? "icon-earth" : !n && e.lang ? "icon-earth-mini" : void 0 : "icon-down-"
                }, navState: function (e) {
                    var t = this;
                    document.addEventListener("click", (function (e) {
                        t.clientWidth > 768 && t.$refs.navMain && !t.$refs.navMain.contains(e.target) && (t.navIndex = "")
                    }), !1)
                }, navGo: function (e, t, n) {
                    if (n.preventDefault(), e.children && (t === this.navIndex ? this.navIndex = "" : this.navIndex = t), e.url && !e.local) return window.open(e.url);
                    e.url && e.local && this.$router.push(e.url)
                }, navEnter: function (e, t, n) {
                    if (n.preventDefault(), e.children && (t === this.navIndex ? this.navIndex = "" : this.navIndex = t), e.url && !e.local && e.children) return window.open(e.url);
                    e.url && e.local && e.children && this.$router.push(e.url)
                }, navLeave: function (e, t, n) {
                    n.preventDefault(), e.children && (t === this.navIndex ? this.navIndex = "" : this.navIndex = t), this.navIndex = ""
                }, navChildrenGo: function (e, t) {
                    if (t && t.preventDefault(), e.url && !e.local) return window.open(e.url);
                    if (e.url && e.local && !e.lang) return this.$router.push(e.url);
                    if (e.lang) {
                        if (e.lang === this.langChange) return !1;
                        this.$route.fullPath.replace("".concat(this.language), e.lang), "/" !== this.$route.fullPath.replace("".concat(this.language), e.lang) && this.$router.replace(this.$route.fullPath.replace("".concat(this.language), e.lang)), this.langChange(e.lang)
                    }
                    this.navIndex = ""
                }, langChange: function (e) {
                    this.$store.commit("SET_LANGUAGE", e), this.$i18n.locale = e, this.navIndex = "", this.menuState = !1
                }, windowChange: function () {
                    var e = this;
                    window.addEventListener("resize", (function (t) {
                        e.clientWidth = t.target.screen.width, e.$store.commit("SET_CLIENT_WIDTH", e.clientWidth)
                    }))
                }
            }
        }
    }, 60: function (e, t, n) {
        "use strict";
        var o = n(62), r = n(100), c = n(101), l = {
            methods: {
                onLink: function () {
                    window.location.href = "https://help.tpwallet.io/cn/TokenPocket-product-policy-adjustment-instructions"
                }
            }
        }, d = (n(282), n(2)), m = Object(d.a)(l, (function () {
            var e = this, t = e.$createElement, o = e._self._c || t;
            return o("div", {staticClass: "tips"}, [o("div", {staticClass: "text tips-text"}, [e._v("根据用户属地相关的监管政策，TokenPocket 已限制中国境内用户访问、使用个别功能")]), e._v(" "), o("div", {
                staticClass: "tips-button",
                on: {click: e.onLink}
            }, [o("span", [e._v("了解更多")]), e._v(" "), o("img", {attrs: {src: n(281)}})])])
        }), [], !1, null, "bae973e8", null).exports, h = {
            components: {Warn: c.a, NormalNav: o.a, MiniNav: r.a, Tips: m},
            props: {
                navLogo: {type: String, default: n(181)},
                navTitleColor: {type: String, default: "#fff"},
                arrowClass: {type: String, default: "icon-down-fff"},
                langClass: {type: String, default: "icon-earth"}
            },
            data: function () {
                return {scroll: 0}
            },
            mounted: function () {
                window.addEventListener("scroll", this.handleScroll)
            },
            methods: {
                handleScroll: function () {
                    this.scroll = document.documentElement.scrollTop || document.body.scrollTop
                }
            },
            beforeDestroy: function () {
                window.removeEventListener("scroll", this.handleScroll)
            }
        }, T = (n(283), Object(d.a)(h, (function () {
            var e = this, t = e.$createElement, n = e._self._c || t;
            return n("div", {
                staticClass: "HeaderLayout",
                class: {scrollBg: 0 !== e.scroll}
            }, ["zh" === e.$i18n.locale ? n("Tips") : e._e(), e._v(" "), n("normal-nav", {
                staticClass: "normal-header",
                attrs: {
                    "arrow-class": e.arrowClass,
                    "lang-class": e.langClass,
                    "nav-title-color": e.navTitleColor,
                    "nav-logo": e.navLogo
                }
            }), e._v(" "), n("mini-nav", {staticClass: "mini-header"})], 1)
        }), [], !1, null, "253a8e43", null));
        t.a = T.exports
    }, 61: function (e, t, n) {
        "use strict";
        n(13), n(9), n(11), n(18), n(19);
        var o = n(3), r = (n(149), n(10)), c = n(147), l = n(99);

        function d(object, e) {
            var t = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                e && (n = n.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(object, e).enumerable
                }))), t.push.apply(t, n)
            }
            return t
        }

        function m(e) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? d(Object(source), !0).forEach((function (t) {
                    Object(o.a)(e, t, source[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(source)) : d(Object(source)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(source, t))
                }))
            }
            return e
        }

        var h = {
            name: "FooterLayout", components: {Modal: n(212).a}, mixins: [c.a, l.a], data: function () {
                return {email: "", show: !1, url: ""}
            }, computed: m(m({}, Object(r.b)(["language"])), {}, {
                followList: function () {
                    return [{url: "https://twitter.com/TokenPocket_TP"}, {
                        isTelegram: !0,
                        url: "zh" === this.language || "zh-tw" === this.language ? "https://t.me/tokenPocket_cn" : "ko" === this.language ? "https://t.me/tokenpocket_kor" : "https://t.me/tokenpocket_en"
                    }, {url: "https://fans.tokenpocket.pro/"}, {url: "https://www.youtube.com/channel/UCudaS5hcbqUaMtOGHmQ2e0A"}, {url: "https://discord.com/invite/NKPM8TXFQk"}, {url: "https://github.com/TP-Lab"}, {url: "https://tokenpocket-gm.medium.com/"}]
                }, isZH: function () {
                    return "zh" === this.language
                }, privacyPolicy: function () {
                    return this.isZH ? "/privacy-zh/index.html" : "/privacy-en/index.html"
                }, terms: function () {
                    return this.isZH ? "/terms-zh/index.html" : "/terms-en/index.html"
                }, copyright: function () {
                    return this.isZH ? "Copyright © 2018-2022 TokenPocket" : "Copyright © 2022 Singapore TokenPocket Foundation Ltd. All rights reserved."
                }, footerList: function () {
                    var e = this;
                    return [{
                        title: this.$t("COMMON.LAYOUT.features"),
                        data: [{
                            title: "Transit Swap",
                            url: "https://swap.transit.finance/?from=tp#/"
                        }, {
                            title: this.$t("COMMON.LAYOUT.buyCrypto"),
                            url: "https://openc.pro/widget-page/?widgetId=UjcyR3hQVlk"
                        }, {
                            title: this.$t("COMMON.LAYOUT.mobileWallet"),
                            curPage: !0,
                            url: this.$i18n.path("/")
                        }, {
                            title: this.$t("COMMON.LAYOUT.hardwareWallet"),
                            url: this.keypalUrl
                        }, {title: this.$t("COMMON.LAYOUT.extensionWallet"), url: this.extensionUrl}, {
                            local: !0,
                            title: this.$t("COMMON.LAYOUT.desktop"),
                            url: this.$i18n.path("/download/pc")
                        }, {
                            title: this.$t("COMMON.LAYOUT.fiveDegrees"),
                            url: this.fiveDegreesUrl
                        }, {
                            title: this.$t("COMMON.LAYOUT.versionVerification"),
                            url: this.verifyVersionUrl
                        }, {
                            title: this.$t("COMMON.LAYOUT.approvalDetector"),
                            url: this.approvalUrl
                        }, {
                            title: this.$t("COMMON.LAYOUT.tokenSecurity"),
                            url: this.tokenSecurityUrl
                        }, {
                            title: this.$t("COMMON.LAYOUT.keyGenerator"),
                            url: this.keyUrl
                        }, {title: this.$t("COMMON.BATCH_SENDER"), url: this.batchSenderUrl}, {
                            title: "REX",
                            url: this.rexUrl
                        }]
                    }, {
                        title: this.$t("COMMON.LAYOUT.information"),
                        data: [{
                            title: this.$t("COMMON.LAYOUT.blockchainGuide"),
                            url: this.isZH ? "https://github.tokenpocket.pro/BlockchainGuideSeries/#/" : "https://github.tokenpocket.pro/BlockchainGuideSeries-EN/#/"
                        }, {
                            title: this.$t("COMMON.LAYOUT.tronWallet"),
                            url: this.isZH ? "https://github.tokenpocket.pro/BlockchainGuide-TRON/#/" : "https://github.tokenpocket.pro/BlockchainGuide-TRON-EN/#/"
                        }, {
                            title: this.$t("COMMON.LAYOUT.iostWallet"),
                            url: this.isZH ? "https://github.tokenpocket.pro/BlockchainGuide-IOST/#/" : "https://github.tokenpocket.pro/BlockchainGuide-IOST-EN/#/"
                        }, {local: !0, title: this.$t("COMMON.LAYOUT.tpMan"), url: this.$i18n.path("/recruiting")}]
                    }, {
                        title: this.$t("COMMON.LAYOUT.developers"),
                        data: [{
                            title: this.$t("COMMON.LAYOUT.github"),
                            url: "https://github.com/TP-Lab"
                        }, {title: this.$t("COMMON.LAYOUT.devCenter"), url: this.developerUrl}, {
                            local: !0,
                            title: this.$t("COMMON.LAYOUT.subDApp"),
                            url: this.$i18n.path("/project/dapp")
                        }, {
                            local: !0,
                            title: this.$t("COMMON.LAYOUT.subToken"),
                            url: this.$i18n.path("/project/token")
                        }, {local: !0, title: this.$t("COMMON.LAYOUT.subNFT"), url: this.$i18n.path("/project/nft")}]
                    }, {
                        title: this.$t("COMMON.LAYOUT.company"),
                        data: [{
                            local: !0,
                            title: this.$t("COMMON.LAYOUT.about"),
                            url: this.$i18n.path("/about")
                        }, {
                            title: this.$t("COMMON.LAYOUT.careers"),
                            url: this.joinUsUrl
                        }, {
                            title: this.$t("COMMON.LAYOUT.pressKit"),
                            url: "https://hilarious-eucalyptus-a2f.notion.site/TokenPocket-Brand-Resources-ab6e6019d20342eea025ec62955084fc"
                        }, {
                            title: this.$t("COMMON.LAYOUT.swagShop"),
                            url: this.isZH ? "https://shop95838799.m.youzan.com/v2/showcase/homepage?alias=sptfzUCg0j" : "https://keypalwallet.mystrikingly.com/"
                        }]
                    }, {
                        title: this.$t("COMMON.LAYOUT.support"),
                        data: [{
                            title: e.$t("COMMON.LAYOUT.helpCenter"),
                            url: e.helpUrl
                        }, {title: e.$t("COMMON.LAYOUT.contactUs"), url: e.contactUsUrl}]
                    }, {
                        title: this.$t("COMMON.LAYOUT.legal"),
                        data: [{
                            title: this.$t("COMMON.LAYOUT.privacyPolicy"),
                            url: this.isZH ? "/privacy-zh/index.html" : "/privacy-en/index.html"
                        }, {
                            title: this.$t("COMMON.LAYOUT.terms"),
                            url: this.isZH ? "/terms-zh/index.html" : "/terms-en/index.html"
                        }]
                    }]
                }
            }), methods: {
                openFollow: function (e) {
                    e.isTelegram ? (this.show = !0, this.url = e.url) : window.open(e.url)
                }, close: function () {
                    this.show = !1
                }, footerUrl: function (e, t) {
                    if (t.preventDefault(), e.scrollTop) return document.body.scrollTop = document.documentElement.scrollTop = 0, !1;
                    e.curPage ? location.reload() : e.local ? this.localLink(e.url, t) : window.open(e.url)
                }, subscribeEmail: function () {
                    var e = this;
                    if (!new RegExp(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/).test(this.email)) {
                        var t = "zh" === this.language ? "请输入正确的邮箱地址" : "Error Email!";
                        return this.$message.error(t), !1
                    }
                    var n = window.origin || window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":" + window.location.port : "");
                    this.$axios.post("".concat(n, "/api/tokenPocket/subscribe"), {email: this.email}).then((function (t) {
                        if (0 === t.data.result) {
                            var n = "zh" === e.language ? "订阅成功" : "Subscribe sucess";
                            e.email = "", e.$message.success(n)
                        } else e.$message.error(t.data.message)
                    })).catch((function (t) {
                        e.$message.error(t)
                    }))
                }
            }
        }, T = (n(273), n(2)), component = Object(T.a)(h, (function () {
            var e = this, t = e.$createElement, o = e._self._c || t;
            return o("div", {staticClass: "FooterLayout"}, [o("footer", {staticClass: "content d-flex jc-between"}, [o("div", {staticClass: "follow-wrap"}, [o("img", {
                staticClass: "logo",
                attrs: {src: n(269)}
            }), e._v(" "), o("div", {staticClass: "footer-follows d-flex"}, [e._l(e.followList, (function (t, n) {
                return o("div", {
                    key: n,
                    staticClass: "footer-follow",
                    class: ["footer-follow-" + (n + 1)],
                    on: {
                        click: function (n) {
                            return e.openFollow(t)
                        }
                    }
                })
            })), e._v(" "), o("a", {
                staticClass: "footer-follow footer-follow-8",
                attrs: {href: "mailto:service@tokenpocket.pro", target: "_blank"}
            })], 2), e._v(" "), o("div", {staticClass: "copyright"}, [e._v("© TokenPocket Foundation Ltd.")])]), e._v(" "), o("div", {staticClass: "footer-wrap flex-1 d-flex flex-wrap jc-between"}, e._l(e.footerList, (function (t, n) {
                return o("div", {
                    key: n,
                    staticClass: "footer-list",
                    class: {"lang-wrap": "ru" === e.$i18n.locale || "es" === e.$i18n.locale || "fil" === e.$i18n.locale || "ja" === e.$i18n.locale || "vi" === e.$i18n.locale || "th" === e.$i18n.locale || "pt" === e.$i18n.locale}
                }, [o("div", {staticClass: "title"}, [e._v(e._s(t.title))]), e._v(" "), o("div", {staticClass: "footer-link-wrap"}, e._l(t.data, (function (data, t) {
                    return o("div", {
                        key: t,
                        staticClass: "footer-link",
                        class: {width0: "Transit Swap" === data.title && "zh" === e.$i18n.locale}
                    }, ["Transit Swap" !== data.title || "zh" !== e.$i18n.locale ? o("a", {
                        staticClass: "pointer ft-14",
                        attrs: {rel: "nofollow", href: data.url, target: data.local ? "_self" : "_blank"},
                        on: {
                            click: function (t) {
                                return e.footerUrl(data, t)
                            }
                        }
                    }, [e._v(e._s(data.title))]) : e._e()])
                })), 0)])
            })), 0)]), e._v(" "), e.show ? o("Modal", {attrs: {url: e.url}, on: {close: e.close}}) : e._e()], 1)
        }), [], !1, null, "c808e9cc", null);
        t.a = component.exports
    }, 62: function (e, t, n) {
        "use strict";
        var o = {name: "normalNav", mixins: [n(59).a]}, r = (n(275), n(2)), component = Object(r.a)(o, (function () {
            var e = this, t = e.$createElement, o = e._self._c || t;
            return o("div", {
                staticClass: "normal-nav container",
                staticStyle: {margintop: "20px"}
            }, [o("nav", {staticClass: "navbar-wrap row"}, [o("div", {staticClass: "navbar-logo"}, [o("img", {
                staticClass: "logo pointer",
                attrs: {src: e.navLogo, alt: e.$t("COMMON.LAYOUT.defiWallet")},
                on: {
                    click: function (t) {
                        return e.indexGo("/")
                    }
                }
            })]), e._v(" "), o("div", {
                ref: "navMain",
                staticClass: "navbar-tab-list col-xl-10 col-md-9"
            }, e._l(e.navList, (function (t, r) {
                return o("a", {
                    key: r,
                    staticClass: "nav-title",
                    class: {null: !t.title, "nav-language": t.lang},
                    attrs: {href: t.local && t.url ? t.url : "javascript:void(0)"},
                    on: {
                        click: function (n) {
                            return n.stopPropagation(), e.navGo(t, r, n)
                        }, mouseenter: function (n) {
                            return n.stopPropagation(), e.navEnter(t, r, n)
                        }, mouseleave: function (n) {
                            return e.navLeave(t, r, n)
                        }
                    }
                }, [o("div", {staticClass: "pointer title language-content"}, [r === e.navList.length - 1 ? o("img", {
                    staticClass: "language-img",
                    attrs: {src: n(274)}
                }) : e._e(), e._v(" "), o("span", {
                    staticClass: "title-left",
                    class: {"language-title": r === e.navList.length - 1}
                }, [e._v(e._s(t.title))]), e._v(" "), o("span", {staticClass: "title-right text-right"}, [t.children && !t.lang ? o("i", {class: [t.lang ? "" : e.arrowClass, t.lang ? e.langClass : ""]}) : e._e()])]), e._v(" "), o("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: t.children && e.navIndex === r,
                        expression: "item.children && navIndex === index"
                    }],
                    staticClass: "nav-children-wrap",
                    class: {products: 0 === r, language: 6 === r},
                    style: {width: t.width, transform: t.translateX}
                }, e._l(t.children, (function (n, r) {
                    return o("a", {
                        key: r,
                        staticClass: "d-flex",
                        attrs: {
                            href: !n.lang && n.url ? n.url : "javascript:void(0)",
                            target: n.local || n.lang ? "_self" : "_blank"
                        },
                        on: {
                            click: function (t) {
                                return t.stopPropagation(), e.navChildrenGo(n, t)
                            }
                        }
                    }, [o("div", {staticClass: "nav-children"}, [o("div", {class: [n.class]}), e._v(" "), o("div", {
                        staticClass: "detail",
                        class: {lang: n.lang, leftDis: t.leftDis}
                    }, [o("div", {staticClass: "child-title"}, [e._v(e._s(n.title))]), e._v(" "), n.desc ? o("div", {
                        staticClass: "child-title desc",
                        style: {width: n.width}
                    }, [e._v("\n                  " + e._s(n.desc) + "\n                ")]) : e._e()])])])
                })), 0)])
            })), 0)])])
        }), [], !1, null, "d7203c54", null);
        t.a = component.exports
    }, 76: function (e, t, n) {
        "use strict";
        var o = {name: "ContainerLayout"}, r = (n(303), n(2)), component = Object(r.a)(o, (function () {
            var e = this, t = e.$createElement;
            return (e._self._c || t)("div", {staticClass: "container"}, [e._t("default")], 2)
        }), [], !1, null, "510569d4", null);
        t.a = component.exports
    }, 99: function (e, t, n) {
        "use strict";
        t.a = {
            computed: {
                isTokenPocketPro: function () {
                    return "tokenpocket.pro" === window.location.hostname || "www.tokenpocket.pro" === window.location.hostname
                }, isZH: function () {
                    return "zh" === this.$i18n.locale
                }, homeUrl: function () {
                    return this.isTokenPocketPro ? "https://tokenpocket.pro/" : "https://tpwallet.io/"
                }, extensionUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://extension.tokenpocket.pro/?locale=zh" : "https://extension.tokenpocket.pro/?locale=en" : this.isZH ? "https://extension.tpwallet.io/?locale=zh" : "https://extension.tpwallet.io/?locale=en"
                }, dappUrl: function () {
                    return this.isTokenPocketPro ? "https://tokenpocket.pro/".concat(this.$i18n.locale, "/submit/dapp") : "https://tpwallet.io/".concat(this.$i18n.locale, "/submit/dapp")
                }, tokenUrl: function () {
                    return this.isTokenPocketPro ? "https://tokenpocket.pro/".concat(this.$i18n.locale, "/submit/token") : "https://tpwallet.io/".concat(this.$i18n.locale, "/submit/token")
                }, nftUrl: function () {
                    return this.isTokenPocketPro ? "https://tokenpocket.pro/".concat(this.$i18n.locale, "/submit/nft") : "https://tpwallet.io/".concat(this.$i18n.locale, "/submit/nft")
                }, recruitingUrl: function () {
                    return this.isTokenPocketPro ? "https://tokenpocket.pro/".concat(this.$i18n.locale, "/recruiting") : "https://tpwallet.io/".concat(this.$i18n.locale, "/recruiting")
                }, aboutUrl: function () {
                    return this.isTokenPocketPro ? "https://tokenpocket.pro/".concat(this.$i18n.locale, "/about") : "https://tpwallet.io/".concat(this.$i18n.locale, "/about")
                }, developerUrl: function () {
                    return this.isZH ? "https://help.tokenpocket.pro/developer-cn/" : "https://help.tokenpocket.pro/developer-en/"
                }, helpUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://help.tokenpocket.pro/cn/" : "https://help.tokenpocket.pro/en/" : this.isZH ? "https://help.tpwallet.io/cn/" : "https://help.tpwallet.io/en/"
                }, desktopUrl: function () {
                    return this.isTokenPocketPro ? "https://tokenpocket.pro/".concat(this.$i18n.locale, "/download/pc") : "https://tpwallet.io/".concat(this.$i18n.locale, "/download/pc")
                }, approvalUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://approval.tokenpocket.pro/?locale=zh" : "https://approval.tokenpocket.pro/?locale=en" : this.isZH ? "https://approval.tptool.pro/?locale=zh" : "https://approval.tptool.pro/?locale=en"
                }, batchSenderUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://batchsender.tokenpocket.pro/?locale=zh" : "https://batchsender.tokenpocket.pro/?locale=en" : this.isZH ? "https://batchsender.tptool.pro/?locale=zh" : "https://batchsender.tptool.pro/?locale=en"
                }, tokenSecurityUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://tokensecurity.tokenpocket.pro/?locale=zh" : "https://tokensecurity.tokenpocket.pro/?locale=en" : this.isZH ? "https://tokensecurity.tptool.pro/?locale=zh" : "https://tokensecurity.tptool.pro/?locale=en"
                }, contactUsUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://help.tokenpocket.pro/cn/contact-us/contact-methods" : "https://help.tokenpocket.pro/en/contact-us/contact-methods" : this.isZH ? "https://help.tpwallet.io/cn/contact-us/contact-methods" : "https://help.tpwallet.io/en/contact-us/contact-methods"
                }, rexUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://rex.tokenpocket.pro/?locale=zh" : "https://rex.tokenpocket.pro/?locale=en" : this.isZH ? "https://rex.tptool.pro/?locale=zh" : "https://rex.tptool.pro/?locale=en"
                }, joinUsUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://help.tpwallet.io/cn/contact-us/joinus" : "https://help.tpwallet.io/en/contact-us/Joinus" : this.isZH ? "https://help.tokenpocket.pro/cn/contact-us/joinus" : "https://help.tokenpocket.pro/en/contact-us/Joinus"
                }, stakeVaultUrl: function () {
                    return this.isTokenPocketPro ? this.isZH ? "https://dapp.tokenpocket.pro/StakeVault/index.html?locale=zh#/" : "https://dapp.tokenpocket.pro/StakeVault/index.html?locale=en#/" : this.isZH ? "https://dapp.tptool.pro/StakeVault/index.html?locale=zh#/" : "https://dapp.tptool.pro/StakeVault/index.html?locale=en#/"
                }, verifyVersionUrl: function () {
                    return this.isTokenPocketPro ? "https://verify.tokenpocket.pro/?locale=".concat(this.$i18n.locale, "#/") : "https://verify.tpwallet.io/?locale=".concat(this.$i18n.locale, "#/")
                }, fiveDegreesUrl: function () {
                    return this.isZH ? "https://www.5degrees.io/?locale=zh#/" : "https://www.5degrees.io/?locale=en#/"
                }, keypalUrl: function () {
                    return this.isZH ? "https://www.keypal.pro/?locale=zh#/" : "https://www.keypal.pro/?locale=en#/"
                }, transitFinanceUrl: function () {
                    return this.isZH ? "https://transit.finance/zh/#/" : "https://transit.finance/en/#/"
                }, keyUrl: function () {
                    return this.isTokenPocketPro ? "https://key.tokenpocket.pro/?locale=".concat(this.$i18n.locale, "#/") : "https://key.tptool.pro/?locale=".concat(this.$i18n.locale, "#/")
                }
            }
        }
    }
}, [[224, 20, 3, 21]]]);