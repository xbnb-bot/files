(window.webpackJsonp = window.webpackJsonp || []).push([[0], {
    366: function (t, e, n) {
        "use strict";
        n(381);
        e.a = {
            data: function () {
                return {intersectionObserver: null}
            }, mounted: function () {
                var t = this;
                this.$nextTick((function () {
                    t.initIntersectionObserver()
                }))
            }, beforeDestroy: function () {
                this.intersectionObserver.disconnect()
            }, methods: {
                initIntersectionObserver: function () {
                    var t = this;
                    this.intersectionObserver = new IntersectionObserver((function (t) {
                        t.forEach((function (t) {
                            t.intersectionRatio >= .3 ? t.target.classList.add("enter-animation") : 0 === t.intersectionRatio && t.target.classList.remove("enter-animation")
                        }))
                    }), {threshold: [0, .3]}), this.$refs && Object.values(this.$refs).forEach((function (e) {
                        Array.isArray(e) || "milestones-mobile-list" === e._prevClass || t.intersectionObserver.observe(e)
                    }))
                }
            }
        }
    }, 368: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAMAAAC7IEhfAAAAhFBMVEUAAACDg4icnqKbnqKTlZmIi5CLjI+KjI6IiIxxcXFSUlKbnqKbnaKbnaKam6GXmZ6Vl5uUl5yWmJyTlZqMjZGOj5OJio+cnaGZnKCZm6CYmp+YmZ6TlJqTlZmXmJ2Ymp6Rk5eLjZKMjJKLkZObnqOUlZqTlJqXm56Ym519fYKeoKWcnqMLgRUyAAAAKnRSTlMAG+/1ck4wKBINBvrp5OLJuJSAd1hAN/Ha0s/Dp6OchnxlVCPFsK6Mii3dkjOXAAAAq0lEQVQ4y8XSWRKCMBRE0QQCishonBVx1sf+96fNBl5/KPT3raTqJOa/821MdU4kjJjwJiIBc2Yj3+VWD22Oskj0Mg5QHoy+S4ryRJQLwRxRvhCmBNLsISTSdEcjZSzSikby3e+RnjTSvUeasEgNEW4RVvrVJbq5fnWFLlxyPN1Z/5U9eK0/4RrdUe2uGbp9wsFs7OAwLQnjR4IxJQODFQwMVlMwWOTeZrh9AHauHYvYzQKSAAAAAElFTkSuQmCC"
    }, 369: function (t, e, n) {
    }, 370: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAMAAAC7IEhfAAAAjVBMVEUAAAAofvspfvskZtAofvone/Une/Yldu4kceAibt4YbcsWPo8nfvkoffknfPcmeO4nePAmevEkc+Mkbt4kbdogc+UfcOMofvsoffYmeO8md+0md+0ofPQodekjct4mZtMVVaone/QnevQme/EnefIoevQnfPQkcuUldOsleu8ldOMmd+8iZswkc9spgP6SLLgPAAAALnRSTlMA/O8b9dHId1ZODwbp5OKilIBAODEnIPHauq+nhnNlFAzDw7WYjIp/dG9aLy0qEAblCQAAAKVJREFUOMvV0lkSgjAQhOGQYBRUFkVxF/d97n88bS8wzYNS9PNXlao/Y367++VBuatIGDHQi4gtCJjKZ4nToUsgfazLwkIujb5eALkiZFewNSHPgAERqb8QMlLcYSNNh2ykcdlkpFPNSC820lGH2y/M9KfncIOJCjO4cETm2ZDBc/0LLVxKHsW+4sLMXPvDlHXC7CoVHpgwmGfCYDkVBotuT/O/vQE+jx92MmYrIAAAAABJRU5ErkJggg=="
    }, 371: function (t, e, n) {
    }, 380: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwBAMAAAClLOS0AAAAG1BMVEUAAADY2Njb29vY2NjX19fa2trY2NjY2NjX19dgydn0AAAACHRSTlMAtgevgVlOvfaSeR8AAACvSURBVDjLzdM9DsIwDAVgBBLMMDG2nICRCyBxAAZGRkauUPVH79gdXmS3fbK8Vc1kN/naJrF3a433d5YenyU4oa0mz/cP/Bl9gMtkogZ6Ri+gqRxcgY7hDyQGMDA8gMQA7hY7qblKEl/kmQBLBVi+AE4EGBFQyK0AIWcFJCBQIoDEgRIFOqGvSj+uv5tuUI8kPUQ99vSi9GrTYtDyCQsuLNGwqMM2CBsnbLWwObc6RhYBiCNnxyl6AAAAAElFTkSuQmCC"
    }, 382: function (t, e, n) {
        t.exports = n.p + "img/users.b9e99c8.png"
    }, 383: function (t, e, n) {
        t.exports = n.p + "img/Daily-Transactions.e262d12.png"
    }, 384: function (t, e, n) {
        t.exports = n.p + "img/contries.b51d1f5.png"
    }, 385: function (t, e, n) {
        "use strict";
        n(369)
    }, 386: function (t, e, n) {
        t.exports = n.p + "img/download-img-zh.7181682.png"
    }, 387: function (t, e, n) {
        t.exports = n.p + "img/download-img-en.a2a49bd.png"
    }, 388: function (t, e, n) {
        t.exports = n.p + "img/download-img-zh.ed8a1ad.png"
    }, 389: function (t, e, n) {
        t.exports = n.p + "img/download-img-en.ed8a1ad.png"
    }, 390: function (t, e, n) {
        "use strict";
        n(371)
    }, 399: function (t, e, n) {
        "use strict";
        var o = {
            mixins: [n(366).a], computed: {
                usersList: function () {
                    return [{icon: n(382), name: this.$t("HOME.INTRODUCTION.desc_2"), number: "20M+"}, {
                        icon: n(383),
                        name: this.$t("HOME.INTRODUCTION.desc_3"),
                        number: "30M+"
                    }, {icon: n(384), name: this.$t("HOME.INTRODUCTION.desc_4"), number: "200+"}]
                }
            }
        }, c = (n(385), n(2)), component = Object(c.a)(o, (function () {
            var t = this, e = t.$createElement, n = t._self._c || e;
            return n("div", {staticClass: "HomeIntroduction"}, [n("div", {
                ref: "introduction-0",
                staticClass: "content"
            }, [n("div", {staticClass: "title"}, [t._v("\n      " + t._s(t.$t("HOME.INTRODUCTION.title")) + "\n    ")]), t._v(" "), n("div", {staticClass: "desc"}, [t._v("\n      " + t._s(t.$t("HOME.INTRODUCTION.desc_1")) + "\n    ")]), t._v(" "), n("div", {staticClass: "users d-flex ai-center jc-between"}, t._l(t.usersList, (function (e, o) {
                return n("div", {
                    key: o,
                    staticClass: "box d-flex flex-column ai-center jc-center"
                }, [n("img", {attrs: {src: e.icon}}), t._v(" "), n("div", {staticClass: "name"}, [t._v(t._s(e.name))]), t._v(" "), n("div", {staticClass: "number"}, [t._v(t._s(e.number))])])
            })), 0)])])
        }), [], !1, null, "125b9ad6", null);
        e.a = component.exports
    }, 400: function (t, e, n) {
        "use strict";
        var o = {
            methods: {
                goDownload: function () {
                    this.$router.push(this.$i18n.path("/download/app"))
                }
            }
        }, c = (n(390), n(2)), component = Object(c.a)(o, (function () {
            var t = this, e = t.$createElement, o = t._self._c || e;
            return o("div", {staticClass: "HomeDownload"}, [o("div", {staticClass: "content d-flex ai-center jc-between"}, [o("div", {staticClass: "content-left"}, [o("div", {staticClass: "title"}, [t._v(t._s(t.$t("HOME.DOWNLOAD.title")))]), t._v(" "), o("div", {staticClass: "desc"}, [t._v("\n        " + t._s(t.$t("HOME.DOWNLOAD.desc_1")) + "\n      ")]), t._v(" "), o("div", {
                staticClass: "button pointer",
                on: {click: t.goDownload}
            }, [t._v("\n        " + t._s(t.$t("HOME.downloadNow")) + "\n      ")])]), t._v(" "), "zh" === t.$i18n.locale || "zh-tw" === t.$i18n.locale ? o("img", {
                staticClass: "main-img",
                attrs: {src: n(386)}
            }) : o("img", {
                staticClass: "main-img",
                attrs: {src: n(387)}
            }), t._v(" "), "zh" === t.$i18n.locale || "zh-tw" === t.$i18n.locale ? o("img", {
                staticClass: "main-img-mobile",
                attrs: {src: n(388)}
            }) : o("img", {staticClass: "main-img-mobile", attrs: {src: n(389)}})])])
        }), [], !1, null, "be6eaa7a", null);
        e.a = component.exports
    }, 403: function (t, e, n) {
    }, 404: function (t, e, n) {
    }, 405: function (t, e, n) {
    }, 406: function (t, e, n) {
    }, 407: function (t, e, n) {
    }, 408: function (t, e, n) {
    }, 409: function (t, e, n) {
    }, 410: function (t, e, n) {
        t.exports = n.p + "img/ecology-phone-zh.b1f25f9.png"
    }, 411: function (t, e, n) {
        t.exports = n.p + "img/ecology-phone-en.675933b.png"
    }, 412: function (t, e, n) {
    }, 413: function (t, e, n) {
    }, 414: function (t, e, n) {
    }, 415: function (t, e, n) {
        t.exports = n.p + "img/2020-12-jinse-reward-en.ebbabf4.png"
    }, 416: function (t, e, n) {
        t.exports = n.p + "img/eth2.0-en.b13cd02.png"
    }, 417: function (t, e, n) {
        t.exports = n.p + "img/tp-binance-chain-en.983d6fc.png"
    }, 418: function (t, e, n) {
        t.exports = n.p + "img/2020-08-tron-book-en.7ed6ac4.png"
    }, 419: function (t, e, n) {
        t.exports = n.p + "img/2020-08-hoo-ama-ogx-en.3f56e2b.png"
    }, 420: function (t, e, n) {
    }, 421: function (t, e, n) {
    }, 422: function (t, e, n) {
        t.exports = n.p + "img/bg.2713697.png"
    }, 423: function (t, e, n) {
    }, 448: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+BAMAAACB77V3AAAAGFBMVEUAAAD///////////////////////////8jfp1fAAAAB3RSTlMACb3s24RUtKCbxgAAAMhJREFUOMvtlK0OwkAQhI/woxsSgkZhcVgUGt4AwQsAYl4fdTuhzeTzpKe6c/0m7d3utP9Yw1RaNK/n5z7e3p2v9byR3sOIPkqPXqwkHX73t5IuvdjLBsb16tVSNjCuU6/WsoFx3Vx2A+MGXIf3LQS8lICXFHBrAS8x4FYDbjngpQe8DAoPBoUHg8KDgfFgYHxqYDwYGId98Kfvo//D86Hzxfuh+8X+oP7C/qT+xvmg+cL5pPmmfKB8oXyifKN8pHyFfKZ8n1drX3B3ufEPDL4eAAAAAElFTkSuQmCC"
    }, 452: function (t, e, n) {
        t.exports = n.p + "img/header-img-zh.e9f1aa7.png"
    }, 453: function (t, e, n) {
        t.exports = n.p + "img/header-img-en.f38def5.png"
    }, 454: function (t, e, n) {
        t.exports = n.p + "img/header-img-zh.9667d1a.png"
    }, 455: function (t, e, n) {
        t.exports = n.p + "img/header-img-en.f7b5ad4.png"
    }, 456: function (t, e, n) {
        t.exports = n.p + "img/header-bg.3361bd1.png"
    }, 457: function (t, e, n) {
        "use strict";
        n(403)
    }, 458: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAMAAADypuvZAAAAOVBMVEUAAAA5Oj04OD05Oz1AQEA6Oz43Ojo6Oz06Ozw5OT05Ojw6Ojw6Ozw6Oz04PDw7Oz46PDw6Oj06Oz19XodcAAAAEnRSTlMA3yCgEM8w779wr4DPj0DPkGAU71XAAAAAw0lEQVRIx+3V3Q6CMAyG4bUbA/lTe/8XK6TilzBp5xkmvCckJE96sm7hyq6TpdtvhmWNLnROlKlPJeLmzoZpRZq0R0wixJZRBaTGUKOIKiA1a9E4pKo2BCOPA8T0URtiEgzyVFZUGFPpt3UNFIJxlG18BeMr2/gKxleGMZVvelkaShWNmzAVK6cqGmuJH4jjSBjtI3Qq1Joof0HuyxJL9FaZj5pkj5LU1gREtSgGNNSiOaBUOWpyt7xi758dOfVzuPqrXuYqKfxjYJLeAAAAAElFTkSuQmCC"
    }, 459: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAMAAADypuvZAAAAM1BMVEUAAAD///////////////////////////////////////////////////////////////+3leKCAAAAEHRSTlMA3yCgzxDeMO+/cK+PgEBgK7ycxQAAAMRJREFUSMft1d0OgjAMhuG12xzIj73/qxWs+CVM2nmGCe8JCcmTnqxbuLLrZen+m2FZowudExUaco04JTZMJ5LyHjGJEFtGFZAaQyURVUBq1qJxSFVtCEbGA8T0URtiEgzyVFFUGVPpt3MNFIJxlG18BeMr2/gKxleGMZVvBlmaahWNmzBXK6cqGmuJH4hjIoz2EToV6kxUviD3ZYk1eqvCR42yR1laSwFRK4oBTa1oDig3jhrdLW/Y+0dPh91eDXO4+queUkIltWgboS8AAAAASUVORK5CYII="
    }, 460: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAMAAADypuvZAAAATlBMVEUAAAA4OEA4ODg7Oz06Oz06Oz05OTw6Oz05Oz06Oz04PDw6Oz1AQEA6Oz05Ozw6Oz3////n5+fa2tuEhIZSU1VGR0nOzs6dnZ6cnZ7Ozs9wSEISAAAAD3RSTlMAICCfn4Bv779aQP4Q7r/wUWbVAAAAp0lEQVRIx+3WwQ6DIBBFUdSKgraMIGj//0drmjaEdCYDNe64S5KzARZPnG6WHZFqKSMHQ9fjpicBrZRh0ggaOTQiyHANv6YxbC2JAKmiiiqq6EBkFZUhvwUA64rQusC7ZS1Ah/kon41c/AxbNrIRBR4h/+9aFKKx2WiPyGUjH6/8gscV6cZxFuC5++Tsn/HxQJDmkC4fVFP5DJvuUhA16pbWfZOzONsL0GFiJULkQL8AAAAASUVORK5CYII="
    }, 461: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAMAAADypuvZAAAAQlBMVEUAAAD///////////////////////////////////////////////////8pgP5EkP7y9//k7/+vz/+UwP9eoP5RmP7epHdGAAAADXRSTlMAIJ+egL9v70BfEO5Q77YkPAAAAKBJREFUSMft1ssOwiAQhWGoLaVVppTL+7+qxmgmRCYMwe7mX5J8G2Bx1HC7mYg2TRmzOrq5bmYS0OrhGtkKWlpoqSDXav012jXTJIJKggQJEqQdnaA+5GMCyKELnQe8O84O9DIf5dko4GeIbJQRJTYCwK5FCU1mo4gosJHHK7/gcVW5cUIGSNEXZ/8aH7aF7Mig4qu7UUR6m8pu38yuRnsCMA5VKvWzbOYAAAAASUVORK5CYII="
    }, 462: function (t, e, n) {
        "use strict";
        n(404)
    }, 463: function (t, e, n) {
        t.exports = n.p + "img/security-img-zh.ce3c758.png"
    }, 464: function (t, e, n) {
        t.exports = n.p + "img/security-img-en.aff6e43.png"
    }, 465: function (t, e, n) {
        "use strict";
        n(405)
    }, 466: function (t, e, n) {
        t.exports = n.p + "img/exchange-img.9e6d4f8.png"
    }, 467: function (t, e, n) {
        "use strict";
        n(406)
    }, 468: function (t, e, n) {
        "use strict";
        n(407)
    }, 469: function (t, e, n) {
        "use strict";
        n(408)
    }, 470: function (t, e, n) {
        t.exports = n.p + "img/dapp-store-img.d71690c.png"
    }, 471: function (t, e, n) {
        "use strict";
        n(409)
    }, 472: function (t, e, n) {
        t.exports = n.p + "img/ecology-1.1500bd3.png"
    }, 473: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABkCAMAAABDybVbAAAAe1BMVEUAAAD////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////NgkbwAAAAKHRSTlMA9SXjC5Qr8efsBkXJeD/Sp42HE147NnPewn25bmlN2ZkxF7GfHVcibcAqWgAAArBJREFUaN7tmNuSojAQhpuTaBBBwQMygoAK7/+Ea7eHAIvuKp2Lqcp3MaOE4qskfzcpQaPRaDQajeY15TJvXCtPTvu4EKCK866RGPNlZoMK0qaHkcb8JrMZwAgXzJrs+tTEtktzEa/C1voFseDW7CK4E2XOU7WLOXOGT5xmIDH3D1Pg8XmcBnE6u74I76KwxCnaDOtnVw2Sb6BN7Rh0eebTKlrLzWiR3xB+r55OTYfT6JQXQYNUvQdt5h1Pbo5eOOeWrQK6bA2qoqlxS8T4qvVm9MB+hs1qGnoAwqP5HhlaW3LbgRehErRT5niPWJIniV6sK85nz9IQXNqgCQxywd3haaM5etwMhohwCFiw0wb5gSFwBJi4bdBqaDacGohvgYO/OGA+gA3PkB2hzZz6ER/FdCjYAi8egJGaAjcfODPMIk5PRPOpocMEFzPk1KzQYol+H8WrHrNlVsBQCALlFtjgQMxqmQBiep2VC7HlCWYLVWTQztYZxy7sFsq1DZIjXmBqadJCpKJ3El6wW4iwtzshu8UI8O+y1fDwos1n+SGLF5FnC08szDS3BeBs4aesE5GK23Jl4uLHZ7EW+E2MtEy7FmJBDa6UqzamsTmDFiJulw+VzorPsuiVbNg6RyXsFqJqHXdqHB1v2UpL98TZrIHAw/aE3ULUMxmDFNsnu0VWf5M8b/e/tZiDFsmeTomPexxmiyR9NOcMu7YqC0QWbo8NsMYqGm1ZwwvW9+qZXP/l31v8NxZZpTG9qa3PLdZ7i0TgAco1zU81xw8siGngPTOM9hiL+8bSfW/HCi20ykSl0EIcrGtkfPGVZS8t/6Ys4f+5DFn4maOlblk2oAIXXxrKLRBgY4pUWmS28rNiC4iEMuAotBD2HA2KLeRRb5E/A1loUcvlFPo2aDQajUbzq/gDg72N7zhRXVIAAAAASUVORK5CYII="
    }, 474: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABkCAMAAABDybVbAAAAflBMVEUAAAD////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////vroaSAAAAKXRSTlMA76BWv639RNIL5uvfG/f02KU/BsyDZTomETSVj29fT0qKLsazfLp3ExM+KtcAAALlSURBVGje7ZjbkqIwEIZ/QYMBVAQFweN4mLHf/wV30omUTG1NJUpqL5bvQokV85nuNglgYGBgYGBg4J/SBNn0C565B4K++YBXyoSYhYQ/zhd6sIEv5Iegltolm+vJZfor4wMehDExQslSWFNdyIIIzOZq2uNIvQaw5UuQDTfVt7jNiYkPCNX7AZbcyApRAcgz09jWQOBSAZHQX1yNf2VyBGRglKsG3yhlDEv49yWHwqLAVsQs9tycqesl7DiyZQYL1sQsTWdOTQk7OA4hbEhV1zSCYeuSGhWIEaxYdOc9VU1YEqt/AKyYciHn0NSqdCawZGTfuSSFWD8lde9BgyUxYw7cTl2efWiwFuxJTm1SvWgQxTpwu0Iq49WPhvPDrPbq9cuT5h7TM40nzbJjSeFHc+TERA9Z6UdTx+YsUyZcB/Cj4fUvkwBkubs18KM5tbub5n1NER4kfiA5ZDv0qLkSpZu/hSxt7fn4cnpTE/Ja3PVEHLIchnpBNJ+9p8lIkZyfQ8ab2rZt57wdvqU5kGbUoGXbDRmitzVFSg9PBUMu9ImwR03JmeFxF/lzyAL0pzGFmx/YM9cT2LFZ9qnhJf4TCLVHVW3Flyf0qJF8f6SScpxzDYeQmQ5Zn5obtdviyXg+OGR1n5pafSDOZqwFezhkR/SpWXdOxjl79Ed9amZqXLFp29WImOTeq2b3M9lNQnrAPjWzOf1cEc8J9+hBk8nOYr9Fh81lPpF9aGhcmBGFnowFrprnOlrqI4UvjRn7rCazuHvU8C3ERF2s4VMjQjT8B5FeNTSvPvXp25tmFfMWpvcUf5pJwwqdIo8anAQxaeFVg5KYEl41ZgPICs8aXs5EBF+amM8XinBdwZ7Q7KgOD1MSuMNBrtzuJnO4UkzVylG7TT6VL01mDGtkyh63+dQBKUKnXDLxNbBluRLkNBlmS68Rz9yy+Zon28CRMHV18BNiZ4owWMUjW5Lscz/DwMDAwMDA/8EfSgvBWdarLqgAAAAASUVORK5CYII="
    }, 475: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABkCAMAAABDybVbAAAAdVBMVEUAAAD////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////li2ZAAAAAJnRSTlMAKWPfriEL9BMH+KF5yV02LhmOhe9A58FV5NbSvJVvUEe27JppgKlFIXAAAAIZSURBVGje7ZjrjoIwEIWLCqIo1CqCihe88P6PuCEWZ3WS7Q5Mk91kzk9I5oN2Lu1RIpFIJBL9RQUmuSjfisy8aZo6UF41ujZPmVh5U35oXrrelR+Fk+ZNh1zxK3rMn9HnZrS1oEnITUl3NnQdtnnQIdcRJyRbWsj+8rGA25QNskpszM0JHl729uEyY4HMFlMb8PaexKeNfZ6shlPOYxus0OpD8dG+mi5mwyC6spHGJeE1Tfhz3T9LF15899bRhVPJnYiELUKFQSsrktZQ5sQmEVMo5KYVdR+2JGAO0ILJy0xop+N2Q+/9xlFAw0x6zFbB2IZjbrlj702SDcYscV7jTJ6GAzGxo0ptXaZD/2YHPeeHLqOHYjTuoLhnpgyZhucBngBDMXi64XnGVje6gGGMpjNneZbw8ej3ODB4K45oszgwOLFQ6jFioEygkNgxUPQwvD1iVGTaUFXoexAEbaiREoxgBCOY/4UZZ1TMqiZj8HDEGDReqfebBEa9A4NOOluKq1V3B5fz7zDB66Sj+3kolXZgeroq+CQTOzD3K5x0mPwtFbU35hwboA6bgmwrpNPGOG0KuveIHYIZcgMGu5EQyOBAKaO3CssyQkvK6hTDJucoQTh9b0jZSQjp7sHFj01XgI/o+zWkChSvgq7/7EpdQCtiF9iF1M5C7j+bBpTEypfiWwcpMuVTunjuj/Ktstg/IiUSiUQiEUlfbUidXUGyzLsAAAAASUVORK5CYII="
    }, 476: function (t, e, n) {
        "use strict";
        n(412)
    }, 477: function (t, e, n) {
        t.exports = n.p + "img/community-img.c0ea679.png"
    }, 478: function (t, e, n) {
        t.exports = n.p + "img/community-img.02aea60.png"
    }, 479: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABYCAMAAABGS8AGAAAATlBMVEUAAAA5Oj06Oz05OzxAQEA6Oj05PDw6Oj04OEA5Oz04ODg5PT02OTo6Oj46Ojw6Oj06PDw6Oz46Ozw5OTs5Ojw5Ojw5OT06Oz46Oj06Oz1VwOLXAAAAGXRSTlMA3++/EF9AkCCgIFAwf4CvgM/PcHCvb86wLiLxtQAAAupJREFUWMPFmduOozAMhrFzApICbaed9fu/6HY10tLggBNTaf5Lqn44jk8JXYWSC8MVkF5CMHOIqTsvfzFIXGZK56hIu4Jh1GINCTJOgXVAFYJWtBewSnRvqEH1vn4iNQm/qrBWMFdrdAJSCESyQ1IJhT28kFoXiasna7l68pNOaifsIp2WL6YbnAdjKeoYV6OrZdxAqyAEU2vjIwSkVYElRpah/zLbVbCNz23ibrZQ+LEf6iqEz5Lb7kcwvh4wNMLNmBvgau343yp615RFRL7AvJHg4xnH1Y4UpwcQxm7Vjd71HhlDvsTsnalYA223+3fDDF4X06iwlybDSfBEZZN7+iyYxrLBNLSC5w0g7CTztRV82wDQrkmXybZxLQO4dSGZYhs48lQvv2/uGmWo5IsotXJZPZYqfig66KQzQmFLoVPI8MCy3GCFPA8szwxWCZmT7yztVAps3fyJQjzLAkuPpAOnDeZPZ5jXdWJhAZRLReW7B/yBTlsDsSMBrI23DVjvCvo18Kjj9gyMQhwriwV2IGSesnACq5rhM7XCsJS+6sA3Bg5Ci1buXWBlk+4asOOUWGzdp/u0L3R/r/IEdyh8wOSBCiVnOG+yZ4ihOLqBFBjy0dOtI5beGfbKCeO6o5lmq+Ayy+6aqxjuB15wLBWElzpzy5eU4ya6bw8j3tTJ2HXo8W+e6Zc39OAPgywgleW3CemY09BMMVlm6eiCQdrTNw/wS3E7li14oUO5Qg25Wj6gz1LNOZggfB6Bk9Re/RE4lY+AX9vbCyOVycM52GJ24OlBKPz36lvOr7eTdE72QlOWuvycn1ftAj/hFoXKLh4ILGzXnnwa5ZYh15i+qRwLEVF2c1CBeSrxhLoowYs4J4HTgEPNBAbzFP1LLlSDB2G2q5vERa5cuGwdeBEHXawa8RXfWHpoB3+nqr47tIKNVXxyk8EQG4amBWvBGLi5sj9kcEjtM2/4KZwHJ1xcbKeSM4RubxvQuCPsX1KoQt2l3I2DAAAAAElFTkSuQmCC"
    }, 480: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAABZCAMAAABi1XidAAAAS1BMVEUAAAAogP8pgP4jgP8pgP4pgP4pgP4ogf4ogPsogP4pgP0pgP0pgP8pgP4ogP8ogP8ngP0qgP4mgP8ogPwqgP4rgP8qgf8pgP4pgP75kaeEAAAAGHRSTlMAIN8Qv4DvX0BwkKDPr59AMK9QUO6PT7ByR5DuAAAC50lEQVRYw7WZ6XIjIQyEgwBxzOmxs6v3f9LdxKngsWAYgd0/ceqzqt0SRz5OS6v/0h+vlN7CPAL9CMxkN/UC6hKBMoJ56yp/mZHKmrbWci1QRRBUCxfphMBK2S5xq3VLuKshgWA9DQ4klD3HVYbEAnUmaUgNQtfqRL8jlpplBWChBgFYipaC+w1x1K2QzzFSv3wGrIFeIFScPOwmmJ3gJGoOASnJHJs8f634oc6dPPvlw7PJkHFLDXBYrv3ZsPyRH/v60hf+riOYb434W29CIBX9UFT6TAHBHFadVrR3cSR4TMFUzsdAzOZEykZ0txqLhS2slWQKxVBPnWRHhaIV7RWlZFvqxOfgzlJypHzRGmkvkJLZzqlLM04LyaVxyvfqPzKwJ8raofk0aPU56bs/r+LDAxdktwA20pwYzP34+7U60l5jHVRPB+Zsdi1knzF6YWFukuH1BUEDCuIR+ZJrI3te4ER7rW1kxXNgBJ0t6HDgIW/j5jj4NjK9iazeTu7/BbFKVo1kzkHB1Bfkmbg/oY28cPLIGr5JlnfK9KJZx7s7viYcmU0lUK/R2c00ZtZMC3kiHjFNz/JtmePDGPqL5vs/ptWuohVlq3PUe5TRkL/MamIaZcm7cMLKQy5H65mYgN8y5IaokbhiOplzWd3xYKieY25m81C2U0Iuz61/OCsq+3hbXw4HZ0TKy7FB5dgVHE3cFs1qXV00SCVB5uj0qRM6yQqfhVxuuoLmrzOmnuDyhPd7jK3tuapWctKw78uxdgcwZfDlI2mXaVRPVlvhI6cq/mlMASlPvrUItuUfBe8hs3BP3TXfIyXwWB6F6VtXv5a7UPIQrTAlL0lI9sfvH59Ccv3NJQjQwsfcmOZcC/ly6gwFk3XLsmwu6rNkowXbe/lAXauYy7aSh/pxFZvI9syWCXLyzZ/bjQcp+aJOn1lBQr452X8Hz5JvLJZVS7BKTkZI2XBwu4B7vYkr03UiDPmPPJA59vcfJSM236EmXz8AAAAASUVORK5CYII="
    }, 481: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABYCAMAAABGS8AGAAAAilBMVEUAAAA6Oj05OT06Oz04OEBAQEA6Oz06PDw6Oz02Ojo6Oz45Oj05PDw6Oz06Ozw7PT04ODg6Oz3////z8/NrbG1TU1Xn5+ecnZ7Ozs61tbaDhIbCwsJfYGGRkZJHR0mpqaqdnZ53eHmQkJFGR0ny8vOEhYaEhIXOzs+1trba2tuoqapGSEm1trdfX2Gsj6k2AAAAEXRSTlMAYN/+IBDvfr8wz69An5BQIC5/pqYAAAKESURBVFjD7djrcqIwGIBhQPGw6nbz5QAIykGLtt29/9tb21G/xgA5mM74w/dnnHkmYEjQ4FlX8Ty8p5dl3Mm+zMjdzUKFHSN7V9Ef2Z1PiKcmc2m+6N4vf59zRDw2QzckXlte4YVfeOH3TmDRFSaee8IPAxf17Qgr7oZZle4BmDzIASBNmDvMyj18lcrjGXwlMuYCf1R7uLZpkmOensqPSVPjuKi4LZyAYZUdzME4ZgULc/jNBl6DRRtzmAsbmO6M4RKsqkxhDnbRnSGcgWWVGcwpuExZD6/BusoIFvYwNYEZOMQM4MwFPhrA1AWmOy1cg1NMC2cgl7d1I0BKJG2bgVyphYVs/FN353LbsZ8IHcxB6nJAvONQ1v0ccQ1cA4YI2aHCuw+Z114Yp4bhMZ/DuUPPxZUaOIXvdZyBZc/CzDWw0MFJDyw0MEjhss/UZ2wHUsMwB6mNeiW0bxfkgzBTTmAF2fTsgswGhlI9XWnR/UpT98A9m3xeXN62UN58EFLkcNOrGYztxYXFhABwgvU94YFqzXIzj9qs40J+8Hgietlk2yg7oQJjDQVMMEJYJjrU8vOTVFrcuqOJSxtnuv68jDY70Kvw9rfh5IaFAzd4E2pF1z675Yyxgm9x41emq3+NfVe+EyUm3W2igZHO8NTrKZVYHYyd1wPlfTCnyBrBWJvj5ttRA/TAHH9LbxkZqN4+6t8KT/ih4cjdmAzCv93hMBqCl+7wahx1wB6mPInjxQAc/3KWl0EwVWBs7CyvgpM8UmBsGrneC1UOpMbhzMoenQuDU/NIgj02jvzD6rcUeC1eIOy56Q/BuDgC74UjhP02j/zDuOwQ9r3sgh8pXiHsuWlw6j+UzJOI0SRt/AAAAABJRU5ErkJggg=="
    }, 482: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAABZCAMAAABi1XidAAAAdVBMVEUAAAAogP8ogPwpgP4pgP4pgP4ggP8pgP4of/0wgP8pgP4pgP0ogP0ogP0ogPwpgP4ogf8ngP4pgP7///9eoP5EkP7y9/+UwP/k7/83iP7J3/95r/6GuP+vz/6hx//X5/9rp/682P+uz/9RmP6u0P9DkP55sP77h1RPAAAAEnRSTlMAIGDe378Qr3AQ75CAQDDPX1AmjFNyAAACe0lEQVRYw+3Z11LjMBSAYQypkITFR12uae//iLvJLpwVkq1iZSYz5L/UmC9Nlmzz9Gigxe55Sh/bhdvdzsvJzX/ZboHupGbFN3j3WubKfNsFwtPb/i/PyozNFgh/lFlbobzMK89Rfi/zhnKZueIh35V86r6PkMN0mVSKARBzkAKA4mSCTBoG15Q5vodrYk+SZMkZfKU1Px57pdTxyHWH44LTaLliEBaPlCkER+JkES4LGSNriIhHyFLEyIyGyxyi2gfLVEBcNFTmENk+UJYCYpNhsoboeJgs4mUmQ2QCCekQeZ8iqxBZQErSLxNIqvLLDZipSnMBRqzRVQ1mvV9uTYTY504tHScq88oSjA72J2k/1wBmHumTO+Pw+usFkaHuRaDyyXxgv6jxLbs/Xu2T+4G5VKHgnp+tT24NuQyXmU8eWngbh8zMY8dlOjT/W3vxIdY0csruo4VjylQDC0wXJUNj71/s4N559LjcWRsRvbye+VtdDNlYK8e4rMGqbZm10CsBVtwnB/Yj5C5d1p5ZdzOZmh+Q1mIIYg2x1sXwVVTRsuxq5mCVluVBmefUmGzvQj253mD1LQ6JviLyz6DhChJyjVQJ15XEiVw7uTZixmXgVW4N2Ll0RgDrPVe5brt1qObmo0jcXdvnrKBDMmX/Zkj8Paw8K/fdHu5fqpKJ9920K0c6n+73KcRDvn95djP5LR1ZvYzK23R5XjjoIsfD3NfFejkmr9O/6Wf8Ml3yU4F0wsPmjS1j6+Rf8fLsfeWQseLtPW124P82bBn1hBZ///LFlqeHNMo5Wy9zy9gG5ew0yrlboZy73Ut2GacIytnp7DLOPpRzt0H5Jv0GxWuqXs2hm64AAAAASUVORK5CYII="
    }, 483: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAABaCAMAAADkQQozAAAARVBMVEUAAAA4ODg6PDw6Oj45Oj06Oz06PDw6Oz06Oz1AQEA6Oz45OTs4OEA6Oj05Oz06Oz07Oz41ODo6Ozw5Ojw5Oj05PT06Oz0FrP9sAAAAFnRSTlMAIIB/3+9Av58Qz3AgT6CPXzDPr2BQMudBLgAAAcNJREFUWMPt2d1ugzAMBWDiJfyUjp+28/s/6tRN7Ki1amMCF9ty7hrBp+goskRalZSU5KRuI5tJ19rrdiOvTBt88IlXJ3YeeWRHGgd8ZlccXQ/MB2364pPTepmd6aqSkv+Ueoy8ObGtM2ayOaudMzl3Vo+8QxrPTM6e1cM+cuOYydmzmndKKHK+fBsuO8nEDzndz/3Hcj6HDJmeVtvvubUYtFmm59X3ryf7H4M2yoTVh7ca/KJNMmEVNd+TYIB2yIRVWTMMcsuEVVHzg0EeGXCl1LwY5JABd0rNPFegdVnC56jUzDGA1mQTRs2SVmULRs1IQiG2DHheCpU1IxNoQwY8gZA1Iz1oXQbMjMiakTfQigz4TcCoWaelLB8zaxabUWTQPRs1S1iXQd/W1dwDNmTQc1pR8w2wKYM+R6vmVANWZUnrNccZsCFLWqs5BsCWLGmtZuzYliWt1RwAm7KktZoDYFOWtHaaA2BTlrR2mgNgU5a0dpoDYFOWtDY0AmBTlrQ2NAJgt8zLu9cpyKHRskNWEtsp/cqviT8qd0KOh30dj4d90df7yNNhNyeH3fa8uEgasnfcvbxVG6IHkv+AlJSUePMJDr4+RHI3veUAAAAASUVORK5CYII="
    }, 484: function (t, e) {
        t.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFkAAABaCAMAAADkQQozAAAASFBMVEUAAAAogP8pgP4pgP4pgP4pgP4pgP8ogP8pf/0ggP8ogf4qgf8ogP8pgP0qgP8ogPspgP8ogPopgP4pgP0lgP8wgP8nf/0pgP5Osy4tAAAAF3RSTlMAIIDf77/PQHAQX0+foJ9AjzCvkDAQcItw44IAAAGzSURBVFjD7dfdTsMwDAXgxOnP2tF2P4Df/00RoHHEHNx6Ti+AnLtF3afqqHWTUFNT40k/J15Nc+mt7nDijZmjDe54c9JgkU9sSGuAI5uybJcn5p1uurPJzXaZjRlCTc1/Sn9N/HDS3Ptmsj6rjTPZO6tPXCCtZSa7Z/VURm4NM9k9q7lQYpX98jh1hWTib+lCCPF4ez4nh0x3q0+fc+tm0MMy3a8ew3sOXwZZZcAh968Wv+ghmcRqFz7SwABtkAmrsmYYZJYJq7maYZBRJqzma4ZBBhnwoNTMzwG0Lks4JqVmThG0LuswatZpKa/BqBlpzqBXZcDnW6GyZmQEvSIDHkHImpEDaF0GzEimZtkdKbK4Tq9Z0nZZ1myXcd0rKzWb25BFr9d8AGx96vSaR8DGN0WvuVkAG99uveaEV9AxkVCzfSJl6VzNnikKOlezZ/KDztXs+VqBztXs+cKCztbs2BWAztbs2MmAztbs2H2B1oZGpAK73MsY5dCYC+3M0zw2v/I08UflQchpt9PxdbcT/VJGHoPMtfAtIy+dH04xZOnJfcdD+CHLlBxPxWUJNTU11rwBilxLfcydV7sAAAAASUVORK5CYII="
    }, 485: function (t, e, n) {
        "use strict";
        n(413)
    }, 486: function (t, e, n) {
        "use strict";
        n(414)
    }, 488: function (t, e, n) {
        t.exports = n.p + "img/2020-12-jinse-reward.b7f16ab.png"
    }, 489: function (t, e, n) {
        t.exports = n.p + "img/eth2.0.1255ebd.png"
    }, 490: function (t, e, n) {
        t.exports = n.p + "img/tp-binance-chain.400cde6.png"
    }, 491: function (t, e, n) {
        t.exports = n.p + "img/2020-08-tron-book.3265826.png"
    }, 492: function (t, e, n) {
        t.exports = n.p + "img/2020-08-hoo-ama-ogx.cdd2dfc.png"
    }, 494: function (t, e, n) {
        "use strict";
        n(420)
    }, 495: function (t, e, n) {
        "use strict";
        n(421)
    }, 496: function (t, e, n) {
        t.exports = n.p + "img/extension-modal.80f32f6.png"
    }, 497: function (t, e, n) {
        t.exports = n.p + "img/extension-modal-en.a7ada22.png"
    }, 498: function (t, e, n) {
        t.exports = n.p + "img/extension-modal-m.38f5adf.png"
    }, 499: function (t, e, n) {
        t.exports = n.p + "img/extension-modal-m-en.535641f.png"
    }, 500: function (t, e, n) {
        "use strict";
        n(423)
    }, 642: function (t, e, n) {
        "use strict";
        n.r(e);
        n(449);
        var o = {
                props: {btnItem: {type: Object}, isSecurity: {type: Boolean}, isHeader: {type: Boolean}},
                methods: {
                    openUrl: function (t) {
                        t.local ? this.$router.push(t.url) : window.open(t.url, "_self")
                    }
                }
            }, c = (n(457), n(2)), r = Object(c.a)(o, (function () {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {
                    staticClass: "button d-flex ai-center jc-center",
                    class: {isHeader: t.isHeader},
                    on: {
                        click: function (e) {
                            return t.openUrl(t.btnItem)
                        }
                    }
                }, [n("img", {
                    staticClass: "icon",
                    attrs: {src: t.btnItem.icon}
                }), t._v(" "), n("img", {
                    staticClass: "icon-hover",
                    attrs: {src: t.btnItem.iconHover}
                }), t._v(" "), n("span", {class: {security: t.isSecurity}}, [t._v(t._s(t.btnItem.text))])])
            }), [], !1, null, "14f0360e", null).exports, l = (n(222), {
                data: function () {
                    return {isMobile: !1}
                }, mounted: function () {
                    navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|TokenPocket|WebOS|Symbian|Windows Phone)/i) ? this.isMobile = !0 : this.isMobile = !1
                }
            }), m = {
                mixins: [l], computed: {
                    btnList: function () {
                        return [{
                            local: !0,
                            icon: n(458),
                            iconHover: n(459),
                            text: this.$t("HOME.download"),
                            url: this.$i18n.path("/download/app")
                        }, {
                            icon: n(460),
                            iconHover: n(461),
                            text: "KeyPal",
                            url: "zh" === this.$i18n.locale ? "https://www.keypal.pro/?locale=zh" : "https://www.keypal.pro/?locale=en"
                        }]
                    }
                }
            }, A = {components: {Button: r}, mixins: [m]}, header = (n(462), Object(c.a)(A, (function () {
                var t = this, e = t.$createElement, o = t._self._c || e;
                return o("div", {
                    staticClass: "HomeHeader",
                    class: {chinese: "zh" === t.$i18n.locale}
                }, [o("div", {staticClass: "content d-flex ai-center jc-between"}, [o("div", {staticClass: "content-left flex-1"}, [o("div", {
                    staticClass: "title",
                    class: {chinese: "zh" === t.$i18n.locale || "zh-tw" === t.$i18n.locale}
                }, [t._v("\n        " + t._s(t.$t("HOME.HEADER.title")) + "\n      ")]), t._v(" "), o("div", {staticClass: "desc"}, [t._v("\n        " + t._s(t.$t("HOME.HEADER.desc_1")) + "\n      ")]), t._v(" "), o("div", {staticClass: "buttons d-flex"}, t._l(t.btnList, (function (t, e) {
                    return o("Button", {key: e, attrs: {btnItem: t, isHeader: 0 === e}})
                })), 1)]), t._v(" "), "zh" === t.$i18n.locale || "zh-tw" === t.$i18n.locale ? o("img", {
                    staticClass: "main-img",
                    attrs: {src: n(452)}
                }) : o("img", {
                    staticClass: "main-img",
                    attrs: {src: n(453)}
                }), t._v(" "), "zh" === t.$i18n.locale || "zh-tw" === t.$i18n.locale ? o("img", {
                    staticClass: "main-img-mobile",
                    attrs: {src: n(454)}
                }) : o("img", {
                    staticClass: "main-img-mobile",
                    attrs: {src: n(455)}
                })]), t._v(" "), o("img", {staticClass: "header-bg-img", attrs: {src: n(456)}})])
            }), [], !1, null, "bae42368", null).exports), d = n(399), h = n(366),
            v = {components: {Button: r}, mixins: [h.a, m]}, f = (n(465), Object(c.a)(v, (function () {
                var t = this, e = t.$createElement, o = t._self._c || e;
                return o("div", {staticClass: "HomeSecurity"}, [o("div", {staticClass: "content d-flex ai-center jc-between"}, ["zh" === t.$i18n.locale || "zh-tw" === t.$i18n.locale ? o("img", {
                    staticClass: "main-img",
                    attrs: {src: n(463)}
                }) : o("img", {staticClass: "main-img", attrs: {src: n(464)}}), t._v(" "), o("div", {
                    ref: "security",
                    staticClass: "content-right flex-1"
                }, [o("div", {staticClass: "title"}, [t._v(t._s(t.$t("HOME.SECURITY.title")))]), t._v(" "), o("div", {staticClass: "desc desc1"}, [t._v("\n        " + t._s(t.$t("HOME.SECURITY.desc_1")) + "\n      ")]), t._v(" "), o("div", {staticClass: "desc"}, [t._v("\n        " + t._s(t.$t("HOME.SECURITY.desc_2")) + "\n      ")]), t._v(" "), o("div", {staticClass: "desc"}, [t._v("\n        " + t._s(t.$t("HOME.SECURITY.desc_3")) + "\n      ")]), t._v(" "), o("div", {staticClass: "buttons d-flex"}, t._l(t.btnList, (function (t, e) {
                    return o("Button", {key: e, attrs: {btnItem: t, isSecurity: ""}})
                })), 1)])])])
            }), [], !1, null, "e82d91ec", null).exports), O = n(6),
            w = (n(64), {props: {item: {type: Object}, flag: {type: Boolean}}}),
            C = (n(467), Object(c.a)(w, (function () {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("a", {
                    staticClass: "box-item d-flex ai-center jc-between",
                    attrs: {href: t.item.url, target: "_blank"}
                }, [n("div", {staticClass: "box-left d-flex ai-center"}, [t.item.titleImg ? n("img", {attrs: {src: t.item.titleImg}}) : t._e(), t._v(" "), t.item.title ? n("span", [t._v(t._s(t.item.title))]) : t._e(), t._v(" "), t.flag ? n("span", [t._v(t._s(t.item.desc))]) : t._e()]), t._v(" "), n("div", {staticClass: "box-right d-flex ai-center"}, [!t.flag && t.item.desc ? n("span", [t._v(t._s(t.item.desc))]) : t._e(), t._v(" "), n("img", {attrs: {src: t.item.icon}})])])
            }), [], !1, null, "eab1bd2c", null).exports), _ = {props: {msgList: {type: Array}}},
            E = (n(468), Object(c.a)(_, (function () {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {staticClass: "message-box d-flex ai-center jc-between"}, t._l(t.msgList, (function (e, o) {
                    return n("a", {
                        key: o,
                        staticClass: "item d-flex ai-center jc-center flex-1",
                        class: {border: o !== t.msgList.length, pointer: e.url},
                        attrs: {href: e.url, target: "_blank"}
                    }, [n("div", {
                        staticClass: "d-flex flex-column ai-center",
                        class: {"item-wrap": e.titleImg_hover}
                    }, [e.title ? n("div", {staticClass: "title"}, [t._v(t._s(e.title))]) : t._e(), t._v(" "), e.titleImg ? n("img", {
                        staticClass: "title-img",
                        attrs: {src: e.titleImg}
                    }) : t._e(), t._v(" "), e.titleImg_hover ? n("img", {
                        staticClass: "title-img title-img-hover",
                        attrs: {src: e.titleImg_hover}
                    }) : t._e(), t._v(" "), n("div", {staticClass: "desc-wrap d-flex ai-center"}, [n("span", [t._v(t._s(e.desc))]), t._v(" "), e.icon ? n("img", {
                        staticClass: "icon",
                        attrs: {src: e.icon}
                    }) : t._e(), t._v(" "), e.icon_hover ? n("img", {
                        staticClass: "icon-hover",
                        attrs: {src: e.icon_hover}
                    }) : t._e()])])])
                })), 0)
            }), [], !1, null, "4e39ce08", null).exports), M = {
                components: {MessageBox: E, BoxItem: C}, mixins: [h.a], data: function () {
                    return {usdtNumber: "", intervalId: "", priceError: !1}
                }, computed: {
                    msgList: function () {
                        return [{
                            title: this.$t("HOME.EXCHANGE.desc_3"),
                            desc: this.$t("HOME.EXCHANGE.desc_4"),
                            icon: n(368),
                            url: "zh" === this.$i18n.locale ? "https://swap.transit.finance/?locale=zh#/" : "https://swap.transit.finance/?locale=en#/"
                        }, {
                            title: this.$t("HOME.EXCHANGE.desc_5"),
                            desc: this.$t("HOME.EXCHANGE.desc_6"),
                            icon: n(368),
                            url: "zh" === this.$i18n.locale ? "https://swap.transit.finance/?locale=zh#/" : "https://swap.transit.finance/?locale=en#/"
                        }, {
                            title: this.$t("HOME.EXCHANGE.desc_7"),
                            desc: this.$t("HOME.EXCHANGE.desc_8"),
                            icon: n(368),
                            url: "https://openc.pro/widget-page/?widgetId=UjcyR3hQVlk"
                        }]
                    }
                }, created: function () {
                    this.getPriceUsd()
                }, methods: {
                    getPriceUsd: function () {
                        var t = this;
                        return Object(O.a)(regeneratorRuntime.mark((function e() {
                            var data, n, o;
                            return regeneratorRuntime.wrap((function (e) {
                                for (; ;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.prev = 0, data = [{
                                            address: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
                                            blockchain_id: 1
                                        }], e.next = 4, fetch("https://preserver.mytokenpocket.vip/v1/swap_market/market_optional", {
                                            method: "post",
                                            body: JSON.stringify(data),
                                            headers: {"Content-Type": "application/json"}
                                        });
                                    case 4:
                                        return n = e.sent, e.next = 7, n.json();
                                    case 7:
                                        0 === (o = e.sent).result && o.data && (t.usdtNumber = 10 * o.data[0].price_usd), e.next = 14;
                                        break;
                                    case 11:
                                        e.prev = 11, e.t0 = e.catch(0), t.priceError = !0;
                                    case 14:
                                    case"end":
                                        return e.stop()
                                }
                            }), e, null, [[0, 11]])
                        })))()
                    }, getExchangePrice: function () {
                        var t = this;
                        return Object(O.a)(regeneratorRuntime.mark((function e() {
                            var n, o;
                            return regeneratorRuntime.wrap((function (e) {
                                for (; ;) switch (e.prev = e.next) {
                                    case 0:
                                        return t.priceError = !1, e.prev = 1, e.next = 4, fetch("https://aggserver.mytokenpocket.vip/v3/transit/swap?token0=0x0000000000000000000000000000000000000000&token1=0xdac17f958d2ee523a2206206994597c13d831ec7&decimal0=18&decimal1=6&impact=300&part=10&amountIn=10000000000000000000&amountOutMin=0&to=0x959E1d86982BDD541cBB8a36bd74693249f088f2&chain=ETH&issuer=0x959E1d86982BDD541cBB8a36bd74693249f088f2&channel=web");
                                    case 4:
                                        return n = e.sent, e.next = 7, n.json();
                                    case 7:
                                        0 === (o = e.sent).result && o.data && (t.usdtNumber = o.data.totalAmountOut / 1e6), e.next = 14;
                                        break;
                                    case 11:
                                        e.prev = 11, e.t0 = e.catch(1), t.priceError = !0;
                                    case 14:
                                    case"end":
                                        return e.stop()
                                }
                            }), e, null, [[1, 11]])
                        })))()
                    }
                }
            }, k = (n(469), Object(c.a)(M, (function () {
                var t = this, e = t.$createElement, o = t._self._c || e;
                return o("div", {staticClass: "HomeExchange"}, [o("div", {staticClass: "content d-flex ai-center jc-between"}, [o("div", {
                    ref: "exchange",
                    staticClass: "content-left"
                }, [o("div", {staticClass: "title"}, [t._v(t._s(t.$t("HOME.EXCHANGE.title")))]), t._v(" "), o("div", {staticClass: "desc desc1"}, [t._v("\n        " + t._s(t.$t("HOME.EXCHANGE.desc_1")) + "\n      ")]), t._v(" "), o("div", {staticClass: "desc desc2"}, [t._v("\n        " + t._s(t.$t("HOME.EXCHANGE.desc_2")) + "\n      ")]), t._v(" "), o("div", {staticClass: "message-box-wrap"}, [o("MessageBox", {attrs: {msgList: t.msgList}})], 1), t._v(" "), o("div", {staticClass: "box-item-wrap"}, t._l(t.msgList, (function (t) {
                    return o("BoxItem", {key: t.title, attrs: {item: t}})
                })), 1)]), t._v(" "), o("div", {staticClass: "main-img-wrap"}, [o("img", {attrs: {src: n(466)}}), t._v(" "), t.usdtNumber && !t.priceError ? o("span", [t._v(t._s(t.usdtNumber.toFixed(6)))]) : o("span", [t._v("10 - 18129.66")])])])])
            }), [], !1, null, "8982cb6c", null).exports), x = {
                components: {MessageBox: E}, mixins: [h.a], computed: {
                    msgList: function () {
                        return [{
                            title: this.$t("HOME.DAPPSTORE.desc_3"),
                            desc: this.$t("HOME.DAPPSTORE.desc_6")
                        }, {
                            title: this.$t("HOME.DAPPSTORE.desc_4"),
                            desc: this.$t("HOME.DAPPSTORE.desc_6")
                        }, {title: this.$t("HOME.DAPPSTORE.desc_5"), desc: this.$t("HOME.DAPPSTORE.desc_6")}]
                    }
                }
            }, B = (n(471), Object(c.a)(x, (function () {
                var t = this, e = t.$createElement, o = t._self._c || e;
                return o("div", {staticClass: "HomeDappStore"}, [o("div", {staticClass: "content d-flex ai-center jc-between"}, [o("img", {
                    staticClass: "main-img",
                    attrs: {src: n(470)}
                }), t._v(" "), o("div", {
                    ref: "dapp-store",
                    staticClass: "content-right flex-1"
                }, [o("div", {staticClass: "title"}, [t._v(t._s(t.$t("HOME.DAPPSTORE.title")))]), t._v(" "), o("div", {staticClass: "desc desc1"}, [t._v("\n        " + t._s(t.$t("HOME.DAPPSTORE.desc_1")) + "\n      ")]), t._v(" "), o("div", {staticClass: "desc"}, [t._v("\n        " + t._s(t.$t("HOME.DAPPSTORE.desc_2")) + "\n      ")]), t._v(" "), o("div", {staticClass: "message-box-wrap"}, [o("MessageBox", {attrs: {msgList: t.msgList}})], 1)])])])
            }), [], !1, null, "6204cd0f", null).exports), P = (n(13), n(9), n(11), n(18), n(19), n(3)), T = n(10),
            H = n(147);

        function y(object, t) {
            var e = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                t && (n = n.filter((function (t) {
                    return Object.getOwnPropertyDescriptor(object, t).enumerable
                }))), e.push.apply(e, n)
            }
            return e
        }

        function I(t) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? y(Object(source), !0).forEach((function (e) {
                    Object(P.a)(t, e, source[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : y(Object(source)).forEach((function (e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                }))
            }
            return t
        }

        var R = {
                name: "HomeEcology", mixins: [H.a], data: function () {
                    return {}
                }, computed: I(I({}, Object(T.b)(["language"])), {}, {
                    mobileBgImg: function () {
                        return "zh" === this.language ? n(410) : n(411)
                    }, phoneBgImg: function () {
                        return "zh" === this.language ? n(410) : n(411)
                    }, ecologyMethod: function () {
                        return [{text: this.$t("HOME.ECOLOGY.staking"), img: n(472)}, {
                            text: this.$t("HOME.ECOLOGY.mining"),
                            img: n(473)
                        }, {text: this.$t("HOME.ECOLOGY.DeFi"), img: n(474)}, {
                            text: this.$t("HOME.ECOLOGY.cryptoGame"),
                            img: n(475)
                        }]
                    }
                }), methods: {
                    goLink: function (t) {
                        t.url && window.open(t.url)
                    }
                }
            }, D = (n(476), Object(c.a)(R, (function () {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {staticClass: "HomeEcology"}, [n("div", {staticClass: "container"}, [n("main", {
                    staticClass: "row",
                    staticStyle: {"align-items": "center"}
                }, [n("div", {staticClass: "ecology-l col-lg-7"}, [n("h2", [t._v(t._s(t.$t("HOME.ECOLOGY.title")))]), t._v(" "), n("div", {staticClass: "ecology-text"}, [n("p", [t._v(t._s(t.$t("HOME.ECOLOGY.desc_1")))]), t._v(" "), n("p", [t._v(t._s(t.$t("HOME.ECOLOGY.desc_2")))]), t._v(" "), n("p", [t._v(t._s(t.$t("HOME.ECOLOGY.desc_3")))])]), t._v(" "), n("h2", [t._v(t._s(t.$t("HOME.ECOLOGY.joinUs")))]), t._v(" "), n("div", {staticClass: "ecology-join"}, [n("a", {
                    staticClass: "pointer",
                    attrs: {href: t.$i18n.path("/project/dapp"), target: "_self"},
                    on: {
                        click: function (e) {
                            t.localLink(t.$i18n.path("/project/dapp"), e)
                        }
                    }
                }, [t._v(t._s(t.$t("HOME.ECOLOGY.subDApp")))]), t._v(" "), n("a", {
                    staticClass: "pointer",
                    attrs: {href: t.$i18n.path("/project/token"), target: "_self"},
                    on: {
                        click: function (e) {
                            t.localLink(t.$i18n.path("/project/token"), e)
                        }
                    }
                }, [t._v(t._s(t.$t("HOME.ECOLOGY.subToken")))])]), t._v(" "), n("h2", [t._v(t._s(t.$t("HOME.ECOLOGY.ways")))]), t._v(" "), n("div", {staticClass: "ecology-methods clearfix"}, t._l(t.ecologyMethod, (function (e, o) {
                    return n("div", {key: o, staticClass: "ecology-methods-item"}, [n("img", {
                        attrs: {
                            src: e.img,
                            alt: t.$t("COMMON.LAYOUT.ethWallet")
                        }
                    }), t._v(" "), n("p", [t._v(t._s(e.text))])])
                })), 0)]), t._v(" "), n("div", {staticClass: "ecology-r col-lg-5"}, [n("img", {
                    staticClass: "ecology-mobile",
                    attrs: {src: t.mobileBgImg, alt: t.$t("COMMON.LAYOUT.ETHWallet")}
                }), t._v(" "), n("img", {
                    staticClass: "ecology-pc",
                    attrs: {src: t.phoneBgImg, alt: t.$t("COMMON.LAYOUT.ETHWallet")}
                })])])])])
            }), [], !1, null, "410083af", null).exports), j = {
                components: {MessageBox: E, BoxItem: C}, mixins: [h.a], computed: {
                    developerUrl: function () {
                        return "zh" === this.$i18n.locale ? "https://help.tokenpocket.pro/developer-cn/" : "https://help.tokenpocket.pro/developer-en/"
                    }, msgList: function () {
                        return [{
                            titleImg: n(479),
                            titleImg_hover: n(480),
                            desc: this.$t("HOME.COMMUNITY.desc_2"),
                            icon: n(368),
                            icon_hover: n(370),
                            url: "https://github.com/TP-Lab"
                        }, {
                            titleImg: n(481),
                            titleImg_hover: n(482),
                            desc: this.$t("HOME.COMMUNITY.desc_3"),
                            icon: n(368),
                            icon_hover: n(370),
                            url: "https://discord.com/invite/NKPM8TXFQk"
                        }, {
                            titleImg: n(483),
                            titleImg_hover: n(484),
                            desc: this.$t("HOME.COMMUNITY.desc_4"),
                            icon: n(368),
                            icon_hover: n(370),
                            url: this.developerUrl
                        }]
                    }
                }
            }, U = (n(485), Object(c.a)(j, (function () {
                var t = this, e = t.$createElement, o = t._self._c || e;
                return o("div", {staticClass: "HomeCommunity"}, [o("div", {staticClass: "content d-flex ai-center jc-between"}, [o("div", {
                    ref: "community",
                    staticClass: "content-left"
                }, [o("div", {staticClass: "title"}, [t._v(t._s(t.$t("HOME.COMMUNITY.title")))]), t._v(" "), o("div", {staticClass: "desc"}, [t._v("\n        " + t._s(t.$t("HOME.COMMUNITY.desc_1")) + "\n      ")]), t._v(" "), o("div", {staticClass: "message-box-wrap"}, [o("MessageBox", {attrs: {msgList: t.msgList}})], 1), t._v(" "), o("div", {staticClass: "box-item-wrap"}, t._l(t.msgList, (function (t) {
                    return o("BoxItem", {key: t.title, attrs: {item: t, flag: !0}})
                })), 1)]), t._v(" "), o("img", {
                    staticClass: "main-img",
                    attrs: {src: n(477)}
                }), t._v(" "), o("img", {staticClass: "main-img-mobile", attrs: {src: n(478)}})])])
            }), [], !1, null, "6c853404", null).exports), S = {name: "HomeGrowth", mixins: [H.a]},
            z = (n(486), Object(c.a)(S, (function () {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {staticClass: "HomeGrowth"}, [n("div", {staticClass: "container"}, [n("h2", [t._v(t._s(t.$t("HOME.GROWTH.title")))]), t._v(" "), n("div", {staticClass: "growth-main"}, [n("div", {staticClass: "growth-items"}, [n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-top"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2017-12")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_1")))])]), t._v(" "), t._m(0)]), t._v(" "), n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-bottom"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2018-06")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_2")))])]), t._v(" "), t._m(1)]), t._v(" "), n("div", {staticClass: "growth-item"}, [t._m(2), t._v(" "), n("div", {staticClass: "growth-item-content growth-item-top"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2018-08")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_3")))])])]), t._v(" "), n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-bottom"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2019-01")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_4")))])]), t._v(" "), t._m(3)]), t._v(" "), n("div", {staticClass: "growth-item"}, [t._m(4), t._v(" "), n("div", {staticClass: "growth-item-content growth-item-top"}, [n("h4", {staticClass: "growth-item-time important-date"}, [t._v("2019-04")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_5")))])])]), t._v(" "), n("div", {staticClass: "growth-item"}, [t._m(5), t._v(" "), n("div", {staticClass: "growth-item-content growth-item-bottom"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2019-08")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_6")))])])]), t._v(" "), n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-top"}, [n("h4", {staticClass: "growth-item-time important-date"}, [t._v("2019-10")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_7")))])]), t._v(" "), t._m(6)]), t._v(" "), n("div", {staticClass: "growth-item"}, [t._m(7), t._v(" "), n("div", {staticClass: "growth-item-content growth-item-bottom"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2019-11")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_8")))])])]), t._v(" "), n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-top"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2019-12")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_9")))])]), t._v(" "), t._m(8)]), t._v(" "), n("div", {staticClass: "growth-item"}, [t._m(9), t._v(" "), n("div", {staticClass: "growth-item-content growth-item-bottom"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2020-05")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_10")))])])]), t._v(" "), n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-top"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2020-07")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_11")))])]), t._v(" "), t._m(10)]), t._v(" "), n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-bottom"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2020-09")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_13")))])]), t._v(" "), t._m(11)]), t._v(" "), n("div", {staticClass: "growth-item"}, [n("div", {staticClass: "growth-item-content growth-item-top"}, [n("h4", {staticClass: "growth-item-time"}, [t._v("2020-12")]), t._v(" "), n("p", {staticClass: "growth-item-desc"}, [t._v(t._s(t.$t("HOME.GROWTH.desc_15")))])]), t._v(" "), t._m(12)])])]), t._v(" "), n("div", {staticClass: "growth-partner text-center"}, [n("a", {
                    staticClass: "pointer",
                    attrs: {href: t.$i18n.path("/partner"), target: "_self"},
                    on: {
                        click: function (e) {
                            t.localLink(t.$i18n.path("/partner"), e)
                        }
                    }
                }, [t._v("\n          " + t._s(t.$t("HOME.GROWTH.ourPartner")) + "\n          "), n("i", {staticClass: "partner-icon-right"})])])])])
            }), [function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }, function () {
                var t = this.$createElement, e = this._self._c || t;
                return e("span", [e("i")])
            }], !1, null, "6cabb8ae", null).exports), N = (n(487), {
                name: "HomeNews", data: function () {
                    return {elImgWidth: 0}
                }, computed: {
                    newsList: function () {
                        return {
                            zh: [{
                                img: n(488),
                                url: "https://www.jinse.com/news/blockchain/967202.html",
                                time: "2020-12",
                                title: "TokenPocket荣获年度区块链百强企业奖与“2020最受用户信任钱包”奖"
                            }, {
                                img: n(489),
                                url: "https://mp.weixin.qq.com/s/51yIpsM7uHuoCDrls_nd4Q",
                                time: "2020-11",
                                title: "TokenPocket上线Eth 2.0 Staking产品质押宝"
                            }, {
                                img: n(490),
                                url: "https://mp.weixin.qq.com/s/L_4fO7hCNQpW1LiRcMut6g",
                                time: "2020-09",
                                title: "TokenPocket已全面支持币安智能链"
                            }, {
                                img: n(491),
                                url: "https://github.tokenpocket.pro/BlockchainGuide-TRON/#/",
                                time: "2020-08",
                                title: "由TokenPocket联合波场TRON官方，以及志愿者共同撰写的《波场钱包的现在过去与未来》已正式上线"
                            }, {
                                img: n(492),
                                url: "https://weibo.com/ttarticle/p/show?id=2309404537869862830262",
                                time: "2020-08",
                                title: "联合创始人兼CTO陈达做客虎符AMA"
                            }],
                            en: [{
                                img: n(415),
                                url: "https://tokenpocket-gm.medium.com/tokenpocket-won-the-annual-blockchain-top-100-enterprise-award-and-2020-most-trusted-wallet-award-3fdf703a9dd6",
                                time: "2020-12",
                                title: "TokenPocket won the Annual Blockchain Top 100 Enterprise Award and 2020 Most Trusted Wallet Award"
                            }, {
                                img: n(416),
                                url: "https://tokenpocket-gm.medium.com/eth2-0-staking-vault-is-officially-launched-with-an-estimated-apy-of-5-20-6e3f8be7f97a",
                                time: "2020-11",
                                title: "TokenPocket launches Eth 2.0 Staking Vault"
                            }, {
                                img: n(417),
                                url: "https://tokenpocket-gm.medium.com/binances-defi-breakthrough-the-binance-smart-chain-faed55c0cec4",
                                time: "2020-09",
                                title: "TokenPocket has fully supported Binance Smart Chain"
                            }, {
                                img: n(418),
                                url: "https://github.tokenpocket.pro/BlockchainGuide-TRON-EN/#/",
                                time: "2020-08",
                                title: "《The Present, Past and Future of TRON Wallet》co-written by TokenPocket, TRON official and volunteers, has been officially launched"
                            }, {
                                img: n(419),
                                url: "https://organixprotocol.medium.com/ama-with-hoo-com-organix-101-how-eos-defi-excels-as-a-latecomer-d2d506542d36",
                                time: "2020-08",
                                title: "Co-founder and CTO Chen Da participated in the Hoo AMA"
                            }],
                            ko: [{
                                img: n(415),
                                url: "https://tokenpocket-gm.medium.com/tokenpocket-won-the-annual-blockchain-top-100-enterprise-award-and-2020-most-trusted-wallet-award-3fdf703a9dd6",
                                time: "2020-12",
                                title: "토큰포켓은 블록체인 상위 100대 기업상과 2020년 가장 신뢰할 수 있는 지갑상을 수상"
                            }, {
                                img: n(416),
                                url: "https://tokenpocket-gm.medium.com/eth2-0-staking-vault-is-officially-launched-with-an-estimated-apy-of-5-20-6e3f8be7f97a",
                                time: "2020-11",
                                title: "토큰포켓이 이더리움 2.0 스테이킹 볼트 출시"
                            }, {
                                img: n(417),
                                url: "https://tokenpocket-gm.medium.com/binances-defi-breakthrough-the-binance-smart-chain-faed55c0cec4",
                                time: "2020-09",
                                title: "토큰포켓 바이낸스 스마트 체인 완전 지원"
                            }, {
                                img: n(418),
                                url: "https://github.tokenpocket.pro/BlockchainGuide-TRON-EN/#/",
                                time: "2020-08",
                                title: "토큰포켓이 공동 집필한 《트론 지갑의 현재, 과거, 미래》가 공식 출시"
                            }, {
                                img: n(419),
                                url: "https://organixprotocol.medium.com/ama-with-hoo-com-organix-101-how-eos-defi-excels-as-a-latecomer-d2d506542d36",
                                time: "2020-08",
                                title: "토큰포켓 공동 창립자 겸 CTO Chen Da, Hoo AMA 참여"
                            }]
                        }[this.$i18n.locale]
                    }
                }, methods: {
                    goNewsDetail: function (t) {
                        window && window.open(t)
                    }
                }, mounted: function () {
                    window && this.$nextTick((function () {
                        new (n(493))(".swiper-container", {slidesPerView: 3, paginationClickable: !0, spaceBetween: 20})
                    }))
                }
            }), L = (n(494), Object(c.a)(N, (function () {
                var t = this, e = t.$createElement, n = t._self._c || e;
                return n("div", {staticClass: "HomeNews"}, [n("div", {staticClass: "container"}, [n("h2", [t._v(t._s(t.$t("HOME.NEWS.title")))]), t._v(" "), n("main", {staticClass: "news-main"}, [n("div", {staticClass: "swiper-container"}, [n("div", {staticClass: "swiper-wrapper"}, t._l(t.newsList, (function (e, o) {
                    return n("div", {
                        key: o, staticClass: "swiper-slide pointer", on: {
                            click: function (n) {
                                return t.goNewsDetail(e.url)
                            }
                        }
                    }, [n("img", {
                        staticClass: "news-poster",
                        staticStyle: {width: "100%"},
                        attrs: {src: e.img, alt: t.$t("COMMON.LAYOUT.defiWallet")}
                    }), t._v(" "), n("h5", {staticClass: "news-time"}, [t._v(t._s(e.time))]), t._v(" "), n("p", {staticClass: "news-desc"}, [t._v(t._s(e.title))])])
                })), 0)]), t._v(" "), n("div", {staticClass: "news-sm"}, t._l(t.newsList, (function (e, o) {
                    return n("div", {
                        key: o, staticClass: "pointer", on: {
                            click: function (n) {
                                return t.goNewsDetail(e.url)
                            }
                        }
                    }, [n("img", {
                        staticClass: "news-poster",
                        staticStyle: {width: "100%"},
                        attrs: {src: e.img, alt: t.$t("COMMON.LAYOUT.defiWallet")}
                    }), t._v(" "), n("h5", {staticClass: "news-time"}, [t._v(t._s(e.time))]), t._v(" "), n("p", {staticClass: "news-desc"}, [t._v(t._s(e.title))])])
                })), 0)])])])
            }), [], !1, null, "641504ab", null).exports);

        function G(object, t) {
            var e = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(object);
                t && (n = n.filter((function (t) {
                    return Object.getOwnPropertyDescriptor(object, t).enumerable
                }))), e.push.apply(e, n)
            }
            return e
        }

        function V(t) {
            for (var i = 1; i < arguments.length; i++) {
                var source = null != arguments[i] ? arguments[i] : {};
                i % 2 ? G(Object(source), !0).forEach((function (e) {
                    Object(P.a)(t, e, source[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(source)) : G(Object(source)).forEach((function (e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(source, e))
                }))
            }
            return t
        }

        var Q = {
            name: "HomeFollow", components: {Modal: n(212).a}, data: function () {
                return {show: !1, url: "false"}
            }, computed: V(V({}, Object(T.b)(["language"])), {}, {
                followImgList: function () {
                    return [{class: "follow-1", url: "https://twitter.com/TokenPocket_TP"}, {
                        class: "follow-2",
                        isTelegram: !0,
                        url: "zh" === this.language ? "https://t.me/tokenPocket_cn" : "ko" === this.language ? "https://t.me/tokenpocket_kor" : "https://t.me/tokenpocket_en"
                    }, {
                        class: "follow-8",
                        url: "https://www.youtube.com/channel/UCudaS5hcbqUaMtOGHmQ2e0A"
                    }, {class: "follow-4", url: "https://github.com/TP-Lab"}, {
                        class: "follow-5",
                        url: "https://fans.tokenpocket.pro/"
                    }, {class: "follow-6", url: "https://tokenpocket-gm.medium.com/"}]
                }
            }), methods: {
                openFollow: function (t) {
                    t.isTelegram ? (this.show = !0, this.url = t.url) : window.open(t.url)
                }, close: function () {
                    this.show = !1
                }
            }
        }, Z = (n(495), Object(c.a)(Q, (function () {
            var t = this, e = t.$createElement, n = t._self._c || e;
            return n("div", {staticClass: "HomeFollow"}, [n("div", {staticClass: "container"}, [n("h2", {staticClass: "text-center"}, [t._v(t._s(t.$t("HOME.FOLLOW.title")))]), t._v(" "), n("div", {staticClass: "follow-logo"}, [t._l(t.followImgList, (function (e, o) {
                return n("div", {key: o, staticClass: "follow-logo-item"}, [n("span", {
                    class: [e.class],
                    on: {
                        click: function (n) {
                            return t.openFollow(e)
                        }
                    }
                })])
            })), t._v(" "), t._m(0)], 2)]), t._v(" "), t.show ? n("Modal", {
                attrs: {url: t.url},
                on: {close: t.close}
            }) : t._e()], 1)
        }), [function () {
            var t = this.$createElement, e = this._self._c || t;
            return e("div", {staticClass: "follow-logo-item"}, [e("a", {
                staticClass: "follow-7",
                attrs: {href: "mailto:service@tokenpocket.pro", target: "_blank"}
            })])
        }], !1, null, "62e96600", null).exports), F = n(400), K = {
            scrollToTop: !1,
            components: {
                HomeHeader: header,
                HomeIntroduction: d.a,
                HomeSecurity: f,
                HomeExchange: k,
                HomeDappStore: B,
                HomeEcology: D,
                HomeCommunity: U,
                HomeGrowth: z,
                HomeNews: L,
                HomeFollow: Z,
                HomeDownload: F.a
            },
            head: function () {
                return {
                    title: this.$t("SEO.title"),
                    meta: [{
                        hid: "description",
                        name: "description",
                        content: this.$t("SEO.description")
                    }, {hid: "keywords", name: "keywords", content: this.$t("SEO.keywords")}, {
                        hid: "og:title",
                        property: "og:title",
                        content: this.$t("SEO.title")
                    }, {
                        hid: "og:site_name",
                        property: "og:site_name",
                        content: this.$t("SEO.title")
                    }, {
                        hid: "og:description",
                        property: "og:description",
                        content: this.$t("SEO.description")
                    }, {
                        hid: "twitter:title",
                        property: "twitter:title",
                        content: this.$t("SEO.title")
                    }, {
                        hid: "twitter:description",
                        property: "twitter:description",
                        content: this.$t("SEO.description")
                    }]
                }
            },
            mixins: [l],
            computed: {
                homeBg: function () {
                    return this.$i18n.locale, n(422)
                }, extensionModalImg: function () {
                    return "zh" === this.$i18n.locale ? n(496) : n(497)
                }, extensionModalImgM: function () {
                    return "zh" === this.$i18n.locale ? n(498) : n(499)
                }, btnText: function () {
                    return this.$t("HOME.EXTENSIONMODAL.btnText")
                }, downloadUrl: function () {
                    return "zh" == this.$i18n.locale ? "https://chrome.google.com/webstore/detail/tokenpocket/mfgccjchihfkkindfppnaooecgfneiii?hl=zh-CN" : "https://chrome.google.com/webstore/detail/tokenpocket/mfgccjchihfkkindfppnaooecgfneiii?hl=en-us"
                }, needAlert: function () {
                    return "zh" === this.$i18n.locale
                }
            },
            data: function () {
                return {isClosed: !1}
            },
            mounted: function () {
            },
            methods: {
                getTime: function () {
                    var t = "";
                    if (window && (t = JSON.parse(window.localStorage.getItem("lastTimeData"))), t) {
                        var e = (Date.now() - Number(t.time)) / 864e5;
                        parseInt(e) >= 3 && 1 === t.count ? this.onOpen(2) : parseInt(e) >= 7 && 2 === t.count ? this.onOpen(3) : parseInt(e) >= 15 && 3 === t.count ? this.onOpen(4) : parseInt(e) >= 30 && 4 === t.count && this.onOpen(5)
                    } else this.onOpen(1)
                }, onOpen: function (t) {
                    var e = {count: t, time: Date.now()};
                    window && window.localStorage.setItem("lastTimeData", JSON.stringify(e));
                    var n = "";
                    this.isMobile ? (n = "onshow-mobile", this.$modal.show("extension-panel-m")) : (n = "onshow", this.$modal.show("extension-panel")), setTimeout((function () {
                        window._hmt && window._hmt.push(["_trackEvent", "showExtensionModal", n])
                    }), 3e3)
                }, onClose: function () {
                    var t = "";
                    t = this.isMobile ? "onclose-mobile" : "onclose", this.$modal.hide("extension-panel-m"), this.$modal.hide("extension-panel"), window._hmt && window._hmt.push(["_trackEvent", "closeExtensionModal", t])
                }, onDownload: function () {
                    var t = "";
                    t = this.isMobile ? "onuse-mobile" : "onuse", window.open(this.downloadUrl), this.onClose(), window._hmt && window._hmt.push(["_trackEvent", "clickUse", t])
                }
            }
        }, Y = (n(500), Object(c.a)(K, (function () {
            var t = this, e = t.$createElement, o = t._self._c || e;
            return o("div", {staticClass: "home layout"}, [o("div", {staticClass: "header-bg"}, [o("HeaderLayout", {
                attrs: {
                    "nav-title-color": "#000",
                    "arrow-class": "icon-down-333",
                    "arrow-up-class": "icon-up-333",
                    "lang-class": "icon-earth-mini"
                }
            }), t._v(" "), o("HomeHeader")], 1), t._v(" "), o("modal", {
                attrs: {
                    name: "notice-panel",
                    classes: "notice-modal",
                    width: "90%",
                    height: "575",
                    maxWidth: 620,
                    adaptive: !0
                }
            }, [o("p", {staticClass: "title-bold"}, [o("b", [t._v("致中国境内用户：TokenPocket 产品政策调整说明")])]), t._v(" "), o("p", [t._v("\n      为响应监管要求，TokenPocket将于2021年11月5日起，发布新版本，新版本将对中国大陆IP进行以下第三方的应用移除，包括但不限于：\n    ")]), t._v(" "), o("p", [t._v("\n      DAPP：DEX 币币兑换"), o("br"), t._v("\n      Staking：流动性挖矿"), o("br"), t._v("\n      借贷、衍生品等第三方DApps\n    ")]), t._v(" "), o("p", [t._v("\n      同时将整体下架DeFi数据板块，以及市场、资讯页面。TokenPocket仍继续保留钱包的基础服务功能，转账、收款、DApp浏览器等功能可继续使用，此过程对用户的资产安全没有任何影响。TokenPocket将致力于区块链技术产业落地，持续努力做好数字钱包的工作。\n    ")]), t._v(" "), o("p", {staticClass: "title-red"}, [t._v("\n      目前市场上出现诸多下载TokenPocket国际版的诈骗行文，TokenPocket在此严正声明，TokenPocket没有“国际版本”，请广大用户谨防上当受骗。\n    ")]), t._v(" "), o("p", [t._v("TokenPocket基金会")]), t._v(" "), o("div", {
                staticClass: "close-btn",
                on: {
                    click: function (e) {
                        return t.$modal.hide("notice-panel")
                    }
                }
            }, [t._v("知道了")])]), t._v(" "), o("modal", {
                attrs: {
                    name: "extension-panel",
                    classes: "extension-content",
                    height: "520",
                    width: "880"
                }, on: {closed: t.onClose}
            }, [o("img", {attrs: {src: t.extensionModalImg}}), t._v(" "), o("div", {staticClass: "desc-right"}, [o("div", {staticClass: "title-wrap"}, [o("div", {staticClass: "title"}, [t._v("TokenPocket")]), t._v(" "), o("div", {staticClass: "title"}, [t._v(t._s(t.$t("HOME.EXTENSIONMODAL.title")))])]), t._v(" "), o("div", {staticClass: "desc-wrap"}, [o("div", {staticClass: "desc"}, [t._v(t._s(t.$t("HOME.EXTENSIONMODAL.desc1")))]), t._v(" "), o("div", {staticClass: "desc"}, [t._v(t._s(t.$t("HOME.EXTENSIONMODAL.desc2")))])]), t._v(" "), o("div", {
                staticClass: "use-now",
                on: {click: t.onDownload}
            }, [t._v("\n        " + t._s(t.btnText) + "\n      ")])]), t._v(" "), o("img", {
                staticClass: "close",
                attrs: {src: n(380)},
                on: {
                    click: function (e) {
                        return t.onClose()
                    }
                }
            })]), t._v(" "), o("modal", {
                attrs: {
                    name: "extension-panel-m",
                    classes: "extension-content extension-content-mobile",
                    height: "auto",
                    width: "314"
                }, on: {closed: t.onClose}
            }, [o("img", {attrs: {src: t.extensionModalImgM}}), t._v(" "), o("div", {staticClass: "desc-right"}, [o("div", {staticClass: "title-wrap"}, [o("div", {staticClass: "title"}, [t._v("\n          TokenPocket " + t._s(t.$t("HOME.EXTENSIONMODAL.title")) + "\n        ")])]), t._v(" "), o("div", {staticClass: "desc-wrap"}, [o("div", {staticClass: "desc"}, [t._v(t._s(t.$t("HOME.EXTENSIONMODAL.desc1")))]), t._v(" "), o("div", {staticClass: "desc"}, [t._v(t._s(t.$t("HOME.EXTENSIONMODAL.desc2")))])]), t._v(" "), o("div", {
                staticClass: "use-now",
                on: {click: t.onDownload}
            }, [t._v("\n        " + t._s(t.btnText) + "\n      ")]), t._v(" "), o("img", {
                staticClass: "close",
                attrs: {src: n(448)},
                on: {
                    click: function (e) {
                        return t.onClose()
                    }
                }
            })])]), t._v(" "), o("HomeIntroduction"), t._v(" "), o("HomeSecurity"), t._v(" "), o("HomeExchange"), t._v(" "), o("HomeDappStore"), t._v(" "), o("HomeCommunity"), t._v(" "), o("HomeDownload"), t._v(" "), o("footer-layout")], 1)
        }), [], !1, null, null, null));
        e.default = Y.exports
    }
}]);